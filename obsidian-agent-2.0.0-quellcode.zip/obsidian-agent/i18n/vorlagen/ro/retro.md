---
typ: retro
titel: {{title}}
projekt: {{projekt}}
pi: {{pi}}
team: {{team}}
iteration: {{iteration}}
datum: {{date}}
tags: [safe, retro]
---
# Retrospectivă: {{title}}
**PI:** {{pi}} · **Echipă:** {{team}} · **Iterație:** {{iteration}}

## Ce a mers bine?
- 

## Ce nu a mers bine?
- 

## Ce îmbunătățim? (cel mult două măsuri)
- [ ] 

## Obstacole pentru Inspect & Adapt
> Marcați obstacolele care afectează mai multe echipe cu `#blocker`.

- 
