---
typ: projektmanagementplan
titel: {{title}}
projekt: {{projekt}}
version: 0.1
status: in_arbeit
erstellt: {{date}}
tags: [hermes, pmp]
---
# Planul de management al proiectului: {{title}}

## 1. Situația inițială și obiective
- Obiectivele proiectului (din mandatul de execuție):
- Delimitare:

## 2. Abordare
- Abordare (clasică, agilă, SAFe):
- Faze și release-uri:

## 3. Organizarea proiectului
| Rol | Persoană |
|---|---|
| Sponsorul proiectului | |
| Comitetul de coordonare | |
| Managerul de proiect | |
| Reprezentantul utilizatorilor | |
| Responsabil calitate și riscuri | |

## 4. Jaloane și termene
{{auto_meilensteine}}

## 5. Costuri și resurse
| Fază | Efort de personal | Costuri materiale |
|---|---|---|
| | | |

## 6. Comunicare și raportare
- Raport de stare a proiectului: lunar către comitetul de coordonare
- Ședințele comitetului de coordonare:

## 7. Riscuri
{{auto_risiken}}

## 8. Calitate și modificări
- Procedura de modificare: cerere de modificare, decizia comitetului de coordonare
