---
typ: inspect_adapt
titel: {{title}}
projekt: {{projekt}}
pi: {{pi}}
datum: {{date}}
tags: [safe, inspect-adapt]
---
# Inspect & Adapt: {{pi}}

## 1. Demonstrația de sistem a PI
- 

## 2. Măsurare cantitativă și calitativă
{{predictability}}

> Intervalul țintă al predictibilității conform SAFe: 80 până la 100 %.

## 3. Retrospectivă
### Retrospectivele echipelor în acest PI
```dataview
TABLE team, iteration
WHERE typ = "retro" AND pi = "{{pi}}"
SORT iteration ASC
```

### Tipare recurente (obstacole sistemice)
- 

## 4. Atelier de rezolvare a problemelor
### Problema convenită

### Analiza cauzelor (os de pește, 5 de ce)
- Oameni:
- Procese:
- Instrumente:
- Organizare:
- Mediu:

### Cauza principală (Pareto)

### Idei de soluții și vot

## 5. Backlog de îmbunătățiri pentru următorul PI Planning
- [ ] 
