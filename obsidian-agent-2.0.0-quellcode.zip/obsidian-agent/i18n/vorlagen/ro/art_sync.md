---
typ: art_sync
titel: {{title}}
projekt: {{projekt}}
pi: {{pi}}
datum: {{date}}
tags: [meeting, safe, art-sync]
---
# ART Sync: {{title}}
**Dată:** {{date}} · **PI:** {{pi}}

## Progres pe echipă
| Echipă | Progresul funcționalităților | Dependențe | Blocaje |
|---|---|---|---|
| | | | |

## Blocaje și riscuri
> `#blocker` pentru obstacole, `#risiko` pentru riscuri.

- 

## Decizii
- 

## Acțiuni
| Ce | Cine | Până la |
|-----|-----|-----|
|     |     |     |
