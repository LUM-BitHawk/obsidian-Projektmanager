---
typ: risiko
titel: {{title}}
projekt: {{projekt}}
pi: {{pi}}
wahrscheinlichkeit: {{wahrscheinlichkeit}}
auswirkung: {{auswirkung}}
roam: {{roam}}
verantwortlich: {{verantwortlich}}
faellig: {{faellig}}
erfasst: {{date}}
task:
tags: [risiko]
---
# Risc: {{title}}

## Descriere (cauză, eveniment, impact)
{{beschreibung}}

## Măsură
{{massnahme}}

## ROAM
| Stare | Semnificație |
|---|---|
| Resolved | Nu mai este un risc, notați motivul |
| Owned | O persoană se ocupă de el |
| Accepted | Acceptat în mod conștient |
| Mitigated | Măsurile reduc probabilitatea sau impactul |

## Istoric
- {{date}}: risc înregistrat
