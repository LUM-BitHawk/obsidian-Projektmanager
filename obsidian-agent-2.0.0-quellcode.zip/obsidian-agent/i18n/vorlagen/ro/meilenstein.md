---
typ: meilenstein
titel: {{title}}
ms_id: {{ms_id}}
projekt: {{projekt}}
methode: {{methode}}
phase: {{phase}}
reihenfolge: {{reihenfolge}}
kern: {{kern}}
plan: {{plan}}
ist:
status: geplant
entscheid_durch: {{entscheid_durch}}
entscheid:
tags: [meilenstein, hermes]
---
# {{title}}

**Fază:** {{phase_name}} · **Decis de:** {{entscheid_durch}}

## Puncte de control pentru aprobare
> Rezultate tipice conform HERMES 2022. Adaptați la scenariu și la mărimea proiectului.

{{pruefpunkte}}

## Baze pentru decizie
- 

## Decizie
- Dată:
- Decizie:
- Condiții:
