---
typ: projektausschuss
titel: {{title}}
projekt: {{projekt}}
datum: {{date}}
teilnehmende:
tags: [meeting, projektausschuss]
---
# Comitetul de coordonare: {{title}}
**Dată:** {{date}} · **Proiect:** {{projekt}} · **Faza curentă:** {{auto_phase}}

## Participanți
- 

## Ordinea de zi
1. Starea proiectului și jaloane
2. Riscuri
3. Cereri și decizii
4. Diverse

## Starea proiectului
{{auto_meilensteine}}

## Riscuri
> Marcați riscurile noi cu `#risiko`, blocajele cu `#blocker`.

{{auto_risiken}}

## Decizii
> Marcați fiecare decizie pe un rând separat cu `#entscheid`. Apoi apare în registrul deciziilor.

- 

## Sarcini
| Ce | Cine | Până la |
|-----|-----|-----|
|     |     |     |
