---
typ: pi_objective
titel: {{title}}
projekt: {{projekt}}
pi: {{pi}}
team: {{team}}
committed: {{committed}}
bv_geplant: {{bv_geplant}}
bv_ist:
status: geplant
tags: [safe, pi-objective]
---
# {{title}}

**PI:** {{pi}} · **Echipă:** {{team}} · **Committed:** {{committed}} · **Valoare de business planificată:** {{bv_geplant}}

## Descriere (SMART)
{{beschreibung}}

## Funcționalități asociate
- 

## Rezultat la sfârșitul PI
- Valoarea de business atinsă (evaluată de business owners):
- Observație:
