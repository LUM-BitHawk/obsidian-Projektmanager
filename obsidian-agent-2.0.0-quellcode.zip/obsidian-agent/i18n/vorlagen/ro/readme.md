---
typ: readme
projekt: {{projekt}}
ordner: {{ordner}}
erstellt: {{date}}
tags: [readme]
---
# {{titel}}

## Scopul acestui dosar
{{zweck}}

## Conținut
```dataview
LIST
FROM "{{pfad}}"
WHERE file.name != this.file.name
SORT file.mtime DESC
```
