---
typ: jourfixe
titel: {{title}}
serie: {{serie}}
datum: {{datum}}
projekt: {{projekt}}
moderation: {{moderation}}
teilnehmer: {{teilnehmer}}
naechster_termin: {{naechster_termin}}
tags: [jourfixe]
---
# {{title}}

**Dată:** {{datum}} · **Moderare:** {{moderation}} · **Următoarea ședință:** {{naechster_termin}}
**Participanți:** {{teilnehmer}}

## Ordinea de zi
{{agenda}}

## Puncte deschise (situația înainte de ședință)
{{pendenzen}}

## Informații / discuție
- 

## Hotărâri
> Marcați hotărârile cu `#entscheid`, apoi apar în registrul deciziilor.

- 

## Puncte deschise noi
> Înregistrați punctele deschise noi în Obsidian-Agent la *Ședință periodică*. Ele apar apoi și la Sarcini și Azi.
