---
typ: projekt
titel: {{title}}
projekt: {{title}}
kunde: {{kunde}}
methode: {{methode}}
status: aktiv
erstellt: {{date}}
tags: [projekt]
---
# Proiect: {{title}}

{{beschreibung}}

## Structură
{{struktur}}

## Sarcini deschise
```dataview
TABLE start, ende, status, prioritaet, verantwortlich
FROM "{{root}}"
WHERE typ = "task" AND status != "erledigt"
SORT ende ASC
```

## Jaloane
```dataview
TABLE phase, plan, ist, status, entscheid_durch
FROM "{{root}}"
WHERE typ = "meilenstein"
SORT reihenfolge ASC
```

## Planning Intervals
```dataview
TABLE art, start, ende, status
FROM "{{root}}"
WHERE typ = "pi"
SORT start DESC
```

## Riscuri deschise (ROAM)
```dataview
TABLE wahrscheinlichkeit, auswirkung, roam, verantwortlich, faellig
FROM "{{root}}"
WHERE typ = "risiko" AND roam != "resolved"
```

## Registrul deciziilor
```dataview
TABLE datum, gremium, entscheid_durch, status
FROM "{{root}}"
WHERE typ = "entscheid"
SORT datum DESC
```

## Decizii, riscuri și blocaje marcate
```dataview
TABLE WITHOUT ID L.text AS "Intrare", file.link AS "Notă"
FROM "{{root}}"
FLATTEN file.lists AS L
WHERE contains(L.tags, "#entscheid") OR contains(L.tags, "#risiko") OR contains(L.tags, "#blocker")
```

> Tabelele necesită pluginul comunității Dataview.
