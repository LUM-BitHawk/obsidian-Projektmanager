---
typ: aenderungsantrag
titel: {{title}}
projekt: {{projekt}}
datum: {{date}}
status: beantragt
antragsteller:
tags: [hermes, aenderung]
---
# Cerere de modificare: {{title}}

## Descrierea modificării

## Justificare

## Efecte
| Domeniu | Efect |
|---|---|
| Obiective / perimetru | |
| Costuri | |
| Termene | |
| Riscuri | |

## Variante

## Cerere către comitetul de coordonare

## Decizie
- 
