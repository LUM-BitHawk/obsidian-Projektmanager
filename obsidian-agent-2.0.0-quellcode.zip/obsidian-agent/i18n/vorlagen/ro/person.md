---
typ: person
titel: {{title}}
kuerzel: {{kuerzel}}
rolle: {{rolle}}
team: {{team}}
organisation: {{organisation}}
email: {{email}}
telefon: {{telefon}}
einfluss: {{einfluss}}
interesse: {{interesse}}
vertretung: {{vertretung}}
tags: [person]
---
# {{title}}

| Câmp | Valoare |
|------|------|
| Rol | {{rolle}} |
| Echipă / organizație | {{team}} {{organisation}} |
| E-mail | {{email}} |
| Telefon | {{telefon}} |
| Influență / interes | {{einfluss}} / {{interesse}} |
| Înlocuitor | {{vertretung}} |

## Responsabilități în proiect
- 

## Așteptări și preocupări
- 

## Ultimele puncte discutate
- 
