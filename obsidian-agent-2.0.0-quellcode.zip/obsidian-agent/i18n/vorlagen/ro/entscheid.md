---
typ: entscheid
titel: {{title}}
projekt: {{projekt}}
datum: {{datum}}
gremium: {{gremium}}
entscheid_durch: {{entscheid_durch}}
status: {{status}}
meilenstein: {{meilenstein}}
pi: {{pi}}
tags: [entscheid]
---
# Decizie: {{title}}

**Dată:** {{datum}} · **Organ:** {{gremium}} · **Decis de:** {{entscheid_durch}}

## Cerere / situația inițială
{{antrag}}

## Decizie
{{entscheid}}

## Condiții / consecințe
- 
