---
typ: statusbericht
titel: {{title}}
projekt: {{projekt}}
datum: {{date}}
phase: {{auto_phase}}
ampel_gesamt: gruen
ampel_termine: gruen
ampel_kosten: gruen
ampel_qualitaet: gruen
tags: [hermes, statusbericht]
---
# Raport de stare a proiectului: {{title}}
**Situația la:** {{date}} · **Faza curentă:** {{auto_phase}}

## Evaluare generală
| Domeniu | Semafor (verde / galben / roșu) | Comentariu |
|---|---|---|
| General | verde | |
| Termene | verde | |
| Costuri | verde | |
| Calitate / performanță | verde | |

## Rezultate obținute de la ultimul raport
- 

## Jaloane
{{auto_meilensteine}}

## Riscuri deschise
{{auto_risiken}}

## Deciziile din ultimele 30 de zile
{{auto_entscheide}}

## Cereri către comitetul de coordonare
- 

## Pașii următori
- 
