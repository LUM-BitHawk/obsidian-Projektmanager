---
typ: meeting
titel: {{title}}
projekt: {{projekt}}
datum: {{date}}
teilnehmende:
tags: [meeting]
---
# Ședință: {{title}}
**Dată:** {{date}} · **Proiect:** {{projekt}}

## Participanți
- 

## Ordinea de zi
1. 

## Discutat / rezultate
- 

## Decizii
> Marcați fiecare decizie pe un rând separat cu `#entscheid`, riscurile cu `#risiko`, blocajele cu `#blocker`.

- 

## Sarcini
| Ce | Cine | Până la |
|-----|-----|-----|
|     |     |     |
