---
typ: schlussbeurteilung
titel: {{title}}
projekt: {{projekt}}
datum: {{date}}
tags: [hermes, abschluss]
---
# Evaluarea finală a proiectului: {{title}}

## Atingerea obiectivelor
| Obiectiv | Atins | Observație |
|---|---|---|
| | | |

## Comparație planificat/efectiv a jaloanelor
{{auto_meilensteine}}

## Costuri și efort (planificat/efectiv)
| Poziție | Planificat | Efectiv | Diferență |
|---|---|---|---|
| | | | |

## Experiențe (lessons learned)
- 

## Puncte deschise și măsuri după încheierea proiectului
- 

## Cerere de încheiere a proiectului
- 
