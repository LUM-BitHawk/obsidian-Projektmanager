---
typ: pi
titel: {{title}}
projekt: {{projekt}}
art: {{art}}
start: {{start}}
ende: {{ende}}
iterationen: {{iterationen}}
iteration_wochen: {{iteration_wochen}}
status: {{status}}
tags: [safe, pi]
---
# {{title}}{{art_titel}}

**Perioadă:** {{start}} până la {{ende}} · **Iterații:** {{iterationen}} a câte {{iteration_wochen}} săptămâni (ultima este iterația IP)

## Iterații
{{iterationen_tabelle}}

## Obiective PI (necesită pluginul comunității Dataview)
```dataview
TABLE team, committed, bv_geplant AS "VB planificată", bv_ist AS "VB atinsă", status
FROM "{{ordner}}"
WHERE typ = "pi_objective"
SORT team ASC, committed DESC
```

## ART Planning Board
[[{{board}}|ART Planning Board (pânză)]]

## Riscuri (ROAM)
```dataview
TABLE wahrscheinlichkeit, auswirkung, roam, verantwortlich
WHERE typ = "risiko" AND pi = "{{title}}"
```

## Retrospectivele acestui PI
```dataview
TABLE team, iteration
WHERE typ = "retro" AND pi = "{{title}}"
SORT iteration ASC
```

## Note despre PI Planning
- Viziune / context de business:
- Funcționalități principale:
- Vot de încredere:
