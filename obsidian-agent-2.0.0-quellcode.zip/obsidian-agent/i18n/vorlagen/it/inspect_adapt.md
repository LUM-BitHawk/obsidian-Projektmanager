---
typ: inspect_adapt
titel: {{title}}
projekt: {{projekt}}
pi: {{pi}}
datum: {{date}}
tags: [safe, inspect-adapt]
---
# Inspect & Adapt: {{pi}}

## 1. Demo di sistema del PI
- 

## 2. Misurazione quantitativa e qualitativa
{{predictability}}

> Intervallo obiettivo della prevedibilità secondo SAFe: da 80 a 100 %.

## 3. Retrospettiva
### Retrospettive dei team in questo PI
```dataview
TABLE team, iteration
WHERE typ = "retro" AND pi = "{{pi}}"
SORT iteration ASC
```

### Schemi ricorrenti (impedimenti sistemici)
- 

## 4. Workshop di problem solving
### Problema concordato

### Analisi delle cause (lisca di pesce, 5 perché)
- Persone:
- Processi:
- Strumenti:
- Organizzazione:
- Ambiente:

### Causa principale (Pareto)

### Idee di soluzione e votazione

## 5. Backlog di miglioramento per il prossimo PI Planning
- [ ] 
