---
typ: readme
projekt: {{projekt}}
ordner: {{ordner}}
erstellt: {{date}}
tags: [readme]
---
# {{titel}}

## Scopo di questa cartella
{{zweck}}

## Contenuto
```dataview
LIST
FROM "{{pfad}}"
WHERE file.name != this.file.name
SORT file.mtime DESC
```
