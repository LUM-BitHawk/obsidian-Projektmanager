---
typ: projektmanagementplan
titel: {{title}}
projekt: {{projekt}}
version: 0.1
status: in_arbeit
erstellt: {{date}}
tags: [hermes, pmp]
---
# Piano di gestione del progetto: {{title}}

## 1. Situazione iniziale e obiettivi
- Obiettivi del progetto (dal mandato di esecuzione):
- Delimitazione:

## 2. Procedura
- Procedura (classica, agile, SAFe):
- Fasi e release:

## 3. Organizzazione del progetto
| Ruolo | Persona |
|---|---|
| Committente | |
| Comitato di progetto | |
| Capoprogetto | |
| Rappresentante degli utenti | |
| Responsabile qualità e rischi | |

## 4. Pietre miliari e scadenze
{{auto_meilensteine}}

## 5. Costi e risorse
| Fase | Onere di personale | Costi materiali |
|---|---|---|
| | | |

## 6. Comunicazione e reporting
- Rapporto sullo stato del progetto: mensile al comitato di progetto
- Sedute del comitato di progetto:

## 7. Rischi
{{auto_risiken}}

## 8. Qualità e modifiche
- Procedura di modifica: richiesta di modifica, decisione del comitato di progetto
