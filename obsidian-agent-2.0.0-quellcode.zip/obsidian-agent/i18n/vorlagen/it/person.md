---
typ: person
titel: {{title}}
kuerzel: {{kuerzel}}
rolle: {{rolle}}
team: {{team}}
organisation: {{organisation}}
email: {{email}}
telefon: {{telefon}}
einfluss: {{einfluss}}
interesse: {{interesse}}
vertretung: {{vertretung}}
tags: [person]
---
# {{title}}

| Campo | Valore |
|------|------|
| Ruolo | {{rolle}} |
| Team / organizzazione | {{team}} {{organisation}} |
| E-mail | {{email}} |
| Telefono | {{telefon}} |
| Influenza / interesse | {{einfluss}} / {{interesse}} |
| Supplenza | {{vertretung}} |

## Responsabilità nel progetto
- 

## Aspettative e richieste
- 

## Ultimi punti discussi
- 
