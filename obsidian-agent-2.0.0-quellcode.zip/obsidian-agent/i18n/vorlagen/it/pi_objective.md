---
typ: pi_objective
titel: {{title}}
projekt: {{projekt}}
pi: {{pi}}
team: {{team}}
committed: {{committed}}
bv_geplant: {{bv_geplant}}
bv_ist:
status: geplant
tags: [safe, pi-objective]
---
# {{title}}

**PI:** {{pi}} · **Team:** {{team}} · **Committed:** {{committed}} · **Valore di business pianificato:** {{bv_geplant}}

## Descrizione (SMART)
{{beschreibung}}

## Feature correlate
- 

## Risultato alla fine del PI
- Valore di business raggiunto (valutazione dei business owner):
- Osservazione:
