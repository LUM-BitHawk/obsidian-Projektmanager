---
typ: meilenstein
titel: {{title}}
ms_id: {{ms_id}}
projekt: {{projekt}}
methode: {{methode}}
phase: {{phase}}
reihenfolge: {{reihenfolge}}
kern: {{kern}}
plan: {{plan}}
ist:
status: geplant
entscheid_durch: {{entscheid_durch}}
entscheid:
tags: [meilenstein, hermes]
---
# {{title}}

**Fase:** {{phase_name}} · **Deciso da:** {{entscheid_durch}}

## Punti di controllo per la liberazione
> Risultati tipici secondo HERMES 2022. Adattare allo scenario e alle dimensioni del progetto.

{{pruefpunkte}}

## Basi decisionali
- 

## Decisione
- Data:
- Decisione:
- Condizioni:
