---
typ: art_sync
titel: {{title}}
projekt: {{projekt}}
pi: {{pi}}
datum: {{date}}
tags: [meeting, safe, art-sync]
---
# ART Sync: {{title}}
**Data:** {{date}} · **PI:** {{pi}}

## Avanzamento per team
| Team | Avanzamento feature | Dipendenze | Bloccanti |
|---|---|---|---|
| | | | |

## Bloccanti e rischi
> `#blocker` per gli impedimenti, `#risiko` per i rischi.

- 

## Decisioni
- 

## Punti d'azione
| Cosa | Chi | Entro |
|-----|-----|-----|
|     |     |     |
