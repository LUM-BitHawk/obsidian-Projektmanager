---
typ: projektausschuss
titel: {{title}}
projekt: {{projekt}}
datum: {{date}}
teilnehmende:
tags: [meeting, projektausschuss]
---
# Comitato di progetto: {{title}}
**Data:** {{date}} · **Progetto:** {{projekt}} · **Fase attuale:** {{auto_phase}}

## Partecipanti
- 

## Ordine del giorno
1. Stato del progetto e pietre miliari
2. Rischi
3. Richieste e decisioni
4. Varie

## Stato del progetto
{{auto_meilensteine}}

## Rischi
> Contrassegnare i nuovi rischi con `#risiko`, i bloccanti con `#blocker`.

{{auto_risiken}}

## Decisioni
> Contrassegnare ogni decisione su una riga separata con `#entscheid`. Compare poi nel registro delle decisioni.

- 

## Compiti
| Cosa | Chi | Entro |
|-----|-----|-----|
|     |     |     |
