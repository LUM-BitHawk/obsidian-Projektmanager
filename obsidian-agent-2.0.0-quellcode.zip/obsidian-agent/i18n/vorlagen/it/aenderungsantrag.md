---
typ: aenderungsantrag
titel: {{title}}
projekt: {{projekt}}
datum: {{date}}
status: beantragt
antragsteller:
tags: [hermes, aenderung]
---
# Richiesta di modifica: {{title}}

## Descrizione della modifica

## Motivazione

## Ripercussioni
| Ambito | Ripercussione |
|---|---|
| Obiettivi / portata | |
| Costi | |
| Scadenze | |
| Rischi | |

## Varianti

## Richiesta al comitato di progetto

## Decisione
- 
