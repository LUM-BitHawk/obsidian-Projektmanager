---
typ: jourfixe
titel: {{title}}
serie: {{serie}}
datum: {{datum}}
projekt: {{projekt}}
moderation: {{moderation}}
teilnehmer: {{teilnehmer}}
naechster_termin: {{naechster_termin}}
tags: [jourfixe]
---
# {{title}}

**Data:** {{datum}} · **Moderazione:** {{moderation}} · **Prossima seduta:** {{naechster_termin}}
**Partecipanti:** {{teilnehmer}}

## Ordine del giorno
{{agenda}}

## Pendenze aperte (stato prima della seduta)
{{pendenzen}}

## Informazioni / discussione
- 

## Deliberazioni
> Contrassegnare le deliberazioni con `#entscheid`, così compaiono nel registro delle decisioni.

- 

## Nuove pendenze
> Registrare le nuove pendenze in Obsidian-Agent sotto *Riunione periodica*. Compaiono poi anche sotto Task e Oggi.
