---
typ: schlussbeurteilung
titel: {{title}}
projekt: {{projekt}}
datum: {{date}}
tags: [hermes, abschluss]
---
# Valutazione finale del progetto: {{title}}

## Raggiungimento degli obiettivi
| Obiettivo | Raggiunto | Osservazione |
|---|---|---|
| | | |

## Confronto pianificato/effettivo delle pietre miliari
{{auto_meilensteine}}

## Costi e onere (pianificato/effettivo)
| Voce | Pianificato | Effettivo | Differenza |
|---|---|---|---|
| | | | |

## Esperienze (lessons learned)
- 

## Pendenze e misure dopo la chiusura del progetto
- 

## Richiesta di chiusura del progetto
- 
