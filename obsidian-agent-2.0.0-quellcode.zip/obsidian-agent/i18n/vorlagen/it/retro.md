---
typ: retro
titel: {{title}}
projekt: {{projekt}}
pi: {{pi}}
team: {{team}}
iteration: {{iteration}}
datum: {{date}}
tags: [safe, retro]
---
# Retrospettiva: {{title}}
**PI:** {{pi}} · **Team:** {{team}} · **Iterazione:** {{iteration}}

## Cosa è andato bene?
- 

## Cosa non è andato bene?
- 

## Cosa miglioriamo? (al massimo due misure)
- [ ] 

## Impedimenti per Inspect & Adapt
> Contrassegnare gli impedimenti trasversali ai team con `#blocker`.

- 
