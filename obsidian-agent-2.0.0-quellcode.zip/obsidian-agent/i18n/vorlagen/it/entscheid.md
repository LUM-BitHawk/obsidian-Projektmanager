---
typ: entscheid
titel: {{title}}
projekt: {{projekt}}
datum: {{datum}}
gremium: {{gremium}}
entscheid_durch: {{entscheid_durch}}
status: {{status}}
meilenstein: {{meilenstein}}
pi: {{pi}}
tags: [entscheid]
---
# Decisione: {{title}}

**Data:** {{datum}} · **Organo:** {{gremium}} · **Deciso da:** {{entscheid_durch}}

## Richiesta / situazione iniziale
{{antrag}}

## Decisione
{{entscheid}}

## Condizioni / conseguenze
- 
