---
typ: meeting
titel: {{title}}
projekt: {{projekt}}
datum: {{date}}
teilnehmende:
tags: [meeting]
---
# Riunione: {{title}}
**Data:** {{date}} · **Progetto:** {{projekt}}

## Partecipanti
- 

## Ordine del giorno
1. 

## Discusso / risultati
- 

## Decisioni
> Contrassegnare ogni decisione su una riga separata con `#entscheid`, i rischi con `#risiko`, i bloccanti con `#blocker`.

- 

## Compiti
| Cosa | Chi | Entro |
|-----|-----|-----|
|     |     |     |
