---
typ: pi
titel: {{title}}
projekt: {{projekt}}
art: {{art}}
start: {{start}}
ende: {{ende}}
iterationen: {{iterationen}}
iteration_wochen: {{iteration_wochen}}
status: {{status}}
tags: [safe, pi]
---
# {{title}}{{art_titel}}

**Periodo:** dal {{start}} al {{ende}} · **Iterazioni:** {{iterationen}} da {{iteration_wochen}} settimane (l'ultima è l'iterazione IP)

## Iterazioni
{{iterationen_tabelle}}

## Obiettivi PI (richiede il plugin della community Dataview)
```dataview
TABLE team, committed, bv_geplant AS "BV pianificato", bv_ist AS "BV raggiunto", status
FROM "{{ordner}}"
WHERE typ = "pi_objective"
SORT team ASC, committed DESC
```

## ART Planning Board
[[{{board}}|ART Planning Board (canvas)]]

## Rischi (ROAM)
```dataview
TABLE wahrscheinlichkeit, auswirkung, roam, verantwortlich
WHERE typ = "risiko" AND pi = "{{title}}"
```

## Retrospettive di questo PI
```dataview
TABLE team, iteration
WHERE typ = "retro" AND pi = "{{title}}"
SORT iteration ASC
```

## Note sul PI Planning
- Visione / contesto di business:
- Feature principali:
- Voto di fiducia:
