---
typ: statusbericht
titel: {{title}}
projekt: {{projekt}}
datum: {{date}}
phase: {{auto_phase}}
ampel_gesamt: gruen
ampel_termine: gruen
ampel_kosten: gruen
ampel_qualitaet: gruen
tags: [hermes, statusbericht]
---
# Rapporto sullo stato del progetto: {{title}}
**Stato al:** {{date}} · **Fase attuale:** {{auto_phase}}

## Valutazione complessiva
| Ambito | Semaforo (verde / giallo / rosso) | Commento |
|---|---|---|
| Complessivo | verde | |
| Scadenze | verde | |
| Costi | verde | |
| Qualità / prestazioni | verde | |

## Risultati raggiunti dall'ultimo rapporto
- 

## Pietre miliari
{{auto_meilensteine}}

## Rischi aperti
{{auto_risiken}}

## Decisioni degli ultimi 30 giorni
{{auto_entscheide}}

## Richieste al comitato di progetto
- 

## Prossimi passi
- 
