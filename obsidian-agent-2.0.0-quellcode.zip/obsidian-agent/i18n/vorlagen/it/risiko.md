---
typ: risiko
titel: {{title}}
projekt: {{projekt}}
pi: {{pi}}
wahrscheinlichkeit: {{wahrscheinlichkeit}}
auswirkung: {{auswirkung}}
roam: {{roam}}
verantwortlich: {{verantwortlich}}
faellig: {{faellig}}
erfasst: {{date}}
task:
tags: [risiko]
---
# Rischio: {{title}}

## Descrizione (causa, evento, impatto)
{{beschreibung}}

## Misura
{{massnahme}}

## ROAM
| Stato | Significato |
|---|---|
| Resolved | Non è più un rischio, annotare la motivazione |
| Owned | Una persona se ne occupa |
| Accepted | Accettato consapevolmente |
| Mitigated | Le misure riducono probabilità o impatto |

## Cronologia
- {{date}}: rischio registrato
