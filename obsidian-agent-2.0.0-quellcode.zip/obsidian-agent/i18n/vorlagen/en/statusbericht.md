---
typ: statusbericht
titel: {{title}}
projekt: {{projekt}}
datum: {{date}}
phase: {{auto_phase}}
ampel_gesamt: gruen
ampel_termine: gruen
ampel_kosten: gruen
ampel_qualitaet: gruen
tags: [hermes, statusbericht]
---
# Project status report: {{title}}
**As of:** {{date}} · **Current phase:** {{auto_phase}}

## Overall assessment
| Area | Status (green / yellow / red) | Comment |
|---|---|---|
| Overall | green | |
| Deadlines | green | |
| Costs | green | |
| Quality / performance | green | |

## Results achieved since the last report
- 

## Milestones
{{auto_meilensteine}}

## Open risks
{{auto_risiken}}

## Decisions of the last 30 days
{{auto_entscheide}}

## Requests to the steering committee
- 

## Next steps
- 
