---
typ: projektmanagementplan
titel: {{title}}
projekt: {{projekt}}
version: 0.1
status: in_arbeit
erstellt: {{date}}
tags: [hermes, pmp]
---
# Project management plan: {{title}}

## 1. Initial situation and objectives
- Project objectives (from the execution order):
- Scope:

## 2. Approach
- Approach (classic, agile, SAFe):
- Phases and releases:

## 3. Project organisation
| Role | Person |
|---|---|
| Project sponsor | |
| Steering committee | |
| Project manager | |
| User representative | |
| Quality and risk manager | |

## 4. Milestones and deadlines
{{auto_meilensteine}}

## 5. Costs and resources
| Phase | Staff effort | Material costs |
|---|---|---|
| | | |

## 6. Communication and reporting
- Project status report: monthly to the steering committee
- Steering committee meetings:

## 7. Risks
{{auto_risiken}}

## 8. Quality and changes
- Change procedure: change request, decision by the steering committee
