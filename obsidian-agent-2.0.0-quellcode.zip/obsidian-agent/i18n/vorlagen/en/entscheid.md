---
typ: entscheid
titel: {{title}}
projekt: {{projekt}}
datum: {{datum}}
gremium: {{gremium}}
entscheid_durch: {{entscheid_durch}}
status: {{status}}
meilenstein: {{meilenstein}}
pi: {{pi}}
tags: [entscheid]
---
# Decision: {{title}}

**Date:** {{datum}} · **Body:** {{gremium}} · **Decided by:** {{entscheid_durch}}

## Request / initial situation
{{antrag}}

## Decision
{{entscheid}}

## Conditions / consequences
- 
