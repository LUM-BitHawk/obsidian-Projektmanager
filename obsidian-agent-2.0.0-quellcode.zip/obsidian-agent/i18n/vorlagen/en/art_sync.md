---
typ: art_sync
titel: {{title}}
projekt: {{projekt}}
pi: {{pi}}
datum: {{date}}
tags: [meeting, safe, art-sync]
---
# ART Sync: {{title}}
**Date:** {{date}} · **PI:** {{pi}}

## Progress per team
| Team | Feature progress | Dependencies | Blockers |
|---|---|---|---|
| | | | |

## Blockers and risks
> `#blocker` for impediments, `#risiko` for risks.

- 

## Decisions
- 

## Action items
| What | Who | By |
|-----|-----|-----|
|     |     |     |
