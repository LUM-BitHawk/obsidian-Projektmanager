---
typ: meilenstein
titel: {{title}}
ms_id: {{ms_id}}
projekt: {{projekt}}
methode: {{methode}}
phase: {{phase}}
reihenfolge: {{reihenfolge}}
kern: {{kern}}
plan: {{plan}}
ist:
status: geplant
entscheid_durch: {{entscheid_durch}}
entscheid:
tags: [meilenstein, hermes]
---
# {{title}}

**Phase:** {{phase_name}} · **Decided by:** {{entscheid_durch}}

## Checkpoints for the approval
> Typical outcomes according to HERMES 2022. Adapt to the scenario and the size of the project.

{{pruefpunkte}}

## Basis for the decision
- 

## Decision
- Date:
- Decision:
- Conditions:
