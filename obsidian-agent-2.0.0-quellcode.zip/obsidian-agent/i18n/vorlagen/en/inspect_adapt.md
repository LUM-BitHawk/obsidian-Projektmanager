---
typ: inspect_adapt
titel: {{title}}
projekt: {{projekt}}
pi: {{pi}}
datum: {{date}}
tags: [safe, inspect-adapt]
---
# Inspect & Adapt: {{pi}}

## 1. PI system demo
- 

## 2. Quantitative and qualitative measurement
{{predictability}}

> Target range for predictability according to SAFe: 80 to 100 %.

## 3. Retrospective
### Team retrospectives in this PI
```dataview
TABLE team, iteration
WHERE typ = "retro" AND pi = "{{pi}}"
SORT iteration ASC
```

### Recurring patterns (systemic impediments)
- 

## 4. Problem-solving workshop
### Agreed problem

### Root cause analysis (fishbone, 5 whys)
- People:
- Processes:
- Tools:
- Organisation:
- Environment:

### Main root cause (Pareto)

### Solution ideas and vote

## 5. Improvement backlog for the next PI planning
- [ ] 
