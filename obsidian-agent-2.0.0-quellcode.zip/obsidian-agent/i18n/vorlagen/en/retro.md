---
typ: retro
titel: {{title}}
projekt: {{projekt}}
pi: {{pi}}
team: {{team}}
iteration: {{iteration}}
datum: {{date}}
tags: [safe, retro]
---
# Retrospective: {{title}}
**PI:** {{pi}} · **Team:** {{team}} · **Iteration:** {{iteration}}

## What went well?
- 

## What did not go well?
- 

## What will we improve? (two measures at most)
- [ ] 

## Impediments for Inspect & Adapt
> Tag cross-team impediments with `#blocker`.

- 
