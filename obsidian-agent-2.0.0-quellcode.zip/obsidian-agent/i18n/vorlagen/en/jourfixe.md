---
typ: jourfixe
titel: {{title}}
serie: {{serie}}
datum: {{datum}}
projekt: {{projekt}}
moderation: {{moderation}}
teilnehmer: {{teilnehmer}}
naechster_termin: {{naechster_termin}}
tags: [jourfixe]
---
# {{title}}

**Date:** {{datum}} · **Moderation:** {{moderation}} · **Next meeting:** {{naechster_termin}}
**Participants:** {{teilnehmer}}

## Agenda
{{agenda}}

## Open action items (before the meeting)
{{pendenzen}}

## Information / discussion
- 

## Resolutions
> Tag resolutions with `#entscheid`, then they appear in the decision log.

- 

## New action items
> Record new action items in Obsidian-Agent under *Recurring meeting*. They then also appear under Tasks and Today.
