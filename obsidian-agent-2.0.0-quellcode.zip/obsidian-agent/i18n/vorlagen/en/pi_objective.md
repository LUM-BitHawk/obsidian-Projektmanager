---
typ: pi_objective
titel: {{title}}
projekt: {{projekt}}
pi: {{pi}}
team: {{team}}
committed: {{committed}}
bv_geplant: {{bv_geplant}}
bv_ist:
status: geplant
tags: [safe, pi-objective]
---
# {{title}}

**PI:** {{pi}} · **Team:** {{team}} · **Committed:** {{committed}} · **Planned business value:** {{bv_geplant}}

## Description (SMART)
{{beschreibung}}

## Related features
- 

## Result at the end of the PI
- Business value achieved (rated by the business owners):
- Remark:
