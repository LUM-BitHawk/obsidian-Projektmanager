---
typ: meeting
titel: {{title}}
projekt: {{projekt}}
datum: {{date}}
teilnehmende:
tags: [meeting]
---
# Meeting: {{title}}
**Date:** {{date}} · **Project:** {{projekt}}

## Participants
- 

## Agenda
1. 

## Discussed / results
- 

## Decisions
> Tag each decision as a separate line with `#entscheid`, risks with `#risiko`, blockers with `#blocker`.

- 

## Tasks
| What | Who | By |
|-----|-----|-----|
|     |     |     |
