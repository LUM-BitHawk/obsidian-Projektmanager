---
typ: risiko
titel: {{title}}
projekt: {{projekt}}
pi: {{pi}}
wahrscheinlichkeit: {{wahrscheinlichkeit}}
auswirkung: {{auswirkung}}
roam: {{roam}}
verantwortlich: {{verantwortlich}}
faellig: {{faellig}}
erfasst: {{date}}
task:
tags: [risiko]
---
# Risk: {{title}}

## Description (cause, event, impact)
{{beschreibung}}

## Measure
{{massnahme}}

## ROAM
| Status | Meaning |
|---|---|
| Resolved | No longer a risk, record the reason |
| Owned | Someone takes care of it |
| Accepted | Knowingly accepted |
| Mitigated | Measures reduce probability or impact |

## History
- {{date}}: risk recorded
