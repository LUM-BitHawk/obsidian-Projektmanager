---
typ: projekt
titel: {{title}}
projekt: {{title}}
kunde: {{kunde}}
methode: {{methode}}
status: aktiv
erstellt: {{date}}
tags: [projekt]
---
# Project: {{title}}

{{beschreibung}}

## Structure
{{struktur}}

## Open tasks
```dataview
TABLE start, ende, status, prioritaet, verantwortlich
FROM "{{root}}"
WHERE typ = "task" AND status != "erledigt"
SORT ende ASC
```

## Milestones
```dataview
TABLE phase, plan, ist, status, entscheid_durch
FROM "{{root}}"
WHERE typ = "meilenstein"
SORT reihenfolge ASC
```

## Planning intervals
```dataview
TABLE art, start, ende, status
FROM "{{root}}"
WHERE typ = "pi"
SORT start DESC
```

## Open risks (ROAM)
```dataview
TABLE wahrscheinlichkeit, auswirkung, roam, verantwortlich, faellig
FROM "{{root}}"
WHERE typ = "risiko" AND roam != "resolved"
```

## Decision log
```dataview
TABLE datum, gremium, entscheid_durch, status
FROM "{{root}}"
WHERE typ = "entscheid"
SORT datum DESC
```

## Tagged decisions, risks and blockers
```dataview
TABLE WITHOUT ID L.text AS "Entry", file.link AS "Note"
FROM "{{root}}"
FLATTEN file.lists AS L
WHERE contains(L.tags, "#entscheid") OR contains(L.tags, "#risiko") OR contains(L.tags, "#blocker")
```

> The tables require the Dataview community plugin.
