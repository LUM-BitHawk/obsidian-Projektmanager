---
typ: schlussbeurteilung
titel: {{title}}
projekt: {{projekt}}
datum: {{date}}
tags: [hermes, abschluss]
---
# Project closure assessment: {{title}}

## Achievement of objectives
| Objective | Achieved | Remark |
|---|---|---|
| | | |

## Target/actual comparison of milestones
{{auto_meilensteine}}

## Costs and effort (target/actual)
| Item | Target | Actual | Difference |
|---|---|---|---|
| | | | |

## Lessons learned
- 

## Open action items and measures after project closure
- 

## Request for project closure
- 
