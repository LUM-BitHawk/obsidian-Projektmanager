---
typ: readme
projekt: {{projekt}}
ordner: {{ordner}}
erstellt: {{date}}
tags: [readme]
---
# {{titel}}

## Purpose of this folder
{{zweck}}

## Contents
```dataview
LIST
FROM "{{pfad}}"
WHERE file.name != this.file.name
SORT file.mtime DESC
```
