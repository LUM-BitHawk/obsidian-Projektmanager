---
typ: projektausschuss
titel: {{title}}
projekt: {{projekt}}
datum: {{date}}
teilnehmende:
tags: [meeting, projektausschuss]
---
# Steering committee: {{title}}
**Date:** {{date}} · **Project:** {{projekt}} · **Current phase:** {{auto_phase}}

## Participants
- 

## Agenda
1. Project status and milestones
2. Risks
3. Requests and decisions
4. Any other business

## Project status
{{auto_meilensteine}}

## Risks
> Tag new risks with `#risiko`, blockers with `#blocker`.

{{auto_risiken}}

## Decisions
> Tag each decision as a separate line with `#entscheid`. It then appears in the decision log.

- 

## Tasks
| What | Who | By |
|-----|-----|-----|
|     |     |     |
