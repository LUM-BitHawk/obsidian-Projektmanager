---
typ: person
titel: {{title}}
kuerzel: {{kuerzel}}
rolle: {{rolle}}
team: {{team}}
organisation: {{organisation}}
email: {{email}}
telefon: {{telefon}}
einfluss: {{einfluss}}
interesse: {{interesse}}
vertretung: {{vertretung}}
tags: [person]
---
# {{title}}

| Field | Value |
|------|------|
| Role | {{rolle}} |
| Team / organisation | {{team}} {{organisation}} |
| E-mail | {{email}} |
| Phone | {{telefon}} |
| Influence / interest | {{einfluss}} / {{interesse}} |
| Deputy | {{vertretung}} |

## Responsibilities in the project
- 

## Expectations and concerns
- 

## Latest discussion points
- 
