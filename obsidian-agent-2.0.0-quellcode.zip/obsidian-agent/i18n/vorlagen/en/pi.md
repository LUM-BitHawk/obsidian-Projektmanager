---
typ: pi
titel: {{title}}
projekt: {{projekt}}
art: {{art}}
start: {{start}}
ende: {{ende}}
iterationen: {{iterationen}}
iteration_wochen: {{iteration_wochen}}
status: {{status}}
tags: [safe, pi]
---
# {{title}}{{art_titel}}

**Period:** {{start}} to {{ende}} · **Iterations:** {{iterationen}} of {{iteration_wochen}} weeks (the last one is the IP iteration)

## Iterations
{{iterationen_tabelle}}

## PI objectives (requires the Dataview community plugin)
```dataview
TABLE team, committed, bv_geplant AS "Planned BV", bv_ist AS "Achieved BV", status
FROM "{{ordner}}"
WHERE typ = "pi_objective"
SORT team ASC, committed DESC
```

## ART Planning Board
[[{{board}}|ART Planning Board (canvas)]]

## Risks (ROAM)
```dataview
TABLE wahrscheinlichkeit, auswirkung, roam, verantwortlich
WHERE typ = "risiko" AND pi = "{{title}}"
```

## Retrospectives of this PI
```dataview
TABLE team, iteration
WHERE typ = "retro" AND pi = "{{title}}"
SORT iteration ASC
```

## PI planning notes
- Vision / business context:
- Top features:
- Confidence vote:
