---
typ: projektmanagementplan
titel: {{title}}
projekt: {{projekt}}
version: 0.1
status: in_arbeit
erstellt: {{date}}
tags: [hermes, pmp]
---
# Projektmanagementplan: {{title}}

## 1. Ausgangslage und Ziele
- Projektziele (aus dem Durchführungsauftrag):
- Abgrenzung:

## 2. Vorgehen
- Vorgehensweise (klassisch, agil, SAFe):
- Phasen und Releases:

## 3. Projektorganisation
| Rolle | Person |
|---|---|
| Auftraggeber/in | |
| Projektausschuss | |
| Projektleiter/in | |
| Anwendervertreter/in | |
| Qualitäts- und Risikomanager/in | |

## 4. Meilensteine und Termine
{{auto_meilensteine}}

## 5. Kosten und Ressourcen
| Phase | Personalaufwand | Sachkosten |
|---|---|---|
| | | |

## 6. Kommunikation und Reporting
- Projektstatusbericht: monatlich an den Projektausschuss
- Sitzungen Projektausschuss:

## 7. Risiken
{{auto_risiken}}

## 8. Qualität und Änderungen
- Änderungsverfahren: Änderungsantrag, Entscheid durch den Projektausschuss
