---
typ: retro
titel: {{title}}
projekt: {{projekt}}
pi: {{pi}}
team: {{team}}
iteration: {{iteration}}
datum: {{date}}
tags: [safe, retro]
---
# Retrospektive: {{title}}
**PI:** {{pi}} · **Team:** {{team}} · **Iteration:** {{iteration}}

## Was lief gut?
- 

## Was lief nicht gut?
- 

## Was verbessern wir? (höchstens zwei Massnahmen)
- [ ] 

## Hindernisse für Inspect & Adapt
> Teamübergreifende Hindernisse mit `#blocker` markieren.

- 
