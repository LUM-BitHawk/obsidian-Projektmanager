---
typ: entscheid
titel: {{title}}
projekt: {{projekt}}
datum: {{datum}}
gremium: {{gremium}}
entscheid_durch: {{entscheid_durch}}
status: {{status}}
meilenstein: {{meilenstein}}
pi: {{pi}}
tags: [entscheid]
---
# Entscheid: {{title}}

**Datum:** {{datum}} · **Gremium:** {{gremium}} · **Entscheid durch:** {{entscheid_durch}}

## Antrag / Ausgangslage
{{antrag}}

## Entscheid
{{entscheid}}

## Auflagen / Konsequenzen
- 
