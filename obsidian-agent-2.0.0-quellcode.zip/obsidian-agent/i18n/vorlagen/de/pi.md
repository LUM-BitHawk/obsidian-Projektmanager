---
typ: pi
titel: {{title}}
projekt: {{projekt}}
art: {{art}}
start: {{start}}
ende: {{ende}}
iterationen: {{iterationen}}
iteration_wochen: {{iteration_wochen}}
status: {{status}}
tags: [safe, pi]
---
# {{title}}{{art_titel}}

**Zeitraum:** {{start}} bis {{ende}} · **Iterationen:** {{iterationen}} à {{iteration_wochen}} Wochen (die letzte ist die IP-Iteration)

## Iterationen
{{iterationen_tabelle}}

## PI Objectives (benötigt das Community-Plugin Dataview)
```dataview
TABLE team, committed, bv_geplant AS "BV geplant", bv_ist AS "BV erreicht", status
FROM "{{ordner}}"
WHERE typ = "pi_objective"
SORT team ASC, committed DESC
```

## ART Planning Board
[[{{board}}|ART Planning Board (Canvas)]]

## Risiken (ROAM)
```dataview
TABLE wahrscheinlichkeit, auswirkung, roam, verantwortlich
WHERE typ = "risiko" AND pi = "{{title}}"
```

## Retrospektiven dieses PI
```dataview
TABLE team, iteration
WHERE typ = "retro" AND pi = "{{title}}"
SORT iteration ASC
```

## Notizen zum PI Planning
- Vision / Business Context:
- Top-Features:
- Confidence Vote:
