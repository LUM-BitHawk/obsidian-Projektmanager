---
typ: statusbericht
titel: {{title}}
projekt: {{projekt}}
datum: {{date}}
phase: {{auto_phase}}
ampel_gesamt: gruen
ampel_termine: gruen
ampel_kosten: gruen
ampel_qualitaet: gruen
tags: [hermes, statusbericht]
---
# Projektstatusbericht: {{title}}
**Stand:** {{date}} · **Aktuelle Phase:** {{auto_phase}}

## Gesamtbeurteilung
| Bereich | Ampel (grün / gelb / rot) | Kommentar |
|---|---|---|
| Gesamt | grün | |
| Termine | grün | |
| Kosten | grün | |
| Qualität / Leistung | grün | |

## Erreichte Ergebnisse seit dem letzten Bericht
- 

## Meilensteine
{{auto_meilensteine}}

## Offene Risiken
{{auto_risiken}}

## Entscheide der letzten 30 Tage
{{auto_entscheide}}

## Anträge an den Projektausschuss
- 

## Nächste Schritte
- 
