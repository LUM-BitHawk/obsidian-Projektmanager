---
typ: risiko
titel: {{title}}
projekt: {{projekt}}
pi: {{pi}}
wahrscheinlichkeit: {{wahrscheinlichkeit}}
auswirkung: {{auswirkung}}
roam: {{roam}}
verantwortlich: {{verantwortlich}}
faellig: {{faellig}}
erfasst: {{date}}
task:
tags: [risiko]
---
# Risiko: {{title}}

## Beschreibung (Ursache, Ereignis, Auswirkung)
{{beschreibung}}

## Massnahme
{{massnahme}}

## ROAM
| Status | Bedeutung |
|---|---|
| Resolved | Kein Risiko mehr, Begründung festhalten |
| Owned | Eine Person kümmert sich darum |
| Accepted | Wird bewusst in Kauf genommen |
| Mitigated | Massnahmen reduzieren Wahrscheinlichkeit oder Auswirkung |

## Verlauf
- {{date}}: Risiko erfasst
