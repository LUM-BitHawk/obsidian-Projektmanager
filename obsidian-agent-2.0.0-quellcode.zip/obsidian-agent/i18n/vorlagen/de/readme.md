---
typ: readme
projekt: {{projekt}}
ordner: {{ordner}}
erstellt: {{date}}
tags: [readme]
---
# {{titel}}

## Zweck dieses Ordners
{{zweck}}

## Inhalt
```dataview
LIST
FROM "{{pfad}}"
WHERE file.name != this.file.name
SORT file.mtime DESC
```
