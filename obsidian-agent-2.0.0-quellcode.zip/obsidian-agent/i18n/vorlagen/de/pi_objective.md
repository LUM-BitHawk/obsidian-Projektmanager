---
typ: pi_objective
titel: {{title}}
projekt: {{projekt}}
pi: {{pi}}
team: {{team}}
committed: {{committed}}
bv_geplant: {{bv_geplant}}
bv_ist:
status: geplant
tags: [safe, pi-objective]
---
# {{title}}

**PI:** {{pi}} · **Team:** {{team}} · **Committed:** {{committed}} · **Business Value geplant:** {{bv_geplant}}

## Beschreibung (SMART)
{{beschreibung}}

## Zugehörige Features
- 

## Ergebnis am Ende des PI
- Business Value erreicht (Bewertung durch die Business Owner):
- Bemerkung:
