---
typ: aenderungsantrag
titel: {{title}}
projekt: {{projekt}}
datum: {{date}}
status: beantragt
antragsteller:
tags: [hermes, aenderung]
---
# Änderungsantrag: {{title}}

## Beschreibung der Änderung

## Begründung

## Auswirkungen
| Bereich | Auswirkung |
|---|---|
| Ziele / Umfang | |
| Kosten | |
| Termine | |
| Risiken | |

## Varianten

## Antrag an den Projektausschuss

## Entscheid
- 
