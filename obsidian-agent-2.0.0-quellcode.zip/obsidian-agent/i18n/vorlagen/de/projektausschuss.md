---
typ: projektausschuss
titel: {{title}}
projekt: {{projekt}}
datum: {{date}}
teilnehmende:
tags: [meeting, projektausschuss]
---
# Projektausschuss: {{title}}
**Datum:** {{date}} · **Projekt:** {{projekt}} · **Aktuelle Phase:** {{auto_phase}}

## Teilnehmende
- 

## Traktanden
1. Projektstatus und Meilensteine
2. Risiken
3. Anträge und Entscheide
4. Varia

## Projektstatus
{{auto_meilensteine}}

## Risiken
> Neue Risiken mit `#risiko` markieren, Blocker mit `#blocker`.

{{auto_risiken}}

## Entscheide
> Jeden Entscheid als eigene Zeile mit `#entscheid` markieren. Er erscheint dann im Entscheid-Log.

- 

## Aufgaben
| Was | Wer | Bis |
|-----|-----|-----|
|     |     |     |
