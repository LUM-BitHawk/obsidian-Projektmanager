---
typ: jourfixe
titel: {{title}}
serie: {{serie}}
datum: {{datum}}
projekt: {{projekt}}
moderation: {{moderation}}
teilnehmer: {{teilnehmer}}
naechster_termin: {{naechster_termin}}
tags: [jourfixe]
---
# {{title}}

**Datum:** {{datum}} · **Moderation:** {{moderation}} · **Nächster Termin:** {{naechster_termin}}
**Teilnehmende:** {{teilnehmer}}

## Traktanden
{{agenda}}

## Offene Pendenzen (Stand vor der Sitzung)
{{pendenzen}}

## Informationen / Diskussion
- 

## Beschlüsse
> Beschlüsse mit `#entscheid` markieren, dann erscheinen sie im Entscheid-Log.

- 

## Neue Pendenzen
> Neue Pendenzen im Obsidian-Agent unter *Jour Fixe* erfassen. Sie erscheinen dann auch unter Tasks und Heute.
