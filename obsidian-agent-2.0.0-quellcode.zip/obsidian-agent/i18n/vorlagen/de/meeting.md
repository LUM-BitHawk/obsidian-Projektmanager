---
typ: meeting
titel: {{title}}
projekt: {{projekt}}
datum: {{date}}
teilnehmende:
tags: [meeting]
---
# Meeting: {{title}}
**Datum:** {{date}} · **Projekt:** {{projekt}}

## Teilnehmende
- 

## Traktanden
1. 

## Besprochen / Ergebnisse
- 

## Entscheide
> Jeden Entscheid als eigene Zeile mit `#entscheid` markieren, Risiken mit `#risiko`, Blocker mit `#blocker`.

- 

## Aufgaben
| Was | Wer | Bis |
|-----|-----|-----|
|     |     |     |
