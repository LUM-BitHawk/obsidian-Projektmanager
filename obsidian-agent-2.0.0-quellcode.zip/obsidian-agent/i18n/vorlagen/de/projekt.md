---
typ: projekt
titel: {{title}}
projekt: {{title}}
kunde: {{kunde}}
methode: {{methode}}
status: aktiv
erstellt: {{date}}
tags: [projekt]
---
# Projekt: {{title}}

{{beschreibung}}

## Struktur
{{struktur}}

## Offene Tasks
```dataview
TABLE start, ende, status, prioritaet, verantwortlich
FROM "{{root}}"
WHERE typ = "task" AND status != "erledigt"
SORT ende ASC
```

## Meilensteine
```dataview
TABLE phase, plan, ist, status, entscheid_durch
FROM "{{root}}"
WHERE typ = "meilenstein"
SORT reihenfolge ASC
```

## Planning Intervals
```dataview
TABLE art, start, ende, status
FROM "{{root}}"
WHERE typ = "pi"
SORT start DESC
```

## Offene Risiken (ROAM)
```dataview
TABLE wahrscheinlichkeit, auswirkung, roam, verantwortlich, faellig
FROM "{{root}}"
WHERE typ = "risiko" AND roam != "resolved"
```

## Entscheid-Log
```dataview
TABLE datum, gremium, entscheid_durch, status
FROM "{{root}}"
WHERE typ = "entscheid"
SORT datum DESC
```

## Markierte Entscheide, Risiken und Blocker
```dataview
TABLE WITHOUT ID L.text AS "Eintrag", file.link AS "Notiz"
FROM "{{root}}"
FLATTEN file.lists AS L
WHERE contains(L.tags, "#entscheid") OR contains(L.tags, "#risiko") OR contains(L.tags, "#blocker")
```

> Die Tabellen benötigen das Community-Plugin Dataview.
