---
typ: art_sync
titel: {{title}}
projekt: {{projekt}}
pi: {{pi}}
datum: {{date}}
tags: [meeting, safe, art-sync]
---
# ART Sync: {{title}}
**Datum:** {{date}} · **PI:** {{pi}}

## Fortschritt je Team
| Team | Fortschritt Features | Abhängigkeiten | Blocker |
|---|---|---|---|
| | | | |

## Blocker und Risiken
> `#blocker` für Hindernisse, `#risiko` für Risiken.

- 

## Entscheide
- 

## Aktionspunkte
| Was | Wer | Bis |
|-----|-----|-----|
|     |     |     |
