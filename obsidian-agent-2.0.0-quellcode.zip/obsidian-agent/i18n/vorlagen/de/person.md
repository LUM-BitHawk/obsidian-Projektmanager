---
typ: person
titel: {{title}}
kuerzel: {{kuerzel}}
rolle: {{rolle}}
team: {{team}}
organisation: {{organisation}}
email: {{email}}
telefon: {{telefon}}
einfluss: {{einfluss}}
interesse: {{interesse}}
vertretung: {{vertretung}}
tags: [person]
---
# {{title}}

| Feld | Wert |
|------|------|
| Rolle | {{rolle}} |
| Team / Organisation | {{team}} {{organisation}} |
| E-Mail | {{email}} |
| Telefon | {{telefon}} |
| Einfluss / Interesse | {{einfluss}} / {{interesse}} |
| Vertretung | {{vertretung}} |

## Verantwortlichkeiten im Projekt
- 

## Erwartungen und Anliegen
- 

## Letzte Gesprächspunkte
- 
