---
typ: schlussbeurteilung
titel: {{title}}
projekt: {{projekt}}
datum: {{date}}
tags: [hermes, abschluss]
---
# Projektschlussbeurteilung: {{title}}

## Zielerreichung
| Ziel | Erreicht | Bemerkung |
|---|---|---|
| | | |

## Soll/Ist-Vergleich Meilensteine
{{auto_meilensteine}}

## Kosten und Aufwand (Soll/Ist)
| Position | Soll | Ist | Differenz |
|---|---|---|---|
| | | | |

## Erfahrungen (Lessons Learned)
- 

## Offene Pendenzen und Massnahmen nach Projektabschluss
- 

## Antrag Projektabschluss
- 
