---
typ: meilenstein
titel: {{title}}
ms_id: {{ms_id}}
projekt: {{projekt}}
methode: {{methode}}
phase: {{phase}}
reihenfolge: {{reihenfolge}}
kern: {{kern}}
plan: {{plan}}
ist:
status: geplant
entscheid_durch: {{entscheid_durch}}
entscheid:
tags: [meilenstein, hermes]
---
# {{title}}

**Phase:** {{phase_name}} · **Entscheid durch:** {{entscheid_durch}}

## Prüfpunkte für die Freigabe
> Typische Ergebnisse nach HERMES 2022. An das Szenario und die Projektgrösse anpassen.

{{pruefpunkte}}

## Entscheidungsgrundlagen
- 

## Entscheid
- Datum:
- Entscheid:
- Auflagen:
