---
typ: inspect_adapt
titel: {{title}}
projekt: {{projekt}}
pi: {{pi}}
datum: {{date}}
tags: [safe, inspect-adapt]
---
# Inspect & Adapt: {{pi}}

## 1. PI System Demo
- 

## 2. Quantitative und qualitative Messung
{{predictability}}

> Zielbereich der Predictability nach SAFe: 80 bis 100 %.

## 3. Retrospektive
### Retrospektiven der Teams in diesem PI
```dataview
TABLE team, iteration
WHERE typ = "retro" AND pi = "{{pi}}"
SORT iteration ASC
```

### Wiederkehrende Muster (Systemic Impediments)
- 

## 4. Problem-Solving-Workshop
### Vereinbartes Problem

### Ursachenanalyse (Fischgräte, 5 Why)
- Menschen:
- Prozesse:
- Werkzeuge:
- Organisation:
- Umgebung:

### Wichtigste Ursache (Pareto)

### Lösungsideen und Abstimmung

## 5. Verbesserungs-Backlog für das nächste PI Planning
- [ ] 
