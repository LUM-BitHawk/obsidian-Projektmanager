---
typ: retro
titel: {{title}}
projekt: {{projekt}}
pi: {{pi}}
team: {{team}}
iteration: {{iteration}}
datum: {{date}}
tags: [safe, retro]
---
# Rétrospective : {{title}}
**PI :** {{pi}} · **Équipe :** {{team}} · **Itération :** {{iteration}}

## Qu'est-ce qui a bien fonctionné ?
- 

## Qu'est-ce qui n'a pas bien fonctionné ?
- 

## Que voulons-nous améliorer ? (deux mesures au maximum)
- [ ] 

## Obstacles pour Inspect & Adapt
> Marquez les obstacles qui concernent plusieurs équipes avec `#blocker`.

- 
