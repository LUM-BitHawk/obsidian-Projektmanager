---
typ: schlussbeurteilung
titel: {{title}}
projekt: {{projekt}}
datum: {{date}}
tags: [hermes, abschluss]
---
# Évaluation finale du projet : {{title}}

## Atteinte des objectifs
| Objectif | Atteint | Remarque |
|---|---|---|
| | | |

## Comparaison prévu/effectif des jalons
{{auto_meilensteine}}

## Coûts et charges (prévu/effectif)
| Poste | Prévu | Effectif | Écart |
|---|---|---|---|
| | | | |

## Expériences (lessons learned)
- 

## Points en suspens et mesures après la clôture du projet
- 

## Demande de clôture du projet
- 
