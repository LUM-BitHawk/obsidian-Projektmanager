---
typ: jourfixe
titel: {{title}}
serie: {{serie}}
datum: {{datum}}
projekt: {{projekt}}
moderation: {{moderation}}
teilnehmer: {{teilnehmer}}
naechster_termin: {{naechster_termin}}
tags: [jourfixe]
---
# {{title}}

**Date :** {{datum}} · **Animation :** {{moderation}} · **Prochaine séance :** {{naechster_termin}}
**Participants :** {{teilnehmer}}

## Ordre du jour
{{agenda}}

## Points en suspens (état avant la séance)
{{pendenzen}}

## Informations / discussion
- 

## Décisions prises
> Marquez les décisions avec `#entscheid`, elles apparaissent alors dans le journal des décisions.

- 

## Nouveaux points en suspens
> Saisissez les nouveaux points en suspens dans Obsidian-Agent sous *Réunion périodique*. Ils apparaissent alors aussi sous Tâches et Aujourd'hui.
