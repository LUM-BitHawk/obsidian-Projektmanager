---
typ: risiko
titel: {{title}}
projekt: {{projekt}}
pi: {{pi}}
wahrscheinlichkeit: {{wahrscheinlichkeit}}
auswirkung: {{auswirkung}}
roam: {{roam}}
verantwortlich: {{verantwortlich}}
faellig: {{faellig}}
erfasst: {{date}}
task:
tags: [risiko]
---
# Risque : {{title}}

## Description (cause, événement, impact)
{{beschreibung}}

## Mesure
{{massnahme}}

## ROAM
| Statut | Signification |
|---|---|
| Resolved | N'est plus un risque, consigner la justification |
| Owned | Une personne s'en occupe |
| Accepted | Accepté en connaissance de cause |
| Mitigated | Des mesures réduisent la probabilité ou l'impact |

## Historique
- {{date}} : risque saisi
