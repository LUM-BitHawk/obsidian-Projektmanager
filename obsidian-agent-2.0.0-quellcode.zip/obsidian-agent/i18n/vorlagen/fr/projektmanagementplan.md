---
typ: projektmanagementplan
titel: {{title}}
projekt: {{projekt}}
version: 0.1
status: in_arbeit
erstellt: {{date}}
tags: [hermes, pmp]
---
# Plan de gestion de projet : {{title}}

## 1. Situation initiale et objectifs
- Objectifs du projet (selon le mandat d'exécution) :
- Délimitation :

## 2. Approche
- Approche (classique, agile, SAFe) :
- Phases et releases :

## 3. Organisation du projet
| Rôle | Personne |
|---|---|
| Mandant | |
| Comité de pilotage | |
| Chef de projet | |
| Représentant des utilisateurs | |
| Responsable qualité et risques | |

## 4. Jalons et délais
{{auto_meilensteine}}

## 5. Coûts et ressources
| Phase | Charge en personnel | Coûts matériels |
|---|---|---|
| | | |

## 6. Communication et rapports
- Rapport sur l'état du projet : mensuel au comité de pilotage
- Séances du comité de pilotage :

## 7. Risques
{{auto_risiken}}

## 8. Qualité et modifications
- Procédure de modification : demande de modification, décision du comité de pilotage
