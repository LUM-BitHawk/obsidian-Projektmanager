---
typ: meeting
titel: {{title}}
projekt: {{projekt}}
datum: {{date}}
teilnehmende:
tags: [meeting]
---
# Réunion : {{title}}
**Date :** {{date}} · **Projet :** {{projekt}}

## Participants
- 

## Ordre du jour
1. 

## Discussion / résultats
- 

## Décisions
> Marquez chaque décision sur une ligne séparée avec `#entscheid`, les risques avec `#risiko`, les blocages avec `#blocker`.

- 

## Tâches
| Quoi | Qui | Délai |
|-----|-----|-----|
|     |     |     |
