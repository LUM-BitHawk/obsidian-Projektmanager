---
typ: entscheid
titel: {{title}}
projekt: {{projekt}}
datum: {{datum}}
gremium: {{gremium}}
entscheid_durch: {{entscheid_durch}}
status: {{status}}
meilenstein: {{meilenstein}}
pi: {{pi}}
tags: [entscheid]
---
# Décision : {{title}}

**Date :** {{datum}} · **Organe :** {{gremium}} · **Décidé par :** {{entscheid_durch}}

## Demande / situation initiale
{{antrag}}

## Décision
{{entscheid}}

## Conditions / conséquences
- 
