---
typ: projektausschuss
titel: {{title}}
projekt: {{projekt}}
datum: {{date}}
teilnehmende:
tags: [meeting, projektausschuss]
---
# Comité de pilotage : {{title}}
**Date :** {{date}} · **Projet :** {{projekt}} · **Phase actuelle :** {{auto_phase}}

## Participants
- 

## Ordre du jour
1. État du projet et jalons
2. Risques
3. Demandes et décisions
4. Divers

## État du projet
{{auto_meilensteine}}

## Risques
> Marquez les nouveaux risques avec `#risiko`, les blocages avec `#blocker`.

{{auto_risiken}}

## Décisions
> Marquez chaque décision sur une ligne séparée avec `#entscheid`. Elle apparaît alors dans le journal des décisions.

- 

## Tâches
| Quoi | Qui | Délai |
|-----|-----|-----|
|     |     |     |
