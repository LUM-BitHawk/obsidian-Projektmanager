---
typ: statusbericht
titel: {{title}}
projekt: {{projekt}}
datum: {{date}}
phase: {{auto_phase}}
ampel_gesamt: gruen
ampel_termine: gruen
ampel_kosten: gruen
ampel_qualitaet: gruen
tags: [hermes, statusbericht]
---
# Rapport sur l'état du projet : {{title}}
**État au :** {{date}} · **Phase actuelle :** {{auto_phase}}

## Appréciation globale
| Domaine | Feu (vert / jaune / rouge) | Commentaire |
|---|---|---|
| Global | vert | |
| Délais | vert | |
| Coûts | vert | |
| Qualité / prestations | vert | |

## Résultats obtenus depuis le dernier rapport
- 

## Jalons
{{auto_meilensteine}}

## Risques ouverts
{{auto_risiken}}

## Décisions des 30 derniers jours
{{auto_entscheide}}

## Demandes au comité de pilotage
- 

## Prochaines étapes
- 
