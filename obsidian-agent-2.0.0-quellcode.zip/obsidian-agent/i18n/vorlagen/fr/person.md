---
typ: person
titel: {{title}}
kuerzel: {{kuerzel}}
rolle: {{rolle}}
team: {{team}}
organisation: {{organisation}}
email: {{email}}
telefon: {{telefon}}
einfluss: {{einfluss}}
interesse: {{interesse}}
vertretung: {{vertretung}}
tags: [person]
---
# {{title}}

| Champ | Valeur |
|------|------|
| Rôle | {{rolle}} |
| Équipe / organisation | {{team}} {{organisation}} |
| E-mail | {{email}} |
| Téléphone | {{telefon}} |
| Influence / intérêt | {{einfluss}} / {{interesse}} |
| Suppléance | {{vertretung}} |

## Responsabilités dans le projet
- 

## Attentes et préoccupations
- 

## Derniers points discutés
- 
