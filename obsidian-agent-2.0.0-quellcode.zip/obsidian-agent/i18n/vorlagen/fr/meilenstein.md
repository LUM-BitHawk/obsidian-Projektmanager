---
typ: meilenstein
titel: {{title}}
ms_id: {{ms_id}}
projekt: {{projekt}}
methode: {{methode}}
phase: {{phase}}
reihenfolge: {{reihenfolge}}
kern: {{kern}}
plan: {{plan}}
ist:
status: geplant
entscheid_durch: {{entscheid_durch}}
entscheid:
tags: [meilenstein, hermes]
---
# {{title}}

**Phase :** {{phase_name}} · **Décidé par :** {{entscheid_durch}}

## Points de contrôle pour la validation
> Résultats typiques selon HERMES 2022. À adapter au scénario et à la taille du projet.

{{pruefpunkte}}

## Bases de décision
- 

## Décision
- Date :
- Décision :
- Conditions :
