---
typ: art_sync
titel: {{title}}
projekt: {{projekt}}
pi: {{pi}}
datum: {{date}}
tags: [meeting, safe, art-sync]
---
# ART Sync : {{title}}
**Date :** {{date}} · **PI :** {{pi}}

## Avancement par équipe
| Équipe | Avancement des fonctionnalités | Dépendances | Blocages |
|---|---|---|---|
| | | | |

## Blocages et risques
> `#blocker` pour les obstacles, `#risiko` pour les risques.

- 

## Décisions
- 

## Points d'action
| Quoi | Qui | Délai |
|-----|-----|-----|
|     |     |     |
