---
typ: pi
titel: {{title}}
projekt: {{projekt}}
art: {{art}}
start: {{start}}
ende: {{ende}}
iterationen: {{iterationen}}
iteration_wochen: {{iteration_wochen}}
status: {{status}}
tags: [safe, pi]
---
# {{title}}{{art_titel}}

**Période :** {{start}} au {{ende}} · **Itérations :** {{iterationen}} de {{iteration_wochen}} semaines (la dernière est l'itération IP)

## Itérations
{{iterationen_tabelle}}

## Objectifs de PI (nécessite le plugin communautaire Dataview)
```dataview
TABLE team, committed, bv_geplant AS "VM prévue", bv_ist AS "VM atteinte", status
FROM "{{ordner}}"
WHERE typ = "pi_objective"
SORT team ASC, committed DESC
```

## ART Planning Board
[[{{board}}|ART Planning Board (canevas)]]

## Risques (ROAM)
```dataview
TABLE wahrscheinlichkeit, auswirkung, roam, verantwortlich
WHERE typ = "risiko" AND pi = "{{title}}"
```

## Rétrospectives de ce PI
```dataview
TABLE team, iteration
WHERE typ = "retro" AND pi = "{{title}}"
SORT iteration ASC
```

## Notes sur le PI Planning
- Vision / contexte métier :
- Principales fonctionnalités :
- Vote de confiance :
