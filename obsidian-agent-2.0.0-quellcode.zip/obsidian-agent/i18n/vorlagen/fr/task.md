---
typ: task
titel: {{title}}
projekt: {{projekt}}
start: {{start}}
ende: {{ende}}
status: offen
prioritaet: {{prioritaet}}
verantwortlich: {{verantwortlich}}
erstellt: {{date}}
tags: [task]
---
# {{title}}

## Description
{{beschreibung}}

## Liste de contrôle
{{checkliste}}

## Notes
