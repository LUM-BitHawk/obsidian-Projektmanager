---
typ: pi_objective
titel: {{title}}
projekt: {{projekt}}
pi: {{pi}}
team: {{team}}
committed: {{committed}}
bv_geplant: {{bv_geplant}}
bv_ist:
status: geplant
tags: [safe, pi-objective]
---
# {{title}}

**PI :** {{pi}} · **Équipe :** {{team}} · **Committed :** {{committed}} · **Valeur métier prévue :** {{bv_geplant}}

## Description (SMART)
{{beschreibung}}

## Fonctionnalités associées
- 

## Résultat à la fin du PI
- Valeur métier atteinte (évaluation par les business owners) :
- Remarque :
