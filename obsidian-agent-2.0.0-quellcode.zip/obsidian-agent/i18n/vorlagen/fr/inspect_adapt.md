---
typ: inspect_adapt
titel: {{title}}
projekt: {{projekt}}
pi: {{pi}}
datum: {{date}}
tags: [safe, inspect-adapt]
---
# Inspect & Adapt : {{pi}}

## 1. Démo système du PI
- 

## 2. Mesure quantitative et qualitative
{{predictability}}

> Plage cible de la prévisibilité selon SAFe : 80 à 100 %.

## 3. Rétrospective
### Rétrospectives des équipes dans ce PI
```dataview
TABLE team, iteration
WHERE typ = "retro" AND pi = "{{pi}}"
SORT iteration ASC
```

### Schémas récurrents (obstacles systémiques)
- 

## 4. Atelier de résolution de problèmes
### Problème convenu

### Analyse des causes (arête de poisson, 5 pourquoi)
- Personnes :
- Processus :
- Outils :
- Organisation :
- Environnement :

### Cause principale (Pareto)

### Idées de solution et vote

## 5. Backlog d'amélioration pour le prochain PI Planning
- [ ] 
