---
typ: projekt
titel: {{title}}
projekt: {{title}}
kunde: {{kunde}}
methode: {{methode}}
status: aktiv
erstellt: {{date}}
tags: [projekt]
---
# Projet : {{title}}

{{beschreibung}}

## Structure
{{struktur}}

## Tâches ouvertes
```dataview
TABLE start, ende, status, prioritaet, verantwortlich
FROM "{{root}}"
WHERE typ = "task" AND status != "erledigt"
SORT ende ASC
```

## Jalons
```dataview
TABLE phase, plan, ist, status, entscheid_durch
FROM "{{root}}"
WHERE typ = "meilenstein"
SORT reihenfolge ASC
```

## Planning Intervals
```dataview
TABLE art, start, ende, status
FROM "{{root}}"
WHERE typ = "pi"
SORT start DESC
```

## Risques ouverts (ROAM)
```dataview
TABLE wahrscheinlichkeit, auswirkung, roam, verantwortlich, faellig
FROM "{{root}}"
WHERE typ = "risiko" AND roam != "resolved"
```

## Journal des décisions
```dataview
TABLE datum, gremium, entscheid_durch, status
FROM "{{root}}"
WHERE typ = "entscheid"
SORT datum DESC
```

## Décisions, risques et blocages marqués
```dataview
TABLE WITHOUT ID L.text AS "Entrée", file.link AS "Note"
FROM "{{root}}"
FLATTEN file.lists AS L
WHERE contains(L.tags, "#entscheid") OR contains(L.tags, "#risiko") OR contains(L.tags, "#blocker")
```

> Les tableaux nécessitent le plugin communautaire Dataview.
