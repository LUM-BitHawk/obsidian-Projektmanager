---
typ: projekt
titel: {{title}}
projekt: {{title}}
kunde: {{kunde}}
methode: {{methode}}
status: aktiv
erstellt: {{date}}
tags: [projekt]
---
# Proyecto: {{title}}

{{beschreibung}}

## Estructura
{{struktur}}

## Tareas abiertas
```dataview
TABLE start, ende, status, prioritaet, verantwortlich
FROM "{{root}}"
WHERE typ = "task" AND status != "erledigt"
SORT ende ASC
```

## Hitos
```dataview
TABLE phase, plan, ist, status, entscheid_durch
FROM "{{root}}"
WHERE typ = "meilenstein"
SORT reihenfolge ASC
```

## Planning Intervals
```dataview
TABLE art, start, ende, status
FROM "{{root}}"
WHERE typ = "pi"
SORT start DESC
```

## Riesgos abiertos (ROAM)
```dataview
TABLE wahrscheinlichkeit, auswirkung, roam, verantwortlich, faellig
FROM "{{root}}"
WHERE typ = "risiko" AND roam != "resolved"
```

## Registro de decisiones
```dataview
TABLE datum, gremium, entscheid_durch, status
FROM "{{root}}"
WHERE typ = "entscheid"
SORT datum DESC
```

## Decisiones, riesgos y bloqueos marcados
```dataview
TABLE WITHOUT ID L.text AS "Entrada", file.link AS "Nota"
FROM "{{root}}"
FLATTEN file.lists AS L
WHERE contains(L.tags, "#entscheid") OR contains(L.tags, "#risiko") OR contains(L.tags, "#blocker")
```

> Las tablas requieren el plugin comunitario Dataview.
