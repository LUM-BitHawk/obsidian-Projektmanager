---
typ: risiko
titel: {{title}}
projekt: {{projekt}}
pi: {{pi}}
wahrscheinlichkeit: {{wahrscheinlichkeit}}
auswirkung: {{auswirkung}}
roam: {{roam}}
verantwortlich: {{verantwortlich}}
faellig: {{faellig}}
erfasst: {{date}}
task:
tags: [risiko]
---
# Riesgo: {{title}}

## Descripción (causa, evento, impacto)
{{beschreibung}}

## Medida
{{massnahme}}

## ROAM
| Estado | Significado |
|---|---|
| Resolved | Ya no es un riesgo, anotar el motivo |
| Owned | Una persona se encarga |
| Accepted | Se acepta conscientemente |
| Mitigated | Las medidas reducen la probabilidad o el impacto |

## Historial
- {{date}}: riesgo registrado
