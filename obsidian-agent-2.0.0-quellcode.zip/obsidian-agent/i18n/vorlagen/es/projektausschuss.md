---
typ: projektausschuss
titel: {{title}}
projekt: {{projekt}}
datum: {{date}}
teilnehmende:
tags: [meeting, projektausschuss]
---
# Comité de dirección: {{title}}
**Fecha:** {{date}} · **Proyecto:** {{projekt}} · **Fase actual:** {{auto_phase}}

## Participantes
- 

## Orden del día
1. Estado del proyecto e hitos
2. Riesgos
3. Solicitudes y decisiones
4. Varios

## Estado del proyecto
{{auto_meilensteine}}

## Riesgos
> Marque los nuevos riesgos con `#risiko`, los bloqueos con `#blocker`.

{{auto_risiken}}

## Decisiones
> Marque cada decisión en una línea propia con `#entscheid`. Aparece entonces en el registro de decisiones.

- 

## Tareas
| Qué | Quién | Hasta |
|-----|-----|-----|
|     |     |     |
