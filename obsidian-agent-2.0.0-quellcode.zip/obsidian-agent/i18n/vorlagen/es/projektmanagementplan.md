---
typ: projektmanagementplan
titel: {{title}}
projekt: {{projekt}}
version: 0.1
status: in_arbeit
erstellt: {{date}}
tags: [hermes, pmp]
---
# Plan de gestión del proyecto: {{title}}

## 1. Situación inicial y objetivos
- Objetivos del proyecto (según el mandato de ejecución):
- Delimitación:

## 2. Enfoque
- Enfoque (clásico, ágil, SAFe):
- Fases y releases:

## 3. Organización del proyecto
| Rol | Persona |
|---|---|
| Patrocinador/a | |
| Comité de dirección | |
| Jefe/a de proyecto | |
| Representante de los usuarios | |
| Responsable de calidad y riesgos | |

## 4. Hitos y plazos
{{auto_meilensteine}}

## 5. Costes y recursos
| Fase | Esfuerzo de personal | Costes materiales |
|---|---|---|
| | | |

## 6. Comunicación e informes
- Informe de estado del proyecto: mensual al comité de dirección
- Reuniones del comité de dirección:

## 7. Riesgos
{{auto_risiken}}

## 8. Calidad y cambios
- Procedimiento de cambio: solicitud de cambio, decisión del comité de dirección
