---
typ: pi_objective
titel: {{title}}
projekt: {{projekt}}
pi: {{pi}}
team: {{team}}
committed: {{committed}}
bv_geplant: {{bv_geplant}}
bv_ist:
status: geplant
tags: [safe, pi-objective]
---
# {{title}}

**PI:** {{pi}} · **Equipo:** {{team}} · **Committed:** {{committed}} · **Valor de negocio planificado:** {{bv_geplant}}

## Descripción (SMART)
{{beschreibung}}

## Funcionalidades relacionadas
- 

## Resultado al final del PI
- Valor de negocio alcanzado (valoración de los business owners):
- Observación:
