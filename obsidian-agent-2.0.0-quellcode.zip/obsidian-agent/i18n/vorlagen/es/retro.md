---
typ: retro
titel: {{title}}
projekt: {{projekt}}
pi: {{pi}}
team: {{team}}
iteration: {{iteration}}
datum: {{date}}
tags: [safe, retro]
---
# Retrospectiva: {{title}}
**PI:** {{pi}} · **Equipo:** {{team}} · **Iteración:** {{iteration}}

## ¿Qué salió bien?
- 

## ¿Qué no salió bien?
- 

## ¿Qué mejoramos? (como máximo dos medidas)
- [ ] 

## Impedimentos para Inspect & Adapt
> Marque los impedimentos que afectan a varios equipos con `#blocker`.

- 
