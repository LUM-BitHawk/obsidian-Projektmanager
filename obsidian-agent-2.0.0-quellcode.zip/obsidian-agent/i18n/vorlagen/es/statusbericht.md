---
typ: statusbericht
titel: {{title}}
projekt: {{projekt}}
datum: {{date}}
phase: {{auto_phase}}
ampel_gesamt: gruen
ampel_termine: gruen
ampel_kosten: gruen
ampel_qualitaet: gruen
tags: [hermes, statusbericht]
---
# Informe de estado del proyecto: {{title}}
**Fecha de corte:** {{date}} · **Fase actual:** {{auto_phase}}

## Valoración global
| Ámbito | Semáforo (verde / amarillo / rojo) | Comentario |
|---|---|---|
| Global | verde | |
| Plazos | verde | |
| Costes | verde | |
| Calidad / prestaciones | verde | |

## Resultados alcanzados desde el último informe
- 

## Hitos
{{auto_meilensteine}}

## Riesgos abiertos
{{auto_risiken}}

## Decisiones de los últimos 30 días
{{auto_entscheide}}

## Solicitudes al comité de dirección
- 

## Próximos pasos
- 
