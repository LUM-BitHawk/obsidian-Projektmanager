---
typ: readme
projekt: {{projekt}}
ordner: {{ordner}}
erstellt: {{date}}
tags: [readme]
---
# {{titel}}

## Finalidad de esta carpeta
{{zweck}}

## Contenido
```dataview
LIST
FROM "{{pfad}}"
WHERE file.name != this.file.name
SORT file.mtime DESC
```
