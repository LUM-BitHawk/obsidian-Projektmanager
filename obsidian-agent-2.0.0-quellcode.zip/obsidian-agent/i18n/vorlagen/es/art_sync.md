---
typ: art_sync
titel: {{title}}
projekt: {{projekt}}
pi: {{pi}}
datum: {{date}}
tags: [meeting, safe, art-sync]
---
# ART Sync: {{title}}
**Fecha:** {{date}} · **PI:** {{pi}}

## Progreso por equipo
| Equipo | Progreso de funcionalidades | Dependencias | Bloqueos |
|---|---|---|---|
| | | | |

## Bloqueos y riesgos
> `#blocker` para impedimentos, `#risiko` para riesgos.

- 

## Decisiones
- 

## Acciones
| Qué | Quién | Hasta |
|-----|-----|-----|
|     |     |     |
