---
typ: meilenstein
titel: {{title}}
ms_id: {{ms_id}}
projekt: {{projekt}}
methode: {{methode}}
phase: {{phase}}
reihenfolge: {{reihenfolge}}
kern: {{kern}}
plan: {{plan}}
ist:
status: geplant
entscheid_durch: {{entscheid_durch}}
entscheid:
tags: [meilenstein, hermes]
---
# {{title}}

**Fase:** {{phase_name}} · **Decidido por:** {{entscheid_durch}}

## Puntos de control para la aprobación
> Resultados típicos según HERMES 2022. Adaptar al escenario y al tamaño del proyecto.

{{pruefpunkte}}

## Bases de decisión
- 

## Decisión
- Fecha:
- Decisión:
- Condiciones:
