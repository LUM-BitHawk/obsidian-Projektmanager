---
typ: task
titel: {{title}}
projekt: {{projekt}}
start: {{start}}
ende: {{ende}}
status: offen
prioritaet: {{prioritaet}}
verantwortlich: {{verantwortlich}}
erstellt: {{date}}
tags: [task]
---
# {{title}}

## Descripción
{{beschreibung}}

## Lista de comprobación
{{checkliste}}

## Notas
