---
typ: entscheid
titel: {{title}}
projekt: {{projekt}}
datum: {{datum}}
gremium: {{gremium}}
entscheid_durch: {{entscheid_durch}}
status: {{status}}
meilenstein: {{meilenstein}}
pi: {{pi}}
tags: [entscheid]
---
# Decisión: {{title}}

**Fecha:** {{datum}} · **Órgano:** {{gremium}} · **Decidido por:** {{entscheid_durch}}

## Solicitud / situación inicial
{{antrag}}

## Decisión
{{entscheid}}

## Condiciones / consecuencias
- 
