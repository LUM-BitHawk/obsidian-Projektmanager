---
typ: pi
titel: {{title}}
projekt: {{projekt}}
art: {{art}}
start: {{start}}
ende: {{ende}}
iterationen: {{iterationen}}
iteration_wochen: {{iteration_wochen}}
status: {{status}}
tags: [safe, pi]
---
# {{title}}{{art_titel}}

**Periodo:** del {{start}} al {{ende}} · **Iteraciones:** {{iterationen}} de {{iteration_wochen}} semanas (la última es la iteración IP)

## Iteraciones
{{iterationen_tabelle}}

## Objetivos de PI (requiere el plugin comunitario Dataview)
```dataview
TABLE team, committed, bv_geplant AS "VN planificado", bv_ist AS "VN alcanzado", status
FROM "{{ordner}}"
WHERE typ = "pi_objective"
SORT team ASC, committed DESC
```

## ART Planning Board
[[{{board}}|ART Planning Board (lienzo)]]

## Riesgos (ROAM)
```dataview
TABLE wahrscheinlichkeit, auswirkung, roam, verantwortlich
WHERE typ = "risiko" AND pi = "{{title}}"
```

## Retrospectivas de este PI
```dataview
TABLE team, iteration
WHERE typ = "retro" AND pi = "{{title}}"
SORT iteration ASC
```

## Notas sobre el PI Planning
- Visión / contexto de negocio:
- Funcionalidades principales:
- Voto de confianza:
