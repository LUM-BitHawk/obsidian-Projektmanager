---
typ: person
titel: {{title}}
kuerzel: {{kuerzel}}
rolle: {{rolle}}
team: {{team}}
organisation: {{organisation}}
email: {{email}}
telefon: {{telefon}}
einfluss: {{einfluss}}
interesse: {{interesse}}
vertretung: {{vertretung}}
tags: [person]
---
# {{title}}

| Campo | Valor |
|------|------|
| Rol | {{rolle}} |
| Equipo / organización | {{team}} {{organisation}} |
| Correo electrónico | {{email}} |
| Teléfono | {{telefon}} |
| Influencia / interés | {{einfluss}} / {{interesse}} |
| Suplencia | {{vertretung}} |

## Responsabilidades en el proyecto
- 

## Expectativas e inquietudes
- 

## Últimos puntos tratados
- 
