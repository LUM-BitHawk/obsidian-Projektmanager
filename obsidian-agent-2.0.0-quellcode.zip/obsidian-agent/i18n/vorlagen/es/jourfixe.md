---
typ: jourfixe
titel: {{title}}
serie: {{serie}}
datum: {{datum}}
projekt: {{projekt}}
moderation: {{moderation}}
teilnehmer: {{teilnehmer}}
naechster_termin: {{naechster_termin}}
tags: [jourfixe]
---
# {{title}}

**Fecha:** {{datum}} · **Moderación:** {{moderation}} · **Próxima reunión:** {{naechster_termin}}
**Participantes:** {{teilnehmer}}

## Orden del día
{{agenda}}

## Asuntos pendientes abiertos (estado antes de la reunión)
{{pendenzen}}

## Información / debate
- 

## Acuerdos
> Marque los acuerdos con `#entscheid`, así aparecen en el registro de decisiones.

- 

## Nuevos asuntos pendientes
> Registre los nuevos asuntos pendientes en Obsidian-Agent en *Reunión periódica*. Aparecen entonces también en Tareas y Hoy.
