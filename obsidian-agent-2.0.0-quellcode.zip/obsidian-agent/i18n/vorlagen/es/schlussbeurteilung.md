---
typ: schlussbeurteilung
titel: {{title}}
projekt: {{projekt}}
datum: {{date}}
tags: [hermes, abschluss]
---
# Evaluación final del proyecto: {{title}}

## Consecución de los objetivos
| Objetivo | Alcanzado | Observación |
|---|---|---|
| | | |

## Comparación previsto/real de los hitos
{{auto_meilensteine}}

## Costes y esfuerzo (previsto/real)
| Partida | Previsto | Real | Diferencia |
|---|---|---|---|
| | | | |

## Experiencias (lessons learned)
- 

## Asuntos pendientes y medidas tras el cierre del proyecto
- 

## Solicitud de cierre del proyecto
- 
