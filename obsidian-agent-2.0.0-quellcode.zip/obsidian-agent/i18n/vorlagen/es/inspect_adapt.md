---
typ: inspect_adapt
titel: {{title}}
projekt: {{projekt}}
pi: {{pi}}
datum: {{date}}
tags: [safe, inspect-adapt]
---
# Inspect & Adapt: {{pi}}

## 1. Demo del sistema del PI
- 

## 2. Medición cuantitativa y cualitativa
{{predictability}}

> Rango objetivo de la previsibilidad según SAFe: del 80 al 100 %.

## 3. Retrospectiva
### Retrospectivas de los equipos en este PI
```dataview
TABLE team, iteration
WHERE typ = "retro" AND pi = "{{pi}}"
SORT iteration ASC
```

### Patrones recurrentes (impedimentos sistémicos)
- 

## 4. Taller de resolución de problemas
### Problema acordado

### Análisis de causas (espina de pescado, 5 porqués)
- Personas:
- Procesos:
- Herramientas:
- Organización:
- Entorno:

### Causa principal (Pareto)

### Ideas de solución y votación

## 5. Backlog de mejora para el próximo PI Planning
- [ ] 
