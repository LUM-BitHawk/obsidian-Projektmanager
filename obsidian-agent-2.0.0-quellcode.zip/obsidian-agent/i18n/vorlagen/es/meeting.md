---
typ: meeting
titel: {{title}}
projekt: {{projekt}}
datum: {{date}}
teilnehmende:
tags: [meeting]
---
# Reunión: {{title}}
**Fecha:** {{date}} · **Proyecto:** {{projekt}}

## Participantes
- 

## Orden del día
1. 

## Tratado / resultados
- 

## Decisiones
> Marque cada decisión en una línea propia con `#entscheid`, los riesgos con `#risiko`, los bloqueos con `#blocker`.

- 

## Tareas
| Qué | Quién | Hasta |
|-----|-----|-----|
|     |     |     |
