---
typ: aenderungsantrag
titel: {{title}}
projekt: {{projekt}}
datum: {{date}}
status: beantragt
antragsteller:
tags: [hermes, aenderung]
---
# Solicitud de cambio: {{title}}

## Descripción del cambio

## Justificación

## Repercusiones
| Ámbito | Repercusión |
|---|---|
| Objetivos / alcance | |
| Costes | |
| Plazos | |
| Riesgos | |

## Variantes

## Solicitud al comité de dirección

## Decisión
- 
