@echo off
REM Obsidian-Agent oeffnen (Windows).
powershell -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "%~dp0windows\start.ps1"
