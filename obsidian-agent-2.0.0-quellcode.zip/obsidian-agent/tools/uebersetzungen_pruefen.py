"""Sammelt alle Texte aus t(), T() und N_() in Code und Seiten und prüft, ob jede Sprache sie übersetzt.
Aufruf: python tools/uebersetzungen_pruefen.py [--fehlend <sprache>]"""
import ast, json, sys
from pathlib import Path
import jinja2
from jinja2 import nodes

BASE = Path(__file__).resolve().parent.parent


def texte_sammeln() -> list[str]:
    gefunden = []
    for f in sorted(BASE.glob("*.py")):
        for n in ast.walk(ast.parse(f.read_text(encoding="utf-8"))):
            if isinstance(n, ast.Call) and n.args and isinstance(n.args[0], ast.Constant) and isinstance(n.args[0].value, str):
                name = n.func.id if isinstance(n.func, ast.Name) else (n.func.attr if isinstance(n.func, ast.Attribute) else "")
                if name in ("t", "T", "N_"):
                    gefunden.append(n.args[0].value)
    env = jinja2.Environment()
    for f in sorted((BASE / "templates").glob("*.html")):
        for n in env.parse(f.read_text(encoding="utf-8")).find_all(nodes.Call):
            if isinstance(n.node, nodes.Name) and n.node.name == "t" and n.args and isinstance(n.args[0], nodes.Const):
                gefunden.append(n.args[0].value)
    return list(dict.fromkeys(gefunden))


if __name__ == "__main__":
    texte = texte_sammeln()
    print(len(texte), "Texte")
    ok = True
    for sp in ("en", "fr", "it", "es", "ro"):
        f = BASE / "i18n" / f"{sp}.json"
        d = json.loads(f.read_text(encoding="utf-8")).get("texte", {}) if f.exists() else {}
        fehlt = [x for x in texte if x not in d]
        ueber = [x for x in d if x not in texte]
        print(f"{sp}: {len(fehlt)} fehlen, {len(ueber)} überzählig")
        ok &= not fehlt
        if "--fehlend" in sys.argv and sys.argv[-1] == sp:
            print(json.dumps(fehlt, ensure_ascii=False, indent=0))
    sys.exit(0 if ok else 1)
