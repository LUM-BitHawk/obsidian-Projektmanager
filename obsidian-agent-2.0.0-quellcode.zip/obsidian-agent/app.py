"""
Obsidian-Agent – Weboberfläche
Start:  python app.py   ->  http://127.0.0.1:5055
"""
from __future__ import annotations

import datetime as dt
import os
import threading
import webbrowser

from flask import Flask, flash, jsonify, redirect, render_template, request, url_for

import agent as core
import pm_daten as pm
from i18n import SPRACHEN

app = Flask(__name__)
app.secret_key = "obsidian-agent-lokal"
AGENT = core.Agent()
T = AGENT.t


@app.template_filter("dmy")
def _dmy(v):
    return AGENT.datum(v)


@app.context_processor
def _globals():
    sp = AGENT.sp
    return {"heute": dt.date.today(), "cfg": AGENT.cfg, "vault_ok": AGENT.vault_ok(), "t": T, "pm": pm,
            "lbl": AGENT.label, "typ_label": lambda x: T(pm.VORLAGEN[x][0]) if x in pm.VORLAGEN else x, "letzter_sync": AGENT.letzter_sync(), "SPRACHEN": SPRACHEN,
            "html_lang": sp.meta("html", sp.code), "datum_eingabe": sp.meta("datum_eingabe"),
            "datum_trenner": sp.meta("trenner", "."), "wochentag": sp.wochentag,
            "TEAM_NAMEN": [p["titel"] for p in AGENT.eintraege("person")] if AGENT.vault_ok() else []}


@app.before_request
def _vault_pruefen():
    if request.endpoint in ("einstellungen", "static") or AGENT.vault_ok():
        return None
    flash(T("Vault-Ordner nicht gefunden: {pfad}. Bitte in den Einstellungen setzen.", pfad=AGENT.vault), "fehler")
    return redirect(url_for("einstellungen"))


def _ok(msg):
    flash(msg, "ok")


def _fehler(exc):
    flash(str(exc), "fehler")


def _zurueck(standard="dashboard", **kw):
    return redirect(request.referrer or url_for(standard, **kw))


# --- Heute -------------------------------------------------------------------------
@app.route("/")
def dashboard():
    g = AGENT.tasks()
    grenze = dt.date.today() + dt.timedelta(days=int(AGENT.cfg.get("demnaechst_tage", 7)))
    bald = [t for t in g["geplant"] if core.parse_date(t["start"]) <= grenze]
    return render_template("dashboard.html", g=g, bald=bald, meilensteine=AGENT.meilensteine_faellig(),
                           risiken=[r for r in AGENT.risiken() if r["roam"] != "resolved" and r["farbe"] == "rot"],
                           notizen=AGENT.letzte_notizen(8), projekte=AGENT.projekte())


@app.post("/sync")
def sync():
    try:
        s = AGENT.sync("manuell")
        _ok(T("Aktualisiert: {d} Dateien gelesen, {h} Tasks heute, {o} offen ({ms} ms).",
              d=s["dateien"], h=s["tasks_heute"], o=s["tasks_offen"], ms=s["dauer_ms"]))
    except Exception as exc:
        _fehler(exc)
    return _zurueck()


# --- Tasks -------------------------------------------------------------------------
@app.route("/tasks")
def tasks():
    projekt = request.args.get("projekt", "")
    return render_template("tasks.html", g=AGENT.tasks(projekt=projekt), projekt=projekt, projekte=AGENT.projekte())


@app.post("/tasks/neu")
def task_neu():
    f = request.form
    try:
        p = AGENT.task_anlegen(f["titel"], f.get("start", ""), f.get("ende", ""), f.get("projekt", ""),
                               f.get("prioritaet", "mittel"), f.get("verantwortlich", ""), f.get("beschreibung", ""),
                               f.get("checkliste", ""), unterordner=f.get("unterordner", ""))
        _ok(T("Task angelegt: {pfad}", pfad=AGENT.rel(p)))
    except Exception as exc:
        _fehler(exc)
    return _zurueck("tasks")


@app.get("/api/projektordner")
def projekt_ordner_api():
    projekt = request.args.get("projekt", "")
    return jsonify({"ordner": AGENT.projekt_unterordner(projekt),
                    "standard": (AGENT.cfg.get("task_standard_ordner") or "").strip("/")})


@app.post("/tasks/status")
def task_status():
    try:
        AGENT.task_status_setzen(request.form["pfad"], request.form["status"])
    except Exception as exc:
        _fehler(exc)
    return _zurueck("tasks")


@app.post("/tasks/verschieben")
def task_verschieben():
    try:
        AGENT.task_verschieben(request.form["pfad"], int(request.form.get("tage", 1)))
    except Exception as exc:
        _fehler(exc)
    return _zurueck("tasks")


# --- Projekte ------------------------------------------------------------------------
@app.route("/projekte")
def projekte():
    return render_template("projekte.html", projekte=AGENT.projekte(), struktur=AGENT.projekt_struktur())


@app.post("/projekte/neu")
def projekt_neu():
    f = request.form
    try:
        methode = f.get("methode") if "methode" in f else None
        p = AGENT.projekt_anlegen(f["name"], f.get("kunde", ""), f.get("beschreibung", ""), methode)
        _ok(T("Projekt angelegt bzw. ergänzt: {pfad}", pfad=AGENT.rel(p)))
    except Exception as exc:
        _fehler(exc)
    return redirect(url_for("projekte"))


@app.post("/projekte/ergaenzen")
def projekte_ergaenzen():
    try:
        n_proj, n_ord = AGENT.projekte_ergaenzen()
        _ok(T("{p} Projekte ergänzt, {o} Ordner neu angelegt. Bestehende Dateien wurden nicht verändert.",
              p=n_proj, o=n_ord))
    except Exception as exc:
        _fehler(exc)
    return redirect(url_for("projekte"))


@app.post("/pm/methode")
def pm_methode():
    f = request.form
    m = f.get("methode", "")
    try:
        AGENT.projekt_methode_setzen(f["projekt"], m)
        _ok(T("Projekt {p}: Methode {m}. Fehlende Ordner und Meilensteine wurden ergänzt, bestehende Dateien "
              "bleiben unverändert.", p=f["projekt"], m=AGENT.label(pm.METHODEN, m)))
    except Exception as exc:
        _fehler(exc)
    if pm.ist_hermes(m):
        return redirect(url_for("pm_hermes", projekt=f["projekt"]))
    return _zurueck("pm_cockpit")


# --- Dokumente aus Vorlage -------------------------------------------------------------
@app.route("/dokumente")
def vorlage():
    return render_template("vorlage.html", vorlagen=AGENT.vorlagen_liste(), projekte=AGENT.projekte(),
                           projekt=request.args.get("projekt", ""), gewaehlt=request.args.get("vorlage", ""),
                           notizen=AGENT.letzte_notizen(12))


@app.post("/dokumente/neu")
def vorlage_neu():
    f = request.form
    try:
        p = AGENT.aus_vorlage_anlegen(f.get("vorlage", ""), f.get("titel", ""), f.get("projekt", ""),
                                      f.get("unterordner", ""))
        _ok(T("Notiz angelegt: {pfad}", pfad=AGENT.rel(p)))
        return redirect(url_for("vorlage", projekt=f.get("projekt", ""), vorlage=f.get("vorlage", "")))
    except Exception as exc:
        _fehler(exc)
    return _zurueck("vorlage")


# --- Team -------------------------------------------------------------------------------
@app.route("/team")
def team():
    return render_template("team.html", team=AGENT.team())


@app.post("/team/neu")
def person_neu():
    try:
        _ok(T("Person angelegt: {pfad}", pfad=AGENT.rel(AGENT.person_anlegen(request.form.to_dict()))))
    except Exception as exc:
        _fehler(exc)
    return redirect(url_for("team"))


# --- Jour Fixe ------------------------------------------------------------------------
@app.route("/jourfixe")
def jourfixe():
    serie = request.args.get("serie", "")
    erledigte = request.args.get("erledigte") == "1"
    return render_template("jourfixe.html", serie=serie, erledigte=erledigte, serien=AGENT.jf_serien(),
                           pendenzen=AGENT.jf_pendenzen(serie, alle=erledigte),
                           sitzungen=AGENT.jf_sitzungen(serie)[:15], projekte=AGENT.projekte())


@app.post("/jourfixe/sitzung")
def jf_sitzung_neu():
    f = request.form.to_dict()
    if f.get("serie") == "__neu__":
        f["serie"] = f.get("serie_neu", "")
    try:
        p = AGENT.jf_sitzung_anlegen(f)
        _ok(T("Sitzung angelegt: {pfad}. Sie enthält die offenen Pendenzen der Serie.", pfad=AGENT.rel(p)))
        return redirect(url_for("jourfixe", serie=core.safe_name(f["serie"])))
    except Exception as exc:
        _fehler(exc)
    return _zurueck("jourfixe")


@app.post("/jourfixe/pendenz")
def jf_pendenz_neu():
    try:
        _ok(T("Pendenz angelegt: {pfad}", pfad=AGENT.rel(AGENT.jf_pendenz_anlegen(request.form.to_dict()))))
    except Exception as exc:
        _fehler(exc)
    return _zurueck("jourfixe")


# --- Projektmanagement ------------------------------------------------------------------
@app.post("/feld")
def feld():
    f = request.form
    try:
        AGENT.feld_setzen(f["pfad"], f["feld"], f["wert"])
    except Exception as exc:
        _fehler(exc)
    return _zurueck()


@app.route("/pm")
def pm_cockpit():
    return render_template("pm.html", c=AGENT.pm_cockpit(), projekte=AGENT.projekte())


@app.route("/pm/hermes")
def pm_hermes():
    projekte = [p for p in AGENT.projekte() if pm.ist_hermes(p["methode"])]
    projekt = request.args.get("projekt", "") or (projekte[0]["name"] if projekte else "")
    st = AGENT.hermes_status(projekt) if any(p["name"] == projekt for p in projekte) else None
    doku = [n for n in AGENT.letzte_notizen(400) if st and n["projekt"] == projekt
            and (n["typ"] in pm.HERMES_DOKU or n["typ"] == "entscheid")]
    return render_template("hermes.html", projekte=projekte, projekt=projekt, st=st, doku=doku,
                           alle_projekte=AGENT.projekte())


@app.post("/pm/meilenstein/neu")
def pm_meilenstein_neu():
    f = request.form.to_dict()
    try:
        _ok(T("Meilenstein angelegt: {pfad}", pfad=AGENT.rel(AGENT.meilenstein_anlegen(f))))
    except Exception as exc:
        _fehler(exc)
    return redirect(url_for("pm_hermes", projekt=f.get("projekt", "")))


@app.post("/pm/meilenstein/freigeben")
def pm_meilenstein_freigeben():
    f = request.form
    try:
        e = AGENT.meilenstein_freigeben(f["pfad"], f.get("datum", ""), f.get("entscheid_durch", ""),
                                        f.get("bemerkung", ""), bool(f.get("entscheid_notiz")))
        _ok(T("Meilenstein freigegeben.") + (" " + T("Entscheid festgehalten: {pfad}", pfad=AGENT.rel(e)) if e else ""))
    except Exception as exc:
        _fehler(exc)
    return _zurueck("pm_hermes")


@app.post("/pm/dokument")
def pm_dokument():
    f = request.form.to_dict()
    try:
        extra = {k: f[k] for k in ("pi", "team", "iteration") if f.get(k)}
        p = AGENT.pm_dokument_anlegen(f.get("typ", ""), f.get("titel", ""), f.get("projekt", ""), extra)
        _ok(T("Dokument angelegt: {pfad}", pfad=AGENT.rel(p)))
    except Exception as exc:
        _fehler(exc)
    return _zurueck("pm_cockpit")


@app.route("/pm/safe")
def pm_safe():
    pis = AGENT.pis()
    name = request.args.get("pi", "")
    if not name and pis:
        name = next((p["titel"] for p in pis if p["laufend"]), pis[0]["titel"])
    return render_template("safe.html", pis=pis, pi=name, det=AGENT.pi_details(name) if name else None,
                           projekte=[p for p in AGENT.projekte() if pm.ist_safe(p["methode"])])


@app.post("/pm/pi/neu")
def pm_pi_neu():
    f = request.form.to_dict()
    try:
        _ok(T("PI angelegt: {pfad} (mit ART Planning Board als Canvas)", pfad=AGENT.rel(AGENT.pi_anlegen(f))))
        return redirect(url_for("pm_safe", pi=core.safe_name(f.get("titel", ""))))
    except Exception as exc:
        _fehler(exc)
    return redirect(url_for("pm_safe"))


@app.post("/pm/objective/neu")
def pm_objective_neu():
    f = request.form.to_dict()
    try:
        _ok(T("PI Objective angelegt: {pfad}", pfad=AGENT.rel(AGENT.objective_anlegen(f))))
    except Exception as exc:
        _fehler(exc)
    return redirect(url_for("pm_safe", pi=f.get("pi", "")))


@app.post("/pm/ia")
def pm_ia():
    pi = request.form.get("pi", "")
    try:
        _ok(T("Inspect & Adapt angelegt: {pfad}", pfad=AGENT.rel(AGENT.ia_anlegen(pi))))
    except Exception as exc:
        _fehler(exc)
    return redirect(url_for("pm_safe", pi=pi))


@app.post("/pm/board")
def pm_board():
    pi = request.form.get("pi", "")
    try:
        _ok(T("ART Planning Board angelegt: {pfad}", pfad=AGENT.rel(AGENT.pi_board_anlegen(pi))))
    except Exception as exc:
        _fehler(exc)
    return redirect(url_for("pm_safe", pi=pi))


@app.route("/pm/risiken")
def pm_risiken():
    projekt, pi = request.args.get("projekt", ""), request.args.get("pi", "")
    rr = AGENT.risiken(projekt, pi)
    marker = [m for m in AGENT.marker("risiko") + AGENT.marker("blocker") if not projekt or m["projekt"] == projekt]
    return render_template("risiken.html", spalten={s: [r for r in rr if r["roam"] == s] for s in pm.ROAM},
                           matrix=AGENT.risiko_matrix(rr), anzahl=len(rr), projekt=projekt, pi=pi, marker=marker,
                           projekte=AGENT.projekte(), pis=AGENT.pis())


@app.post("/pm/risiko/neu")
def pm_risiko_neu():
    try:
        _ok(T("Risiko erfasst: {pfad}", pfad=AGENT.rel(AGENT.risiko_anlegen(request.form.to_dict()))))
    except Exception as exc:
        _fehler(exc)
    return _zurueck("pm_risiken")


@app.post("/pm/risiko/task")
def pm_risiko_task():
    f = request.form
    try:
        t = AGENT.risiko_zu_task(f["pfad"], f.get("start", ""), f.get("ende", ""), f.get("verantwortlich", ""))
        _ok(T("Task für die Massnahme erstellt: {pfad}", pfad=AGENT.rel(t)))
    except Exception as exc:
        _fehler(exc)
    return _zurueck("pm_risiken")


@app.route("/pm/entscheide")
def pm_entscheide():
    projekt, quelle = request.args.get("projekt", ""), request.args.get("quelle", "")
    return render_template("entscheide.html", entscheide=AGENT.entscheide(projekt, quelle), projekt=projekt,
                           quelle=quelle, projekte=AGENT.projekte(), pis=AGENT.pis())


@app.post("/pm/entscheid/neu")
def pm_entscheid_neu():
    try:
        _ok(T("Entscheid festgehalten: {pfad}", pfad=AGENT.rel(AGENT.entscheid_anlegen(request.form.to_dict()))))
    except Exception as exc:
        _fehler(exc)
    return _zurueck("pm_entscheide")


# --- Suche und Einstellungen ------------------------------------------------------------
@app.route("/suche")
def suche():
    q = request.args.get("q", "").strip()
    return render_template("suche.html", q=q, treffer=AGENT.suche(q) if q else None)


FELDER = ["vault_path", "projekt_ordner", "task_ordner", "notiz_ordner", "vorlagen_ordner", "planer_ordner",
          "team_ordner", "jourfixe_ordner", "safe_ordner", "task_standard_ordner", "sync_zeit",
          "demnaechst_tage", "meilenstein_tage"]


@app.route("/einstellungen", methods=["GET", "POST"])
def einstellungen():
    if request.method == "POST":
        for k in FELDER:
            if k in request.form:
                v = request.form[k].strip()
                AGENT.cfg[k] = int(v) if k.endswith("_tage") and v.isdigit() else v
        if request.form.get("sprache") in SPRACHEN:
            AGENT.cfg["sprache"] = request.form["sprache"]
        core.save_config(AGENT.cfg)
        if AGENT.vault_ok():
            try:
                AGENT.sync("manuell")
                _ok(T("Einstellungen gespeichert und Vault eingelesen."))
            except Exception as exc:
                _fehler(exc)
        else:
            flash(T("Gespeichert, aber der Vault-Ordner existiert nicht: {pfad}", pfad=AGENT.vault), "fehler")
        return redirect(url_for("einstellungen"))
    return render_template("einstellungen.html", felder=FELDER, log=AGENT.sync_log(15), db=AGENT.db_path,
                           faellig=AGENT.geplanter_sync_faellig())


if __name__ == "__main__":
    port = int(AGENT.cfg.get("port", 5055))
    AGENT.starte_scheduler()
    if not os.environ.get("OBSIDIAN_AGENT_NO_BROWSER"):
        threading.Timer(1.2, lambda: webbrowser.open(f"http://127.0.0.1:{port}")).start()
    print(T("Obsidian-Agent läuft auf http://127.0.0.1:{port} (Beenden mit Ctrl+C)", port=port))
    app.run(host="127.0.0.1", port=port, debug=False)
