# Obsidian-Agent

Projektmanagement mit Obsidian nach HERMES 2022 und SAFe: Projekte, Meilensteine und Freigaben, Planning Intervals, Risiken (ROAM), Entscheid-Log, Jour Fixe und Tagesübersicht. Lokale Oberfläche unter `http://127.0.0.1:5055`.

| Sprache | Anleitung |
|---|---|
| Deutsch | [docs/Anleitung_de.md](docs/Anleitung_de.md) |
| English | [docs/Guide_en.md](docs/Guide_en.md) |
| Français | [docs/Guide_fr.md](docs/Guide_fr.md) |
| Italiano | [docs/Guida_it.md](docs/Guida_it.md) |
| Español | [docs/Guia_es.md](docs/Guia_es.md) |
| Română | [docs/Ghid_ro.md](docs/Ghid_ro.md) |

## Installation

- **Windows:** `Obsidian-Agent-Setup-<Version>.exe` ausführen (ohne Administratorrechte).
- **macOS:** `Obsidian-Agent-<Version>.pkg` öffnen.
- **Linux / aus dem Quellcode:** `./start.sh`

## Aufbau

| Datei | Inhalt |
|---|---|
| `agent.py` | Kernlogik, Sync und Kommandozeile |
| `app.py` | Weboberfläche (Flask) |
| `pm_daten.py` | HERMES-Phasen und -Meilensteine, Statuswerte |
| `i18n.py`, `i18n/` | Sprachen: Texte, Ordnernamen, Notizvorlagen (Deutsch ist die Mastersprache) |
| `templates/`, `static/` | Seiten der Oberfläche |
| `windows/` | Einrichtung, Start und Deinstallation unter Windows, NSIS-Installer |
| `mac/` | Einrichtung, Start und Deinstallation unter macOS, App-Starter, Paketskripte |
| `build/build_pkg.py` | Baut das macOS-Paket |
| `tools/uebersetzungen_pruefen.py` | Prüft, ob jede Sprache alle Texte übersetzt |

## Pakete bauen

```bash
# Windows-Installer (NSIS 3)
makensis -DVERSION=2.0.0 -DQUELLE=<Programmordner> -DAUSGABE=Obsidian-Agent-Setup-2.0.0.exe windows/installer.nsi
# macOS-Paket (benötigt cpio und das Hilfsprogramm mkpkg für die BOM-Datei)
python3 build/build_pkg.py 2.0.0 Obsidian-Agent-2.0.0.pkg <pfad/zu/mkpkg>
```
