@echo off
REM Obsidian-Agent einrichten (Windows). Mehrfach ausfuehrbar.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0windows\install.ps1"
