"""
Obsidian-Agent – Sprachen
=========================
Deutsch ist die Mastersprache: Alle Texte stehen im Code auf Deutsch und werden
mit t("…") übersetzt. Die Übersetzungen liegen in i18n/<sprache>.json, die
Markdown-Vorlagen in i18n/vorlagen/<sprache>/<name>.md. Fehlt eine Übersetzung,
wird der deutsche Text verwendet.
"""
from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path

I18N_DIR = Path(__file__).resolve().parent / "i18n"
MASTER = "de"
SPRACHEN = {"de": "Deutsch", "en": "English", "fr": "Français", "it": "Italiano", "es": "Español", "ro": "Română"}


def N_(text: str) -> str:
    """Markiert einen Text für die Übersetzung, ohne ihn sofort zu übersetzen."""
    return text


@lru_cache(maxsize=None)
def daten(sprache: str) -> dict:
    sprache = sprache if sprache in SPRACHEN else MASTER
    f = I18N_DIR / f"{sprache}.json"
    d = json.loads(f.read_text(encoding="utf-8")) if f.exists() else {}
    if sprache != MASTER:  # fehlende Abschnitte aus der Mastersprache ergänzen
        master = daten(MASTER)
        for k, v in master.items():
            if isinstance(v, dict):
                d[k] = {**v, **d.get(k, {})}
            else:
                d.setdefault(k, v)
    return d


class Sprache:
    def __init__(self, code: str):
        self.code = code if code in SPRACHEN else MASTER
        self.d = daten(self.code)
        self._texte = self.d.get("texte", {})

    def t(self, text: str, **werte) -> str:
        s = self._texte.get(text) or text
        return s.format(**werte) if werte else s

    def meta(self, key: str, standard=None):
        return self.d.get("_meta", {}).get(key, standard)

    def ordner(self, key: str) -> str:
        return self.d["ordner"][key]

    def struktur(self) -> dict:
        return dict(self.d["struktur"])

    def unterordner(self) -> dict:
        return dict(self.d["unterordner"])

    def datum(self, d) -> str:
        return d.strftime(self.meta("datum", "%d.%m.%Y")) if d else ""

    def wochentag(self, d) -> str:
        return self.meta("wochentage")[d.weekday()]

    def vorlage(self, name: str) -> str:
        for code in (self.code, MASTER):
            f = I18N_DIR / "vorlagen" / code / f"{name}.md"
            if f.exists():
                return f.read_text(encoding="utf-8")
        raise FileNotFoundError(f"Vorlage fehlt: {name}")


@lru_cache(maxsize=None)
def sprache(code: str) -> Sprache:
    return Sprache(code)
