﻿# Obsidian-Agent – Deinstallation (wird vom Uninstaller aufgerufen).
# Beendet den Agent, entfernt die geplanten Aufgaben und den Autostart und sichert
# config.json und planer.db auf den Desktop. Der Obsidian-Vault bleibt unverändert.
param([switch]$OhnePause)
$Dir = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
Set-Location $Dir
$Sprache = 'en'
try { $Sprache = (Get-Content config.json -Raw -Encoding UTF8 | ConvertFrom-Json).sprache } catch {}
if (-not (Test-Path "i18n\$Sprache.json")) { $Sprache = 'en' }
$T = (Get-Content "i18n\$Sprache.json" -Raw -Encoding UTF8 | ConvertFrom-Json).installer

$Port = 5055
try { $Port = [int](Get-Content config.json -Raw -Encoding UTF8 | ConvertFrom-Json).port } catch {}
foreach ($t in 'Obsidian-Agent Weboberflaeche', 'Obsidian-Agent Tages-Sync') {
    Stop-ScheduledTask -TaskName $t -ErrorAction SilentlyContinue
    Unregister-ScheduledTask -TaskName $t -Confirm:$false -ErrorAction SilentlyContinue
}
Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue |
    ForEach-Object { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue }
$Lnk = Join-Path ([Environment]::GetFolderPath('Startup')) 'Obsidian-Agent.lnk'
if (Test-Path $Lnk) { Remove-Item $Lnk -Force }
Remove-Item (Join-Path $env:LOCALAPPDATA 'obsidian-agent') -Recurse -Force -ErrorAction SilentlyContinue

if ((Test-Path config.json) -or (Test-Path planer.db)) {
    $Backup = Join-Path ([Environment]::GetFolderPath('Desktop')) ('obsidian-agent-backup_' + (Get-Date -Format 'yyyy-MM-dd_HHmm'))
    New-Item -ItemType Directory -Path $Backup -Force | Out-Null
    foreach ($f in 'config.json', 'planer.db') { if (Test-Path $f) { Copy-Item $f $Backup -Force } }
    Write-Host "$($T.backup) $Backup"
}
Remove-Item .venv -Recurse -Force -ErrorAction SilentlyContinue
Write-Host $T.deinstall_fertig
if (-not $OhnePause) { Start-Sleep -Seconds 2 }
