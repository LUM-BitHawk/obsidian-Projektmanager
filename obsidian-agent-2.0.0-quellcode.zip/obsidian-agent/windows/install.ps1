﻿# ======================================================================
#  Obsidian-Agent – Einrichtung unter Windows (ohne Administratorrechte)
#  Wird vom Installer (Obsidian-Agent-Setup.exe) aufgerufen, kann aber auch
#  direkt ausgeführt werden. Mehrfach ausführbar, nichts geht verloren.
#   1. Python suchen (bei Bedarf über winget installieren), .venv und Flask
#   2. Sprache setzen, Vault wählen, erster Sync
#   3. Geplante Aufgaben: Oberfläche bei der Anmeldung, täglicher Sync
#   4. Starten und Browser öffnen
# ======================================================================
param([string]$Sprache = '', [switch]$OhnePause)
$ErrorActionPreference = 'Continue'
$Dir = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
Set-Location $Dir

$TaskGui  = 'Obsidian-Agent Weboberflaeche'
$TaskSync = 'Obsidian-Agent Tages-Sync'
$Lnk      = Join-Path ([Environment]::GetFolderPath('Startup')) 'Obsidian-Agent.lnk'
$LogFile  = Join-Path $env:LOCALAPPDATA 'obsidian-agent\gui.log'
$VenvPy   = Join-Path $Dir '.venv\Scripts\python.exe'
$VenvPyw  = Join-Path $Dir '.venv\Scripts\pythonw.exe'
$Starter  = Join-Path $Dir 'hintergrund.pyw'

# --- Texte in der gewählten Sprache ---------------------------------------------
if (-not $Sprache -and (Test-Path config.json)) {
    try { $Sprache = (Get-Content config.json -Raw -Encoding UTF8 | ConvertFrom-Json).sprache } catch {}
}
if (-not $Sprache) { $Sprache = (Get-Culture).TwoLetterISOLanguageName }
if (-not (Test-Path "i18n\$Sprache.json")) { $Sprache = 'en' }
$T = (Get-Content "i18n\$Sprache.json" -Raw -Encoding UTF8 | ConvertFrom-Json).installer

function Ok($m)   { Write-Host "[OK] $m" -ForegroundColor Green }
function Warn($m) { Write-Host "[!!] $m" -ForegroundColor Yellow }
function Info($m) { Write-Host "...  $m" }
function Ende($code) { if (-not $OhnePause) { Read-Host $T.enter | Out-Null }; exit $code }
function Fail($m) { Write-Host "[X]  $m" -ForegroundColor Red; Ende 1 }
function Lauscht($p) { [bool](Get-NetTCPConnection -LocalPort $p -State Listen -ErrorAction SilentlyContinue) }

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
Write-Host ''
Write-Host "=== $($T.titel) ===" -ForegroundColor Cyan
Write-Host $Dir
Write-Host ''

# --- 1. Python ------------------------------------------------------------------
function Python-Finden {
    $kandidaten = @(@('py', '-3'), @('python'))
    foreach ($pfad in (Get-ChildItem "$env:LOCALAPPDATA\Programs\Python\Python3*\python.exe" -ErrorAction SilentlyContinue)) {
        $kandidaten += ,@($pfad.FullName)
    }
    foreach ($k in $kandidaten) {
        $exe = $k[0]; $arg = @($k | Select-Object -Skip 1)
        if (-not (Get-Command $exe -ErrorAction SilentlyContinue)) { continue }
        $v = & $exe @arg -c 'import sys; print(sys.version_info >= (3, 10))' 2>$null
        if ($v -eq 'True') { return @{ exe = $exe; arg = $arg } }
    }
    return $null
}
if (-not (Test-Path $VenvPy)) {
    Info $T.python_suche
    $py = Python-Finden
    if (-not $py -and (Get-Command winget -ErrorAction SilentlyContinue)) {
        Info $T.python_winget
        winget install -e --id Python.Python.3.12 --scope user --silent --accept-package-agreements --accept-source-agreements | Out-Host
        $env:Path = [Environment]::GetEnvironmentVariable('Path', 'User') + ';' + [Environment]::GetEnvironmentVariable('Path', 'Machine')
        $py = Python-Finden
    }
    if (-not $py) {
        Start-Process 'https://www.python.org/downloads/windows/'
        Fail $T.python_fehlt
    }
    Info $T.venv
    & $py.exe @($py.arg) -m venv .venv
    if (-not (Test-Path $VenvPy)) { Fail $T.python_fehlt }
}
& $VenvPy -m pip install -q --upgrade pip 2>$null | Out-Null
& $VenvPy -m pip install -q -r requirements.txt
if ($LASTEXITCODE -ne 0) { Fail $T.pip_fehler }
Ok "$($T.bereit) ($(& $VenvPy --version))"

# --- 2. Sprache und Vault ----------------------------------------------------------
& $VenvPy agent.py sprache $Sprache | Out-Null
Ok "$($T.sprache_gesetzt): $Sprache"
$vaultOk = & $VenvPy -c "import agent, os; c = agent.load_config(); print(os.path.isdir(os.path.expanduser(c['vault_path'])))"
if ($vaultOk -ne 'True') {
    Info $T.vault_waehlen
    Add-Type -AssemblyName System.Windows.Forms
    $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
    $dlg.Description = $T.vault_dialog
    $dlg.ShowNewFolderButton = $true
    $owner = New-Object System.Windows.Forms.Form -Property @{TopMost = $true}
    if ($dlg.ShowDialog($owner) -eq [System.Windows.Forms.DialogResult]::OK) {
        & $VenvPy -c "import agent, sys; c = agent.load_config(); c['vault_path'] = sys.argv[1]; agent.save_config(c)" $dlg.SelectedPath
        Ok "Vault: $($dlg.SelectedPath)"
    } else {
        Warn $T.vault_keiner
    }
} else {
    Ok "Vault: $(& $VenvPy -c "import agent; print(agent.load_config()['vault_path'])")"
}
& $VenvPy agent.py sync
$Port     = [int](& $VenvPy -c "import agent; print(agent.load_config().get('port', 5055))")
$SyncZeit = (& $VenvPy -c "import agent; print(agent.load_config().get('sync_zeit', '04:00'))")

# --- 3. Geplante Aufgaben ------------------------------------------------------------
$User = "$env:USERDOMAIN\$env:USERNAME"
$Settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
    -StartWhenAvailable -MultipleInstances IgnoreNew -ExecutionTimeLimit ([TimeSpan]::Zero) `
    -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1)
$Principal = New-ScheduledTaskPrincipal -UserId $User -LogonType Interactive -RunLevel Limited
$guiArt = $null
try {
    $act = New-ScheduledTaskAction -Execute $VenvPyw -Argument "`"$Starter`"" -WorkingDirectory $Dir
    $trg = New-ScheduledTaskTrigger -AtLogOn -User $User
    Register-ScheduledTask -TaskName $TaskGui -Action $act -Trigger $trg -Settings $Settings `
        -Principal $Principal -Description 'Obsidian-Agent' -Force -ErrorAction Stop | Out-Null
    if (Test-Path $Lnk) { Remove-Item $Lnk -Force }
    $guiArt = 'task'
    Ok $T.aufgabe_gui
} catch {
    $ws = New-Object -ComObject WScript.Shell
    $s = $ws.CreateShortcut($Lnk)
    $s.TargetPath = $VenvPyw; $s.Arguments = "`"$Starter`""; $s.WorkingDirectory = $Dir
    $s.Save()
    $guiArt = 'lnk'
    Warn "$($T.aufgabe_fehler): $($_.Exception.Message.Trim())"
    Ok $T.autostart_lnk
}
try {
    $h, $m = $SyncZeit.Split(':')
    $act = New-ScheduledTaskAction -Execute $VenvPyw -Argument "`"$Dir\agent.py`" sync --geplant" -WorkingDirectory $Dir
    $trg = New-ScheduledTaskTrigger -Daily -At ([datetime]::Today.AddHours([int]$h).AddMinutes([int]$m))
    Register-ScheduledTask -TaskName $TaskSync -Action $act -Trigger $trg -Settings $Settings `
        -Principal $Principal -Description 'Obsidian-Agent Sync' -Force -ErrorAction Stop | Out-Null
    Ok "$($T.aufgabe_sync) $SyncZeit"
} catch {
    Warn "$($T.aufgabe_fehler): $($_.Exception.Message.Trim())"
}

# --- 4. Starten -------------------------------------------------------------------------
if (Lauscht $Port) {
    Stop-ScheduledTask -TaskName $TaskGui -ErrorAction SilentlyContinue
    Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue |
        ForEach-Object { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue }
    Start-Sleep -Seconds 1
}
Info $T.starten
if ($guiArt -eq 'task') { Start-ScheduledTask -TaskName $TaskGui }
else { Start-Process -FilePath $VenvPyw -ArgumentList "`"$Starter`"" -WorkingDirectory $Dir }
for ($i = 0; $i -lt 30 -and -not (Lauscht $Port); $i++) { Start-Sleep -Milliseconds 500 }
Write-Host ''
if (Lauscht $Port) {
    Ok "$($T.fertig) http://127.0.0.1:$Port"
    Start-Process "http://127.0.0.1:$Port"
} else {
    Warn $T.laeuft_nicht
    if (Test-Path $LogFile) { Get-Content $LogFile -Tail 8 }
    Write-Host "     $LogFile"
}
Write-Host ''
Ende 0
