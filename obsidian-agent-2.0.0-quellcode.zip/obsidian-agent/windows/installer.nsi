; ======================================================================
;  Obsidian-Agent – Windows-Installer (NSIS 3)
;  Build:  makensis -DVERSION=2.0.0 -DQUELLE=<Programmordner> windows/installer.nsi
;  Installiert ohne Administratorrechte nach %LOCALAPPDATA%\Programs\Obsidian-Agent
;  und startet danach die Einrichtung (windows\install.ps1) in der gewählten Sprache.
; ======================================================================
Unicode true
SetCompressor /SOLID lzma
!include "MUI2.nsh"

!ifndef VERSION
  !define VERSION "2.0.0"
!endif
!ifndef QUELLE
  !define QUELLE ".."
!endif
!ifndef AUSGABE
  !define AUSGABE "Obsidian-Agent-Setup-${VERSION}.exe"
!endif

Name "Obsidian-Agent"
OutFile "${AUSGABE}"
InstallDir "$LOCALAPPDATA\Programs\Obsidian-Agent"
InstallDirRegKey HKCU "Software\Obsidian-Agent" "InstallDir"
RequestExecutionLevel user
ShowInstDetails show
BrandingText "Obsidian-Agent ${VERSION}"

VIProductVersion "${VERSION}.0"
VIAddVersionKey /LANG=0 "ProductName" "Obsidian-Agent"
VIAddVersionKey /LANG=0 "FileDescription" "Obsidian-Agent Setup"
VIAddVersionKey /LANG=0 "FileVersion" "${VERSION}"
VIAddVersionKey /LANG=0 "ProductVersion" "${VERSION}"
VIAddVersionKey /LANG=0 "LegalCopyright" "Obsidian-Agent"

!define MUI_ICON "${QUELLE}\windows\icon.ico"
!define MUI_UNICON "${QUELLE}\windows\icon.ico"
!define MUI_ABORTWARNING
!define MUI_LANGDLL_REGISTRY_ROOT "HKCU"
!define MUI_LANGDLL_REGISTRY_KEY "Software\Obsidian-Agent"
!define MUI_LANGDLL_REGISTRY_VALUENAME "Sprache"
!define MUI_LANGDLL_ALLLANGUAGES

!define MUI_WELCOMEPAGE_TEXT "$(WillkommenText)"
!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!define MUI_FINISHPAGE_TEXT "$(FertigText)"
!define MUI_FINISHPAGE_RUN
!define MUI_FINISHPAGE_RUN_NOTCHECKED
!define MUI_FINISHPAGE_RUN_TEXT "$(Oeffnen)"
!define MUI_FINISHPAGE_RUN_FUNCTION Oeffnen
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES

!insertmacro MUI_LANGUAGE "German"
!insertmacro MUI_LANGUAGE "English"
!insertmacro MUI_LANGUAGE "French"
!insertmacro MUI_LANGUAGE "Italian"
!insertmacro MUI_LANGUAGE "Spanish"
!insertmacro MUI_LANGUAGE "Romanian"
!insertmacro MUI_RESERVEFILE_LANGDLL

LangString Code ${LANG_GERMAN} "de"
LangString Code ${LANG_ENGLISH} "en"
LangString Code ${LANG_FRENCH} "fr"
LangString Code ${LANG_ITALIAN} "it"
LangString Code ${LANG_SPANISH} "es"
LangString Code ${LANG_ROMANIAN} "ro"

LangString WillkommenText ${LANG_GERMAN} "Obsidian-Agent unterstützt Projektmanagement mit Obsidian nach HERMES 2022 und SAFe.$\r$\n$\r$\nDie Installation braucht keine Administratorrechte. Danach öffnet sich ein Fenster, das Python einrichtet und nach deinem Obsidian-Vault fragt.$\r$\n$\r$\nPython 3.10 oder neuer wird benötigt und bei Bedarf automatisch installiert."
LangString WillkommenText ${LANG_ENGLISH} "Obsidian-Agent supports project management with Obsidian according to HERMES 2022 and SAFe.$\r$\n$\r$\nThe installation does not need administrator rights. Afterwards a window opens that sets up Python and asks for your Obsidian vault.$\r$\n$\r$\nPython 3.10 or newer is required and installed automatically if needed."
LangString WillkommenText ${LANG_FRENCH} "Obsidian-Agent facilite la gestion de projet avec Obsidian selon HERMES 2022 et SAFe.$\r$\n$\r$\nL'installation ne nécessite pas de droits d'administrateur. Une fenêtre s'ouvre ensuite pour configurer Python et demander votre coffre Obsidian.$\r$\n$\r$\nPython 3.10 ou plus récent est requis et installé automatiquement si nécessaire."
LangString WillkommenText ${LANG_ITALIAN} "Obsidian-Agent supporta la gestione dei progetti con Obsidian secondo HERMES 2022 e SAFe.$\r$\n$\r$\nL'installazione non richiede diritti di amministratore. In seguito si apre una finestra che configura Python e chiede il vault Obsidian.$\r$\n$\r$\nÈ necessario Python 3.10 o più recente, che viene installato automaticamente se necessario."
LangString WillkommenText ${LANG_SPANISH} "Obsidian-Agent facilita la gestión de proyectos con Obsidian según HERMES 2022 y SAFe.$\r$\n$\r$\nLa instalación no necesita derechos de administrador. Después se abre una ventana que configura Python y pide su bóveda de Obsidian.$\r$\n$\r$\nSe necesita Python 3.10 o posterior, que se instala automáticamente si hace falta."
LangString WillkommenText ${LANG_ROMANIAN} "Obsidian-Agent sprijină managementul proiectelor cu Obsidian conform HERMES 2022 și SAFe.$\r$\n$\r$\nInstalarea nu necesită drepturi de administrator. Apoi se deschide o fereastră care configurează Python și cere seiful Obsidian.$\r$\n$\r$\nEste necesar Python 3.10 sau mai nou, instalat automat dacă este nevoie."

LangString FertigText ${LANG_GERMAN} "Obsidian-Agent ist eingerichtet. Er startet ab jetzt bei jeder Anmeldung im Hintergrund. Öffnen über das Startmenü oder die Verknüpfung auf dem Desktop."
LangString FertigText ${LANG_ENGLISH} "Obsidian-Agent is set up. From now on it starts in the background at every login. Open it from the Start menu or the desktop shortcut."
LangString FertigText ${LANG_FRENCH} "Obsidian-Agent est configuré. Il démarre désormais en arrière-plan à chaque ouverture de session. Ouvrez-le depuis le menu Démarrer ou le raccourci du bureau."
LangString FertigText ${LANG_ITALIAN} "Obsidian-Agent è configurato. Da ora si avvia in background a ogni accesso. Aprirlo dal menu Start o dal collegamento sul desktop."
LangString FertigText ${LANG_SPANISH} "Obsidian-Agent está configurado. A partir de ahora se inicia en segundo plano en cada inicio de sesión. Ábralo desde el menú Inicio o el acceso directo del escritorio."
LangString FertigText ${LANG_ROMANIAN} "Obsidian-Agent este configurat. De acum pornește în fundal la fiecare autentificare. Deschideți-l din meniul Start sau din scurtătura de pe desktop."

LangString Oeffnen ${LANG_GERMAN} "Obsidian-Agent jetzt öffnen"
LangString Oeffnen ${LANG_ENGLISH} "Open Obsidian-Agent now"
LangString Oeffnen ${LANG_FRENCH} "Ouvrir Obsidian-Agent maintenant"
LangString Oeffnen ${LANG_ITALIAN} "Aprire Obsidian-Agent ora"
LangString Oeffnen ${LANG_SPANISH} "Abrir Obsidian-Agent ahora"
LangString Oeffnen ${LANG_ROMANIAN} "Deschide Obsidian-Agent acum"

LangString Einrichten ${LANG_GERMAN} "Python und Vault werden eingerichtet …"
LangString Einrichten ${LANG_ENGLISH} "Setting up Python and vault …"
LangString Einrichten ${LANG_FRENCH} "Configuration de Python et du coffre …"
LangString Einrichten ${LANG_ITALIAN} "Configurazione di Python e del vault …"
LangString Einrichten ${LANG_SPANISH} "Configurando Python y la bóveda …"
LangString Einrichten ${LANG_ROMANIAN} "Se configurează Python și seiful …"

LangString Deinstallieren ${LANG_GERMAN} "Obsidian-Agent deinstallieren"
LangString Deinstallieren ${LANG_ENGLISH} "Uninstall Obsidian-Agent"
LangString Deinstallieren ${LANG_FRENCH} "Désinstaller Obsidian-Agent"
LangString Deinstallieren ${LANG_ITALIAN} "Disinstallare Obsidian-Agent"
LangString Deinstallieren ${LANG_SPANISH} "Desinstalar Obsidian-Agent"
LangString Deinstallieren ${LANG_ROMANIAN} "Dezinstalează Obsidian-Agent"

!define PS 'powershell.exe -NoProfile -ExecutionPolicy Bypass'
!define UNINST_KEY "Software\Microsoft\Windows\CurrentVersion\Uninstall\Obsidian-Agent"

Function .onInit
  !insertmacro MUI_LANGDLL_DISPLAY
FunctionEnd

Function un.onInit
  !insertmacro MUI_UNGETLANGUAGE
FunctionEnd

Function Oeffnen
  Exec '${PS} -WindowStyle Hidden -File "$INSTDIR\windows\start.ps1"'
FunctionEnd

Section "Obsidian-Agent" SecMain
  SetOutPath "$INSTDIR"
  ; Programmdateien (config.json, planer.db und .venv bleiben bei einer Aktualisierung erhalten)
  File /r /x config.json /x planer.db /x .venv /x __pycache__ /x tools /x installer.nsi "${QUELLE}\*.*"
  WriteUninstaller "$INSTDIR\Uninstall.exe"
  WriteRegStr HKCU "Software\Obsidian-Agent" "InstallDir" "$INSTDIR"

  CreateDirectory "$SMPROGRAMS\Obsidian-Agent"
  CreateShortcut "$SMPROGRAMS\Obsidian-Agent\Obsidian-Agent.lnk" "powershell.exe" \
    '-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "$INSTDIR\windows\start.ps1"' "$INSTDIR\windows\icon.ico" 0 SW_SHOWMINIMIZED
  CreateShortcut "$SMPROGRAMS\Obsidian-Agent\$(Deinstallieren).lnk" "$INSTDIR\Uninstall.exe"
  CreateShortcut "$DESKTOP\Obsidian-Agent.lnk" "powershell.exe" \
    '-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "$INSTDIR\windows\start.ps1"' "$INSTDIR\windows\icon.ico" 0 SW_SHOWMINIMIZED

  WriteRegStr HKCU "${UNINST_KEY}" "DisplayName" "Obsidian-Agent"
  WriteRegStr HKCU "${UNINST_KEY}" "DisplayVersion" "${VERSION}"
  WriteRegStr HKCU "${UNINST_KEY}" "Publisher" "Obsidian-Agent"
  WriteRegStr HKCU "${UNINST_KEY}" "DisplayIcon" "$INSTDIR\windows\icon.ico"
  WriteRegStr HKCU "${UNINST_KEY}" "InstallLocation" "$INSTDIR"
  WriteRegStr HKCU "${UNINST_KEY}" "UninstallString" '"$INSTDIR\Uninstall.exe"'
  WriteRegDWORD HKCU "${UNINST_KEY}" "NoModify" 1
  WriteRegDWORD HKCU "${UNINST_KEY}" "NoRepair" 1

  DetailPrint "$(Einrichten)"
  ExecWait '${PS} -File "$INSTDIR\windows\install.ps1" -Sprache $(Code)'
SectionEnd

Section "Uninstall"
  IfFileExists "$INSTDIR\windows\uninstall.ps1" 0 +2
    ExecWait '${PS} -File "$INSTDIR\windows\uninstall.ps1" -OhnePause'
  Delete "$DESKTOP\Obsidian-Agent.lnk"
  RMDir /r "$SMPROGRAMS\Obsidian-Agent"
  RMDir /r "$INSTDIR"
  DeleteRegKey HKCU "${UNINST_KEY}"
  DeleteRegKey HKCU "Software\Obsidian-Agent"
SectionEnd
