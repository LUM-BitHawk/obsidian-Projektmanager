﻿# Obsidian-Agent öffnen: läuft er schon, wird nur der Browser geöffnet, sonst wird er gestartet.
# Ist er noch nicht eingerichtet, startet die Einrichtung.
$Dir = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
Set-Location $Dir
$VenvPyw = Join-Path $Dir '.venv\Scripts\pythonw.exe'
if (-not (Test-Path $VenvPyw)) {
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$Dir\windows\install.ps1`""
    exit
}
$Port = 5055
try { $Port = [int](Get-Content config.json -Raw -Encoding UTF8 | ConvertFrom-Json).port } catch {}
function Lauscht { [bool](Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue) }
if (-not (Lauscht)) {
    schtasks /Run /TN "Obsidian-Agent Weboberflaeche" *> $null
    if ($LASTEXITCODE -ne 0) { Start-Process -FilePath $VenvPyw -ArgumentList "`"$Dir\hintergrund.pyw`"" -WorkingDirectory $Dir }
    for ($i = 0; $i -lt 30 -and -not (Lauscht); $i++) { Start-Sleep -Milliseconds 500 }
}
Start-Process "http://127.0.0.1:$Port"
