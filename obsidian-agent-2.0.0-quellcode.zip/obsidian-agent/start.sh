#!/usr/bin/env bash
# Obsidian-Agent starten (Linux). Täglicher Sync per crontab -e:
# 0 4 * * *  cd /pfad/zu/obsidian-agent && .venv/bin/python agent.py sync --geplant
cd "$(dirname "$0")"
if [ ! -x .venv/bin/python ]; then
  python3 -m venv .venv && .venv/bin/pip install -q -r requirements.txt
fi
exec .venv/bin/python app.py
