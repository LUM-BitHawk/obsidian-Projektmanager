#!/bin/bash
# ======================================================================
#  Obsidian-Agent – Einrichtung unter macOS
#  Wird vom Paket (Obsidian-Agent.pkg) bzw. von der App beim ersten Start
#  aufgerufen, kann aber auch per Doppelklick ausgeführt werden.
#   1. Python 3.9+ suchen, .venv und Flask einrichten
#   2. Sprache setzen, Vault wählen, erster Sync
#   3. launchd: Oberfläche bei der Anmeldung, täglicher Sync
#  Optionen: --sprache de|en|fr|it|es|ro   --ohne-fragen (keine Rückfragen im Terminal)
# ======================================================================
cd "$(dirname "$0")/.." || exit 1
DIR="$(pwd)"
LA="$HOME/Library/LaunchAgents"
LOGDIR="$HOME/Library/Logs/obsidian-agent"
UIDN="$(id -u)"
SYNC_LABEL="ch.obsidian-agent.sync"
GUI_LABEL="ch.obsidian-agent.gui"
SP=""; FRAGEN=1
while [ $# -gt 0 ]; do
  case "$1" in
    --sprache) SP="$2"; shift ;;
    --ohne-fragen) FRAGEN=0 ;;
  esac
  shift
done
mkdir -p "$LOGDIR"
xattr -dr com.apple.quarantine "$DIR" 2>/dev/null
chmod +x "$DIR"/mac/*.command "$DIR"/start.sh 2>/dev/null

# --- Sprache ------------------------------------------------------------------------
if [ -z "$SP" ] && [ -f config.json ]; then
  SP=$(/usr/bin/plutil -extract sprache raw -o - config.json 2>/dev/null)
fi
if [ -z "$SP" ]; then
  SP=$(defaults read -g AppleLanguages 2>/dev/null | sed -n '2p' | tr -d ' ",' | cut -c1-2)
fi
case "$SP" in de|en|fr|it|es|ro) ;; *) SP="en" ;; esac

# --- 1. Python ------------------------------------------------------------------------
PY=""
for c in python3.13 python3.12 python3.11 python3.10 python3.9 /opt/homebrew/bin/python3 /usr/local/bin/python3 \
         /Library/Frameworks/Python.framework/Versions/Current/bin/python3 python3; do
  if command -v "$c" >/dev/null 2>&1 && "$c" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)' >/dev/null 2>&1; then
    PY="$(command -v "$c")"; break
  fi
done
if [ -z "$PY" ]; then
  case "$SP" in
    de) MSG="Python 3.9 oder neuer wurde nicht gefunden. Bitte von python.org installieren und danach Obsidian-Agent erneut öffnen." ;;
    fr) MSG="Python 3.9 ou plus récent est introuvable. Veuillez l'installer depuis python.org puis rouvrir Obsidian-Agent." ;;
    it) MSG="Python 3.9 o più recente non trovato. Installarlo da python.org e poi riaprire Obsidian-Agent." ;;
    es) MSG="No se ha encontrado Python 3.9 o posterior. Instálelo desde python.org y vuelva a abrir Obsidian-Agent." ;;
    ro) MSG="Python 3.9 sau mai nou nu a fost găsit. Instalați-l de pe python.org și apoi deschideți din nou Obsidian-Agent." ;;
    *)  MSG="Python 3.9 or newer was not found. Please install it from python.org and then open Obsidian-Agent again." ;;
  esac
  echo "$MSG"
  osascript -e "display dialog \"$MSG\" buttons {\"OK\"} default button 1 with title \"Obsidian-Agent\" with icon caution" >/dev/null 2>&1
  open "https://www.python.org/downloads/macos/"
  exit 2
fi
T() { "$PY" -c "import json,sys; print(json.load(open('i18n/$SP.json', encoding='utf-8'))['installer'][sys.argv[1]])" "$1"; }

echo ""
echo "=== $(T titel) ==="
echo "$DIR"
echo ""

# --- 2. Python-Umgebung -----------------------------------------------------------------
if [ ! -x .venv/bin/python ]; then
  echo "... $(T venv)"
  "$PY" -m venv .venv || { echo "[X] $(T python_fehlt)"; exit 1; }
fi
.venv/bin/python -m pip install -q --upgrade pip >/dev/null 2>&1
.venv/bin/python -m pip install -q -r requirements.txt || { echo "[X] $(T pip_fehler)"; osascript -e "display dialog \"$(T pip_fehler)\" buttons {\"OK\"} with title \"Obsidian-Agent\"" >/dev/null 2>&1; exit 1; }
VPY="$DIR/.venv/bin/python"
echo "[OK] $(T bereit) ($("$VPY" --version 2>&1))"

# --- 3. Sprache und Vault -------------------------------------------------------------------
"$VPY" agent.py sprache "$SP" >/dev/null
echo "[OK] $(T sprache_gesetzt): $SP"
if ! "$VPY" -c "import agent,os,sys; c=agent.load_config(); sys.exit(0 if os.path.isdir(os.path.expanduser(c['vault_path'])) else 1)" 2>/dev/null; then
  echo "... $(T vault_waehlen)"
  PROMPT="$(T vault_dialog)"
  VAULT=$(osascript -e "POSIX path of (choose folder with prompt \"$PROMPT\")" 2>/dev/null)
  if [ -z "$VAULT" ]; then
    echo "[!!] $(T vault_keiner)"
  else
    "$VPY" -c "import agent,sys; c=agent.load_config(); c['vault_path']=sys.argv[1].rstrip('/'); agent.save_config(c)" "$VAULT"
    echo "[OK] Vault: $VAULT"
  fi
else
  echo "[OK] Vault: $("$VPY" -c "import agent; print(agent.load_config()['vault_path'])")"
fi
"$VPY" agent.py sync 2>&1 | tail -1

# --- 4. launchd ---------------------------------------------------------------------------
mkdir -p "$LA"
AUTO=j
if [ "$FRAGEN" = 1 ]; then
  read -r -p "Autostart (j/y/n)? [j] " AUTO; AUTO=${AUTO:-j}
fi
"$VPY" - "$DIR" "$LA" "$LOGDIR" "$SYNC_LABEL" "$GUI_LABEL" "$AUTO" <<'PYEOF'
import plistlib, sys, os
sys.path.insert(0, sys.argv[1])
import agent
d, la, logdir, sync_label, gui_label, auto = sys.argv[1:7]
py = os.path.join(d, ".venv", "bin", "python")
h, m = (int(x) for x in agent.load_config().get("sync_zeit", "04:00").split(":"))
with open(os.path.join(la, sync_label + ".plist"), "wb") as f:
    plistlib.dump({"Label": sync_label, "ProgramArguments": [py, os.path.join(d, "agent.py"), "sync", "--geplant"],
                   "WorkingDirectory": d, "StartCalendarInterval": {"Hour": h, "Minute": m},
                   "StandardOutPath": os.path.join(logdir, "sync.log"),
                   "StandardErrorPath": os.path.join(logdir, "sync.log")}, f)
gui_path = os.path.join(la, gui_label + ".plist")
if auto.lower().startswith(("j", "y", "o", "s", "d")):
    with open(gui_path, "wb") as f:
        plistlib.dump({"Label": gui_label, "ProgramArguments": [py, os.path.join(d, "app.py")], "WorkingDirectory": d,
                       "RunAtLoad": True, "KeepAlive": {"SuccessfulExit": False},
                       "EnvironmentVariables": {"OBSIDIAN_AGENT_NO_BROWSER": "1"},
                       "StandardOutPath": os.path.join(logdir, "gui.log"),
                       "StandardErrorPath": os.path.join(logdir, "gui.log")}, f)
elif os.path.exists(gui_path):
    os.remove(gui_path)
print(f"{h:02d}:{m:02d}")
PYEOF
lade() {
  local plist="$LA/$1.plist"
  launchctl bootout "gui/$UIDN/$1" 2>/dev/null || launchctl unload "$plist" 2>/dev/null
  [ -f "$plist" ] && { launchctl bootstrap "gui/$UIDN" "$plist" 2>/dev/null || launchctl load -w "$plist"; }
}
lade "$SYNC_LABEL"; lade "$GUI_LABEL"
echo "[OK] $(T aufgabe_sync) $("$VPY" -c "import agent; print(agent.load_config().get('sync_zeit','04:00'))")"
[ -f "$LA/$GUI_LABEL.plist" ] && echo "[OK] $(T aufgabe_gui)"

# --- 5. Ordnerrechte von macOS prüfen ---------------------------------------------------------
: > "$LOGDIR/sync.log"
launchctl kickstart "gui/$UIDN/$SYNC_LABEL" 2>/dev/null
sleep 4
if grep -qiE "Operation not permitted|PermissionError" "$LOGDIR/sync.log"; then
  REAL=$("$VPY" -c "import os,sys; print(os.path.realpath(sys.executable))")
  echo "[!!] $(T mac_rechte)"
  echo "     $REAL"
  osascript -e "display dialog \"$(T mac_rechte)

$REAL\" buttons {\"OK\"} with title \"Obsidian-Agent\"" >/dev/null 2>&1
  open "x-apple.systempreferences:com.apple.preference.security?Privacy_AllFiles" 2>/dev/null
fi

PORT=$("$VPY" -c "import agent; print(agent.load_config().get('port', 5055))")
for i in $(seq 1 20); do
  curl -s -o /dev/null "http://127.0.0.1:$PORT" && break
  sleep 0.5
done
echo ""
echo "[OK] $(T fertig) http://127.0.0.1:$PORT"
echo "     $LOGDIR"
exit 0
