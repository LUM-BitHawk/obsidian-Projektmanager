#!/bin/bash
# Obsidian-Agent öffnen: läuft er schon, öffnet sich nur der Browser, sonst wird er gestartet.
# Ist er noch nicht eingerichtet, startet die Einrichtung im Terminal.
cd "$(dirname "$0")/.." || exit 1
DIR="$(pwd)"
if [ ! -x .venv/bin/python ]; then
  exec "$DIR/mac/install.command"
fi
PORT=$(.venv/bin/python -c "import agent; print(agent.load_config().get('port', 5055))" 2>/dev/null || echo 5055)
if ! curl -s -o /dev/null "http://127.0.0.1:$PORT"; then
  if ! launchctl kickstart "gui/$(id -u)/ch.obsidian-agent.gui" 2>/dev/null; then
    mkdir -p "$HOME/Library/Logs/obsidian-agent"
    OBSIDIAN_AGENT_NO_BROWSER=1 nohup .venv/bin/python app.py >> "$HOME/Library/Logs/obsidian-agent/gui.log" 2>&1 &
  fi
  for i in $(seq 1 30); do curl -s -o /dev/null "http://127.0.0.1:$PORT" && break; sleep 0.5; done
fi
open "http://127.0.0.1:$PORT"
