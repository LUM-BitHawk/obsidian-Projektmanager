#!/bin/bash
# Obsidian-Agent deinstallieren (macOS): beendet den Agent, entfernt launchd-Einträge,
# sichert config.json und planer.db auf den Schreibtisch und entfernt Programm und App.
# Der Obsidian-Vault bleibt unverändert.
cd "$(dirname "$0")/.." || exit 1
DIR="$(pwd)"
[ -f "$DIR/agent.py" ] || { echo "agent.py?"; exit 1; }
SP=$(/usr/bin/plutil -extract sprache raw -o - config.json 2>/dev/null); [ -f "i18n/$SP.json" ] || SP=en
T() { /usr/bin/python3 -c "import json,sys; print(json.load(open('i18n/$SP.json', encoding='utf-8'))['installer'][sys.argv[1]])" "$1" 2>/dev/null; }
for L in ch.obsidian-agent.gui ch.obsidian-agent.sync; do
  launchctl bootout "gui/$(id -u)/$L" 2>/dev/null
  rm -f "$HOME/Library/LaunchAgents/$L.plist"
done
pkill -f "$DIR/app.py" 2>/dev/null
if [ -f config.json ] || [ -f planer.db ]; then
  B="$HOME/Desktop/obsidian-agent-backup_$(date +%Y-%m-%d_%H%M)"
  mkdir -p "$B"; cp -f config.json planer.db "$B"/ 2>/dev/null
  echo "$(T backup) $B"
fi
rm -rf "$HOME/Library/Logs/obsidian-agent"
[ -d "/Applications/Obsidian-Agent.app" ] && rm -rf "/Applications/Obsidian-Agent.app" 2>/dev/null
pkgutil --forget ch.obsidian-agent.pkg >/dev/null 2>&1
cd "$HOME" && rm -rf "$DIR"
echo "$(T deinstall_fertig)"
