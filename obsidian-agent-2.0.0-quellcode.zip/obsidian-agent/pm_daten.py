"""
Obsidian-Agent – Fachdaten für HERMES 2022 und SAFe 6
====================================================
Kennungen (z.B. Phasen, Status) sind sprachneutral und stehen so im Frontmatter
der Notizen. Die angezeigten Bezeichnungen werden mit t() übersetzt.
"""
from __future__ import annotations

from i18n import N_

METHODEN = {
    "": N_("Ohne Methode"),
    "hermes_klassisch": N_("HERMES klassisch"),
    "hermes_agil": N_("HERMES agil"),
    "safe": N_("SAFe"),
    "hermes_safe": N_("HERMES agil + SAFe"),
}


def ist_hermes(methode: str) -> bool:
    return (methode or "").startswith("hermes")


def ist_safe(methode: str) -> bool:
    return "safe" in (methode or "")


# Projektstruktur: Rolle -> Zweck (Ordnernamen je Sprache in i18n/<sprache>.json)
STRUKTUR_ZWECK = {
    "auftrag": N_("Projektinitialisierungsauftrag, Durchführungsauftrag, Ziele, Business Case und Verträge."),
    "planung": N_("Projektmanagementplan, Termin-, Ressourcen- und Kostenplanung."),
    "steuerung": N_("HERMES-Meilensteine und Freigaben, Statusberichte, Änderungsanträge sowie SAFe Planning Intervals."),
    "risiken": N_("Risiken mit ROAM-Status und das Entscheid-Log."),
    "meetings": N_("Protokolle von Projektausschuss, Projektsitzungen und Workshops."),
    "ergebnisse": N_("Konzepte, Spezifikationen, Testprotokolle und Abnahmen."),
    "stakeholder": N_("Stakeholder-Analyse, Kontakte und Kommunikation."),
    "archiv": N_("Abgeschlossene Phasen und nicht mehr gültige Dokumente."),
}

# --- HERMES 2022 ----------------------------------------------------------------
PHASEN_NAME = {
    "initialisierung": N_("Initialisierung"),
    "konzept": N_("Konzept"),
    "realisierung": N_("Realisierung"),
    "einfuehrung": N_("Einführung"),
    "umsetzung": N_("Umsetzung"),
    "abschluss": N_("Abschluss"),
}
PHASEN = {
    "hermes_klassisch": ["initialisierung", "konzept", "realisierung", "einfuehrung", "abschluss"],
    "hermes_agil": ["initialisierung", "umsetzung", "abschluss"],
}
PHASEN["hermes_safe"] = PHASEN["hermes_agil"]

_PRUEF_INIT = [
    N_("Projektinitialisierungsauftrag liegt vor (Ausgangslage, Ziele der Initialisierung, Aufwand)"),
    N_("Auftraggeber/in und Projektleiter/in sind bestimmt"),
    N_("Ressourcen für die Phase Initialisierung sind freigegeben"),
]
_PRUEF_DURCHF = [
    N_("Studie: Situationsanalyse, Lösungsvarianten und Variantenwahl"),
    N_("Durchführungsauftrag: Ziele, Abgrenzung, Kosten, Termine, Nutzen"),
    N_("Projektmanagementplan (Vorgehen, Organisation, Planung, Hilfsmittel)"),
    N_("Stakeholder- und Risikoanalyse erstellt"),
    N_("Schutzbedarfsanalyse (ISDS) durchgeführt"),
    N_("Projektausschuss ist besetzt"),
]
_PRUEF_AGIL = [
    N_("Initialer Product Backlog und Releaseplanung vorhanden"),
    N_("Rollen für das agile Vorgehen besetzt (Product Owner, Entwicklungsteam, Scrum Master)"),
]
_PRUEF_ABSCHLUSS = [
    N_("Projektschlussbeurteilung erstellt (Soll/Ist Ziele, Kosten, Termine)"),
    N_("Erfahrungen (Lessons Learned) dokumentiert"),
    N_("Offene Pendenzen an die Stammorganisation übergeben"),
    N_("Projektorganisation aufgelöst, Unterlagen archiviert"),
]

MS_NAME = {
    "projektinitialisierung": N_("Projektinitialisierungsfreigabe"),
    "durchfuehrung": N_("Durchführungsfreigabe"),
    "phase_realisierung": N_("Phasenfreigabe Realisierung"),
    "phase_einfuehrung": N_("Phasenfreigabe Einführung"),
    "phase_abschluss": N_("Phasenfreigabe Abschluss"),
    "projektabschluss": N_("Projektabschluss"),
}
MS_ENTSCHEID = {
    "projektinitialisierung": N_("Auftraggeber/in"),
    "durchfuehrung": N_("Auftraggeber/in mit Portfoliomanagement"),
}
MS_ENTSCHEID_STANDARD = N_("Auftraggeber/in, Projektausschuss")

# (Kennung, Phase, Prüfpunkte)
MEILENSTEINE = {
    "hermes_klassisch": [
        ("projektinitialisierung", "initialisierung", _PRUEF_INIT),
        ("durchfuehrung", "initialisierung", _PRUEF_DURCHF),
        ("phase_realisierung", "konzept", [
            N_("Lösungsanforderungen bzw. Systemanforderungen abgenommen"),
            N_("Lösungsarchitektur / Systemkonzept erstellt"),
            N_("ISDS-Konzept erstellt"),
            N_("Testkonzept erstellt"),
            N_("Projektplan und Kosten aktualisiert"),
        ]),
        ("phase_einfuehrung", "realisierung", [
            N_("Lösung realisiert und getestet (Testprotokoll)"),
            N_("Vorabnahme erteilt"),
            N_("Einführungs- und Migrationsplanung erstellt"),
            N_("Betrieb, Schulung und Anwenderdokumentation vorbereitet"),
        ]),
        ("phase_abschluss", "einfuehrung", [
            N_("Abnahme erteilt"),
            N_("Betriebsaufnahme erfolgt"),
            N_("Migration durchgeführt (falls relevant)"),
        ]),
        ("projektabschluss", "abschluss", _PRUEF_ABSCHLUSS),
    ],
    "hermes_agil": [
        ("projektinitialisierung", "initialisierung", _PRUEF_INIT),
        ("durchfuehrung", "initialisierung", _PRUEF_DURCHF + _PRUEF_AGIL),
        ("phase_abschluss", "umsetzung", [
            N_("Letztes Release abgenommen"),
            N_("Betriebsaufnahme erfolgt"),
            N_("Migration durchgeführt (falls relevant)"),
        ]),
        ("projektabschluss", "abschluss", _PRUEF_ABSCHLUSS),
    ],
}
MEILENSTEINE["hermes_safe"] = MEILENSTEINE["hermes_agil"]
MS_FREIGABE_AUFTRAGGEBER = {"projektinitialisierung", "durchfuehrung"}

MEILENSTEIN_VORSCHLAEGE = [N_("Releasefreigabe Release 1"), N_("Lösungsarchitektur"), N_("ISDS-Konzept"),
                           N_("Vorabnahme"), N_("Abnahme"), N_("Betriebsaufnahme"), N_("Abnahme Migration"),
                           N_("Zwischenevaluation")]

MS_STATUS = {"geplant": N_("geplant"), "gefaehrdet": N_("gefährdet"), "verschoben": N_("verschoben"),
             "erreicht": N_("erreicht"), "freigegeben": N_("freigegeben"), "entfallen": N_("entfallen")}
MS_ERLEDIGT = {"erreicht", "freigegeben", "entfallen"}

# --- Risiken, Entscheide, SAFe ----------------------------------------------------
STUFEN = {"hoch": N_("hoch"), "mittel": N_("mittel"), "niedrig": N_("niedrig")}
STUFE_WERT = {"niedrig": 1, "mittel": 2, "hoch": 3}
ROAM = {"offen": N_("Offen"), "owned": N_("Owned"), "mitigated": N_("Mitigated"),
        "accepted": N_("Accepted"), "resolved": N_("Resolved")}
ENTSCHEID_STATUS = {"beantragt": N_("beantragt"), "entschieden": N_("entschieden"),
                    "zurueckgestellt": N_("zurückgestellt"), "abgelehnt": N_("abgelehnt")}
GREMIEN = [N_("Projektausschuss"), N_("Auftraggeber/in"), N_("Projektleitung"), N_("Business Owner"),
           N_("ART Sync / RTE"), N_("Product Management"), N_("Fachausschuss")]
PI_STATUS = {"planung": N_("Planung"), "laufend": N_("laufend"), "abgeschlossen": N_("abgeschlossen")}
OBJ_STATUS = {"geplant": N_("geplant"), "in_arbeit": N_("in Arbeit"), "erreicht": N_("erreicht"),
              "teilweise": N_("teilweise erreicht"), "nicht_erreicht": N_("nicht erreicht")}
TASK_STATUS = {"offen": N_("offen"), "in_arbeit": N_("in Arbeit"), "wartend": N_("wartend"),
               "erledigt": N_("erledigt")}

HERMES_DOKU = {"projektmanagementplan": N_("Projektmanagementplan"), "statusbericht": N_("Projektstatusbericht"),
               "aenderungsantrag": N_("Änderungsantrag"), "projektausschuss": N_("Projektausschuss-Protokoll"),
               "schlussbeurteilung": N_("Projektschlussbeurteilung")}
SAFE_DOKU = {"retro": N_("Iterations-Retrospektive"), "art_sync": N_("ART Sync / Scrum of Scrums")}

# Vorlagen: Schlüssel -> (Bezeichnung, Ablage: Rolle der Projektstruktur, Unterordner)
VORLAGEN = {
    "task": (N_("Task"), None, None),
    "meeting": (N_("Meeting-Protokoll"), "meetings", None),
    "person": (N_("Person / Stakeholder"), None, None),
    "jourfixe": (N_("Jour Fixe"), None, None),
    "meilenstein": (N_("HERMES-Meilenstein"), "steuerung", "meilensteine"),
    "risiko": (N_("Risiko (ROAM)"), "risiken", "risiken"),
    "entscheid": (N_("Entscheid"), "risiken", "entscheide"),
    "projektmanagementplan": (N_("Projektmanagementplan"), "planung", None),
    "statusbericht": (N_("Projektstatusbericht"), "steuerung", None),
    "aenderungsantrag": (N_("Änderungsantrag"), "steuerung", None),
    "projektausschuss": (N_("Projektausschuss-Protokoll"), "meetings", None),
    "schlussbeurteilung": (N_("Projektschlussbeurteilung"), "steuerung", None),
    "pi": (N_("SAFe Planning Interval"), "steuerung", "pi"),
    "pi_objective": (N_("SAFe PI Objective"), "steuerung", "pi"),
    "inspect_adapt": (N_("SAFe Inspect & Adapt"), "steuerung", "pi"),
    "retro": (N_("Iterations-Retrospektive"), "steuerung", "pi"),
    "art_sync": (N_("ART Sync / Scrum of Scrums"), "steuerung", "pi"),
}
