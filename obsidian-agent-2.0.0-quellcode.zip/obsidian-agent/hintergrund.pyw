"""
Obsidian-Agent – Start im Hintergrund (Windows, ohne Konsolenfenster).
Wird von der geplanten Aufgabe "Obsidian-Agent Weboberflaeche" bei der Anmeldung
mit pythonw.exe gestartet. Öffnet keinen Browser und schreibt ein Protokoll nach
%LOCALAPPDATA%\\obsidian-agent\\gui.log
"""
import logging
import os
import runpy
import sys
from pathlib import Path

BASE = Path(__file__).resolve().parent
os.chdir(BASE)
sys.path.insert(0, str(BASE))
os.environ["OBSIDIAN_AGENT_NO_BROWSER"] = "1"

log_dir = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "obsidian-agent"
log_dir.mkdir(parents=True, exist_ok=True)
log = open(log_dir / "gui.log", "w", encoding="utf-8", buffering=1)
sys.stdout = sys.stderr = log
logging.getLogger("werkzeug").setLevel(logging.WARNING)  # keine Zeile pro Seitenaufruf

try:
    runpy.run_path(str(BASE / "app.py"), run_name="__main__")
except SystemExit:
    raise
except BaseException:
    import traceback
    traceback.print_exc()
    raise
