"""
Obsidian-Agent – Kernlogik
==========================
Projektmanagement mit Obsidian nach HERMES 2022 und SAFe. Die Markdown-Dateien im
Vault sind die einzige Wahrheit, die SQLite-Datenbank ist Index und Planer.

CLI:
  python agent.py sync               # Vault einlesen, Tagesübersicht schreiben
  python agent.py sync --geplant     # wie oben, zählt als geplanter Tageslauf
  python agent.py heute              # heutige Tasks in der Konsole
  python agent.py projekt "Name" [--methode hermes_klassisch|hermes_agil|safe|hermes_safe]
  python agent.py sprache de|en|fr|it|es|ro
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import re
import sqlite3
import sys
import threading
import time
import urllib.parse
from pathlib import Path

import pm_daten as pm
from i18n import SPRACHEN, sprache

BASE_DIR = Path(__file__).resolve().parent
CONFIG_FILE = BASE_DIR / "config.json"

DEFAULT_CONFIG = {
    "vault_path": str(Path.home() / "Documents" / "Obsidian"),
    "db_path": "planer.db",
    "sprache": "de",
    "task_standard_ordner": "",
    "sync_zeit": "04:00",
    "demnaechst_tage": 7,
    "meilenstein_tage": 14,
    "port": 5055,
}
# Ordner, deren Standardnamen von der Sprache abhängen (beim ersten Start festgelegt)
ORDNER_KEYS = {"projekt_ordner": "projekte", "task_ordner": "tasks", "notiz_ordner": "notizen",
               "vorlagen_ordner": "vorlagen", "planer_ordner": "planer", "team_ordner": "team",
               "jourfixe_ordner": "jourfixe", "safe_ordner": "safe"}

ERLEDIGT_WERTE = {"erledigt", "done", "abgeschlossen", "fertig", "x", "true", "ja", "closed", "yes"}
PRIO_ORDER = {"hoch": 0, "mittel": 1, "niedrig": 2}
JF_TURNUS = {"woechentlich": 7, "zweiwoechentlich": 14, "vierwoechentlich": 28, "monatlich": 0}


# ---------------------------------------------------------------------------
# Konfiguration
# ---------------------------------------------------------------------------
def config_ergaenzen(cfg: dict) -> bool:
    """Fehlende sprachabhängige Ordnernamen ergänzen. Rückgabe: True, wenn etwas ergänzt wurde."""
    sp = sprache(cfg.get("sprache") or "de")
    neu = False
    for key, name in ORDNER_KEYS.items():
        if key not in cfg:
            cfg[key] = sp.ordner(name)
            neu = True
    for key, werte in (("projekt_struktur", sp.struktur()), ("unterordner", sp.unterordner())):
        aktuell = dict(cfg.get(key) or {})
        for k, v in werte.items():
            if k not in aktuell:
                aktuell[k] = v
                neu = True
        cfg[key] = aktuell
    return neu


def load_config() -> dict:
    cfg = dict(DEFAULT_CONFIG)
    vorhanden = CONFIG_FILE.exists()
    if vorhanden:
        try:
            cfg.update(json.loads(CONFIG_FILE.read_text(encoding="utf-8")))
        except json.JSONDecodeError:
            pass
    if cfg.get("sprache") not in SPRACHEN:
        cfg["sprache"] = "de"
    if config_ergaenzen(cfg) or not vorhanden:
        save_config(cfg)
    return cfg


def save_config(cfg: dict) -> None:
    CONFIG_FILE.write_text(json.dumps(cfg, indent=2, ensure_ascii=False), encoding="utf-8")


def sprache_setzen(code: str) -> dict:
    """Sprache setzen. Bei einer neuen Installation folgen auch die Ordnernamen der Sprache;
    bestehende Ordnernamen bleiben, damit der Vault nicht auseinanderfällt."""
    if code not in SPRACHEN:
        raise ValueError(code)
    cfg = dict(DEFAULT_CONFIG)
    if CONFIG_FILE.exists():
        cfg.update(json.loads(CONFIG_FILE.read_text(encoding="utf-8")))
    cfg["sprache"] = code
    config_ergaenzen(cfg)
    save_config(cfg)
    return cfg


# ---------------------------------------------------------------------------
# Hilfsfunktionen
# ---------------------------------------------------------------------------
FM_RE = re.compile(r"\A---[ \t]*\r?\n(.*?)^---[ \t]*(?:\r?\n|\Z)", re.S | re.M)
CHECK_RE = re.compile(r"^\s*[-*+] \[([ xX])\]", re.M)
MARKER_RE = re.compile(r"(?<![\w/#&])#(entscheid|risiko|blocker)(?![\w/-])", re.I)
WIKILINK_RE = re.compile(r"\[\[([^\]|]+)(?:\|([^\]]+))?\]\]")


def safe_name(name: str, underscore: bool = False) -> str:
    name = re.sub(r'[\\/:*?"<>|#^\[\]]', "", str(name)).strip().strip(".")
    name = re.sub(r"\s+", "_" if underscore else " ", name)
    return name[:120]


def parse_frontmatter(text: str) -> tuple[dict, str]:
    m = FM_RE.match(text)
    if not m:
        return {}, text
    data = {}
    for line in m.group(1).splitlines():
        if not line.strip() or line.lstrip().startswith("#") or ":" not in line:
            continue
        if line[0] in " \t-":
            continue
        k, v = line.split(":", 1)
        v = v.strip()
        if len(v) >= 2 and v[0] == v[-1] and v[0] in "\"'":
            v = v[1:-1]
        data[k.strip().lower()] = v
    return data, text[m.end():]


def fm_value(v) -> str:
    v = "" if v is None else str(v)
    if v.startswith("[["):
        return json.dumps(v, ensure_ascii=False)
    if re.search(r"[:#]\s|^[\[{&*!|>%@`]", v) and not re.match(r"^\[.*\]$", v):
        return json.dumps(v, ensure_ascii=False)
    return v


def set_frontmatter(text: str, values: dict) -> str:
    m = FM_RE.match(text)
    if not m:
        block = [f"{k}: {fm_value(v)}" for k, v in values.items()]
        return "---\n" + "\n".join(block) + "\n---\n" + text
    block = m.group(1).rstrip("\r\n").split("\n") if m.group(1).strip() else []
    for k, v in values.items():
        line = f"{k}: {fm_value(v)}"
        for i, existing in enumerate(block):
            if re.match(rf"^{re.escape(k)}\s*:", existing, re.I):
                block[i] = line
                break
        else:
            block.append(line)
    return "---\n" + "\n".join(block) + "\n---\n" + text[m.end():]


def parse_date(v) -> dt.date | None:
    if not v:
        return None
    s = str(v).strip().strip("[]\"' ")
    if not s:
        return None
    try:
        return dt.date.fromisoformat(s[:10])
    except ValueError:
        pass
    for fmt in ("%d.%m.%Y", "%d.%m.%y", "%Y/%m/%d", "%d/%m/%Y", "%d/%m/%y"):
        try:
            return dt.datetime.strptime(s, fmt).date()
        except ValueError:
            continue
    return None


def iso(d: dt.date | None) -> str | None:
    return d.isoformat() if d else None


def task_kategorie(t: dict, heute: dt.date) -> str:
    """heute | ueberfaellig | geplant | ohne_datum | erledigt"""
    if t.get("status") == "erledigt":
        return "erledigt"
    start = parse_date(t.get("start"))
    ende = parse_date(t.get("ende"))
    if not start and not ende:
        return "ohne_datum"
    start = start or ende
    ende = ende or start
    if ende < heute:
        return "ueberfaellig"
    if start > heute:
        return "geplant"
    return "heute"


def render_vorlage(text: str, werte: dict) -> str:
    for k, v in werte.items():
        text = text.replace("{{" + k + "}}", "" if v is None else str(v))
    return re.sub(r"\{\{[a-z_]+\}\}", "", text)


def marker_finden(body: str) -> list[tuple[int, str, str]]:
    """Zeilen mit #entscheid, #risiko oder #blocker (nicht in Code-Blöcken oder Inline-Code).
    Rückgabe: (Zeilennummer, Tag, Text ohne Tag und Listenzeichen). Leere Zeilen werden übersprungen."""
    out = []
    im_code = False
    for nr, zeile in enumerate(body.splitlines(), 1):
        if zeile.lstrip().startswith(("```", "~~~")):
            im_code = not im_code
            continue
        if im_code or "#" not in zeile:
            continue
        zeile = re.sub(r"`[^`]*`", "", zeile)
        tags = {m.group(1).lower() for m in MARKER_RE.finditer(zeile)}
        if not tags:
            continue
        txt = MARKER_RE.sub("", zeile)
        while True:
            neu = re.sub(r"^\s*(?:>\s*|[-*+]\s+|\d+[.)]\s+|\[.\]\s*)", "", txt)
            if neu == txt:
                break
            txt = neu
        txt = re.sub(r"\s{2,}", " ", txt.strip(" \t-–:|"))
        if not re.search(r"\w", txt):
            continue
        for tag in sorted(tags):
            out.append((nr, tag, txt[:500]))
    return out


def wikilinks_lesbar(text: str) -> str:
    return WIKILINK_RE.sub(lambda m: m.group(2) or m.group(1).split("/")[-1], text or "")


SCHEMA = """
CREATE TABLE IF NOT EXISTS tasks (
    pfad TEXT PRIMARY KEY,
    titel TEXT, projekt TEXT, start TEXT, ende TEXT,
    status TEXT, prioritaet TEXT, verantwortlich TEXT,
    checks_total INTEGER, checks_done INTEGER,
    erledigt_am TEXT, geaendert TEXT, aktiv INTEGER DEFAULT 1, jourfixe TEXT
);
CREATE TABLE IF NOT EXISTS tagesuebersicht (
    datum TEXT, pfad TEXT, titel TEXT, projekt TEXT,
    kategorie TEXT, status TEXT, ende TEXT, prioritaet TEXT,
    PRIMARY KEY (datum, pfad)
);
CREATE TABLE IF NOT EXISTS notizen (
    pfad TEXT PRIMARY KEY,
    titel TEXT, typ TEXT, projekt TEXT, tags TEXT, kategorie TEXT,
    geaendert TEXT, inhalt TEXT, meta TEXT
);
CREATE TABLE IF NOT EXISTS marker (
    pfad TEXT, zeile INTEGER, tag TEXT, text TEXT,
    projekt TEXT, datum TEXT, titel TEXT,
    PRIMARY KEY (pfad, zeile, tag)
);
CREATE TABLE IF NOT EXISTS sync_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    zeitpunkt TEXT, art TEXT, dateien INTEGER, tasks_offen INTEGER,
    tasks_heute INTEGER, tasks_erledigt INTEGER, lcm INTEGER,
    dauer_ms INTEGER, fehler TEXT
);
CREATE INDEX IF NOT EXISTS ix_tasks_status ON tasks(status, aktiv);
CREATE INDEX IF NOT EXISTS ix_notizen_typ ON notizen(typ);
CREATE INDEX IF NOT EXISTS ix_marker_tag ON marker(tag);
"""

SKIP_ORDNER = {".obsidian", ".trash", ".git", "node_modules"}


# ---------------------------------------------------------------------------
# Agent
# ---------------------------------------------------------------------------
class Agent:
    def __init__(self, cfg: dict | None = None):
        self.cfg = cfg or load_config()
        config_ergaenzen(self.cfg)
        self._lock = threading.Lock()
        self._init_db()

    # --- Sprache --------------------------------------------------------------
    @property
    def sp(self):
        return sprache(self.cfg.get("sprache") or "de")

    def t(self, text: str, **werte) -> str:
        return self.sp.t(text, **werte)

    def label(self, tabelle: dict, wert: str) -> str:
        return self.t(tabelle.get(wert, wert or ""))

    def datum(self, v) -> str:
        return self.sp.datum(parse_date(v))

    # --- Pfade -----------------------------------------------------------------
    @property
    def vault(self) -> Path:
        return Path(self.cfg["vault_path"]).expanduser()

    @property
    def db_path(self) -> Path:
        p = Path(self.cfg["db_path"]).expanduser()
        return p if p.is_absolute() else BASE_DIR / p

    def vault_ok(self) -> bool:
        return self.vault.is_dir()

    def ordner(self, key: str) -> Path:
        name = self.cfg.get(key, "") or ""
        return self.vault / name if name else self.vault

    def struktur(self, rolle: str) -> str:
        return self.cfg["projekt_struktur"][rolle]

    def unter(self, key: str) -> str:
        return self.cfg["unterordner"][key]

    def rel(self, p: Path) -> str:
        return p.relative_to(self.vault).as_posix()

    def abs_in_vault(self, rel: str, root_ok: bool = False) -> Path:
        p = (self.vault / (rel or "")).resolve()
        v = self.vault.resolve()
        if root_ok and p == v:
            return p
        if v not in p.parents:
            raise ValueError(self.t("Pfad liegt ausserhalb des Vaults"))
        return p

    def obsidian_link(self, rel: str) -> str:
        name = (self.cfg.get("obsidian_vault_name") or "").strip()
        params = {"vault": name, "file": rel} if name else {"path": str(self.vault / rel)}
        return "obsidian://open?" + urllib.parse.urlencode(params, quote_via=urllib.parse.quote)

    # --- DB --------------------------------------------------------------------
    def db(self) -> sqlite3.Connection:
        con = sqlite3.connect(self.db_path, timeout=30)
        con.row_factory = sqlite3.Row
        return con

    def _init_db(self):
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        with self.db() as con:
            con.executescript(SCHEMA)
            if "meta" not in {r[1] for r in con.execute("PRAGMA table_info(notizen)")}:
                con.execute("ALTER TABLE notizen ADD COLUMN meta TEXT")
            if "jourfixe" not in {r[1] for r in con.execute("PRAGMA table_info(tasks)")}:
                con.execute("ALTER TABLE tasks ADD COLUMN jourfixe TEXT")

    # --- Grundstruktur und Vorlagen ------------------------------------------------
    def vorlage_datei(self, key: str) -> str:
        return self.sp.d["vorlagen"][key][0]

    def ensure_basics(self):
        if not self.vault_ok():
            raise FileNotFoundError(self.t("Vault nicht gefunden: {pfad}", pfad=self.vault))
        for key in ("projekt_ordner", "task_ordner", "vorlagen_ordner", "planer_ordner",
                    "team_ordner", "jourfixe_ordner"):
            self.ordner(key).mkdir(parents=True, exist_ok=True)
        vdir = self.ordner("vorlagen_ordner")
        for key in pm.VORLAGEN:
            f = vdir / self.vorlage_datei(key)
            if not f.exists():
                f.write_text(self.sp.vorlage(key), encoding="utf-8")

    def vorlage_text(self, key: str) -> str:
        f = self.ordner("vorlagen_ordner") / self.vorlage_datei(key)
        return f.read_text(encoding="utf-8") if f.exists() else self.sp.vorlage(key)

    def dateiname(self, key: str, **werte) -> str:
        muster = self.sp.d["vorlagen"][key][1] if key in self.sp.d["vorlagen"] else self.sp.d["dateien"][key]
        return muster.format(**werte)

    @staticmethod
    def _unique(path: Path) -> Path:
        if not path.exists():
            return path
        i = 2
        while True:
            cand = path.with_name(f"{path.stem}_{i}{path.suffix}")
            if not cand.exists():
                return cand
            i += 1

    def _index_neu(self, *dateien: Path):
        with self.db() as con:
            for d in dateien:
                self._index_file(con, d, dt.date.today())

    def _schreiben(self, key: str, datei: Path, werte: dict, fm: dict | None = None) -> Path:
        """Notiz aus Vorlage schreiben, Pflichtfelder im Frontmatter absichern und indexieren."""
        werte = {k: ("" if v is None else v) for k, v in werte.items()}
        werte.setdefault("date", dt.date.today().isoformat())
        text = render_vorlage(self.vorlage_text(key), werte)
        text = set_frontmatter(text, {"typ": key, "titel": werte.get("title", ""), **(fm or {})})
        datei.parent.mkdir(parents=True, exist_ok=True)
        datei.write_text(text, encoding="utf-8")
        self._index_neu(datei)
        return datei

    # --- Projekte ------------------------------------------------------------------
    def projekt_struktur(self) -> dict[str, str]:
        """Rolle -> Ordnername, in der Reihenfolge der Nummerierung."""
        return dict(sorted(self.cfg["projekt_struktur"].items(), key=lambda kv: kv[1].lower()))

    def _projekt_root(self, projekt: str) -> Path:
        root = self.ordner("projekt_ordner") / safe_name(projekt)
        if not projekt or not root.is_dir():
            raise ValueError(self.t("Projekt '{name}' existiert nicht.", name=projekt))
        return root

    def _projekt_uebersicht(self, name: str) -> Path | None:
        root = self.ordner("projekt_ordner") / safe_name(name)
        f = root / f"{self.dateiname('projekt', titel_=safe_name(name, True))}.md"
        if f.is_file():
            return f
        if root.is_dir():
            for k in sorted(root.glob("_*.md")):
                fm, _ = parse_frontmatter(k.read_text(encoding="utf-8", errors="replace"))
                if (fm.get("typ") or "").lower() == "projekt":
                    return k
        return None

    def projekt_methode(self, name: str) -> str:
        f = self._projekt_uebersicht(name)
        if not f:
            return ""
        fm, _ = parse_frontmatter(f.read_text(encoding="utf-8", errors="replace"))
        m = (fm.get("methode") or "").strip().lower()
        return m if m in pm.METHODEN else ""

    def projekte(self) -> list[dict]:
        root = self.ordner("projekt_ordner")
        if not root.is_dir():
            return []
        result = []
        struktur = self.projekt_struktur().values()
        with self.db() as con:
            for d in sorted(root.iterdir(), key=lambda p: p.name.lower()):
                if not d.is_dir() or d.name.startswith((".", "_")):
                    continue
                if not self.cfg.get("projekt_ordner") and not self._projekt_uebersicht(d.name):
                    continue
                offen = con.execute("SELECT COUNT(*) FROM tasks WHERE aktiv=1 AND status!='erledigt' "
                                    "AND projekt=?", (d.name,)).fetchone()[0]
                methode = self.projekt_methode(d.name)
                result.append({"name": d.name, "pfad": self.rel(d), "offen": offen, "methode": methode,
                               "methode_label": self.label(pm.METHODEN, methode),
                               "vollstaendig": all((d / o).is_dir() for o in struktur)})
        return result

    def projekt_unterordner(self, projekt: str, max_tiefe: int = 3) -> list[dict]:
        root = self.ordner("projekt_ordner") / safe_name(projekt)
        if not projekt or not root.is_dir():
            return []
        out: list[dict] = []

        def walk(d: Path, tiefe: int):
            try:
                kinder = sorted((k for k in d.iterdir() if k.is_dir()), key=lambda p: p.name.lower())
            except OSError:
                return
            for k in kinder:
                if k.name.startswith("."):
                    continue
                out.append({"pfad": k.relative_to(root).as_posix(), "name": k.name, "tiefe": tiefe})
                if tiefe + 1 < max_tiefe:
                    walk(k, tiefe + 1)
        walk(root, 0)
        return out

    def _readme_schreiben(self, d: Path, projekt: str, rolle: str) -> None:
        readme = d / f"readme_{d.name}.md"
        if readme.exists():
            return
        teile = d.name.split("_", 1)
        titel = (teile[1] if len(teile) == 2 and teile[0].isdigit() else d.name).replace("_", " ")
        readme.write_text(render_vorlage(self.sp.vorlage("readme"), {
            "projekt": fm_value(projekt), "ordner": fm_value(d.name), "date": dt.date.today().isoformat(),
            "titel": f"{titel} · {projekt}" if projekt else titel, "pfad": self.rel(d),
            "zweck": self.t(pm.STRUKTUR_ZWECK.get(rolle, ""))}), encoding="utf-8")

    def projekt_anlegen(self, name: str, kunde: str = "", beschreibung: str = "",
                        methode: str | None = None) -> Path:
        """methode=None: bestehende Methode beibehalten (neue Projekte: ohne Methode)."""
        self.ensure_basics()
        name = safe_name(name)
        if not name:
            raise ValueError(self.t("Bitte einen Projektnamen eingeben."))
        if methode is not None and methode not in pm.METHODEN:
            raise ValueError(self.t("Unbekannte Projektmethode: {m}", m=methode))
        root = self.ordner("projekt_ordner") / name
        root.mkdir(parents=True, exist_ok=True)
        if methode is None:
            methode = self.projekt_methode(name)
        for rolle, ordner in self.projekt_struktur().items():
            d = root / ordner
            d.mkdir(exist_ok=True)
            self._readme_schreiben(d, name, rolle)
        uebersicht = self._projekt_uebersicht(name)
        if not uebersicht:
            uebersicht = root / f"{self.dateiname('projekt', titel_=safe_name(name, True))}.md"
            links = "\n".join(f"- [[{self.rel(root / o / f'readme_{o}')}|{o}]]"
                              for o in self.projekt_struktur().values())
            uebersicht.write_text(render_vorlage(self.sp.vorlage("projekt"), {
                "title": name, "kunde": fm_value(kunde), "methode": methode, "beschreibung": beschreibung,
                "date": dt.date.today().isoformat(), "struktur": links, "root": self.rel(root)}),
                encoding="utf-8")
        elif self.projekt_methode(name) != methode:
            uebersicht.write_text(set_frontmatter(uebersicht.read_text(encoding="utf-8"), {"methode": methode}),
                                  encoding="utf-8")
        if pm.ist_hermes(methode):
            self._hermes_meilensteine_anlegen(name, methode)
        self._index_neu(uebersicht)
        return root

    def projekt_methode_setzen(self, name: str, methode: str) -> Path:
        self._projekt_root(name)
        return self.projekt_anlegen(name, methode=methode)

    def projekte_ergaenzen(self) -> tuple[int, int]:
        n_proj = n_ord = 0
        for p in self.projekte():
            if p["vollstaendig"]:
                continue
            root = self.ordner("projekt_ordner") / p["name"]
            n_ord += sum(not (root / o).is_dir() for o in self.projekt_struktur().values())
            self.projekt_anlegen(p["name"])
            n_proj += 1
        return n_proj, n_ord

    def _projekt_ziel(self, projekt: str, rolle: str, unter: str | None = None) -> Path:
        ziel = self._projekt_root(projekt) / self.struktur(rolle)
        if unter:
            ziel = ziel / self.unter(unter)
        ziel.mkdir(parents=True, exist_ok=True)
        return ziel

    # --- Tasks -------------------------------------------------------------------------
    def task_anlegen(self, titel: str, start: str = "", ende: str = "", projekt: str = "",
                     prioritaet: str = "mittel", verantwortlich: str = "", beschreibung: str = "",
                     checkliste: str = "", ordner: Path | None = None, extra: dict | None = None,
                     unterordner: str = "") -> Path:
        self.ensure_basics()
        if not titel.strip():
            raise ValueError(self.t("Titel fehlt."))
        if prioritaet not in pm.STUFEN:
            prioritaet = "mittel"
        start_d = parse_date(start) or dt.date.today()
        ende_d = parse_date(ende) or start_d
        if ende_d < start_d:
            raise ValueError(self.t("Enddatum liegt vor dem Startdatum."))
        if ordner is not None:
            ziel = ordner
        elif projekt:
            ziel = self._projekt_root(projekt)
            unterordner = (unterordner or "").strip().strip("/\\")
            if unterordner:
                proj_root = ziel.resolve()
                ziel = (ziel / unterordner).resolve()
                if proj_root not in ziel.parents:
                    raise ValueError(self.t("Der gewählte Ordner liegt nicht im Projekt."))
                if not ziel.is_dir():
                    raise ValueError(self.t("Ordner '{o}' gibt es im Projekt nicht (mehr). Bitte Seite neu laden.",
                                            o=unterordner))
        else:
            ziel = self.ordner("task_ordner")
        ziel.mkdir(parents=True, exist_ok=True)
        datei = self._unique(ziel / f"{self.dateiname('task', titel_=safe_name(titel, True))}.md")
        checks = "\n".join(f"- [ ] {z.strip()}" for z in checkliste.splitlines() if z.strip()) or "- [ ] "
        return self._schreiben("task", datei, {
            "title": titel.strip(), "projekt": projekt, "start": iso(start_d), "ende": iso(ende_d),
            "prioritaet": prioritaet, "verantwortlich": verantwortlich, "beschreibung": beschreibung,
            "checkliste": checks},
            {"start": iso(start_d), "ende": iso(ende_d), "status": "offen", "projekt": projekt,
             "prioritaet": prioritaet, "verantwortlich": verantwortlich, **(extra or {})})

    def task_status_setzen(self, rel: str, status: str) -> None:
        if status not in pm.TASK_STATUS:
            raise ValueError(self.t("Ungültiger Status"))
        p = self.abs_in_vault(rel)
        werte = {"status": status, "erledigt_am": dt.date.today().isoformat() if status == "erledigt" else ""}
        p.write_text(set_frontmatter(p.read_text(encoding="utf-8"), werte), encoding="utf-8")
        with self.db() as con:
            self._index_file(con, p, dt.date.today())
            self._tagesuebersicht(con, dt.date.today())

    def task_verschieben(self, rel: str, tage: int) -> None:
        p = self.abs_in_vault(rel)
        text = p.read_text(encoding="utf-8")
        fm, _ = parse_frontmatter(text)
        heute = dt.date.today()
        start = parse_date(fm.get("start")) or heute
        ende = parse_date(fm.get("ende")) or start
        neu_start = max(start, heute) + dt.timedelta(days=tage)
        p.write_text(set_frontmatter(text, {"start": iso(neu_start),
                                            "ende": iso(neu_start + dt.timedelta(days=(ende - start).days))}),
                     encoding="utf-8")
        with self.db() as con:
            self._index_file(con, p, heute)
            self._tagesuebersicht(con, heute)

    def tasks(self, heute: dt.date | None = None, projekt: str = "") -> dict[str, list[dict]]:
        heute = heute or dt.date.today()
        sql, args = "SELECT * FROM tasks WHERE aktiv=1", []
        if projekt:
            sql += " AND projekt=?"
            args.append(projekt)
        gruppen = {k: [] for k in ("heute", "ueberfaellig", "geplant", "ohne_datum", "erledigt")}
        with self.db() as con:
            for r in con.execute(sql, args):
                t = dict(r)
                t["kategorie"] = task_kategorie(t, heute)
                t["link"] = self.obsidian_link(t["pfad"])
                e = parse_date(t["ende"])
                t["rest_tage"] = (e - heute).days if e else None
                gruppen[t["kategorie"]].append(t)

        def key(t):
            return (PRIO_ORDER.get((t["prioritaet"] or "").lower(), 1), t["ende"] or "9999", t["titel"].lower())
        for k in ("heute", "ueberfaellig", "ohne_datum"):
            gruppen[k].sort(key=key)
        gruppen["geplant"].sort(key=lambda t: (t["start"] or "9999", key(t)))
        gruppen["erledigt"].sort(key=lambda t: t["erledigt_am"] or "", reverse=True)
        return gruppen

    # --- Aus Vorlage -----------------------------------------------------------------------
    def vorlagen_liste(self) -> list[dict]:
        """Alle Vorlagen im Vorlagen-Ordner (auch eigene), mit vorgeschlagenem Zielordner.
        Eigene Vorlagen können im Frontmatter 'zielordner: 05_Meetings' setzen."""
        self.ensure_basics()
        vdir = self.ordner("vorlagen_ordner")
        bekannt = {self.vorlage_datei(k).lower(): k for k in pm.VORLAGEN}
        out = []
        for f in sorted(vdir.rglob("*.md"), key=lambda p: p.name.lower()):
            fm, _ = parse_frontmatter(f.read_text(encoding="utf-8", errors="replace"))
            key = bekannt.get(f.name.lower())
            typ = (fm.get("typ") or key or "").lower()
            meta = pm.VORLAGEN.get(key or typ)
            ziel = fm.get("zielordner") or ""
            if not ziel and meta and meta[1]:
                ziel = self.struktur(meta[1])
            name = self.t(meta[0]) if key else re.sub(r"^[^_]*_", "", f.stem).replace("_", " ")
            out.append({"datei": f.relative_to(vdir).as_posix(), "name": name, "typ": typ, "ziel": ziel,
                        "eigen": key is None, "link": self.obsidian_link(self.rel(f))})
        return out

    def aus_vorlage_anlegen(self, datei: str, titel: str, projekt: str = "", unterordner: str = "") -> Path:
        self.ensure_basics()
        titel = titel.strip()
        if not titel:
            raise ValueError(self.t("Titel fehlt."))
        vdir = self.ordner("vorlagen_ordner").resolve()
        vorlage = (vdir / datei).resolve()
        if vdir not in vorlage.parents or not vorlage.is_file():
            raise ValueError(self.t("Vorlage nicht gefunden. Bitte Seite neu laden."))
        heute = dt.date.today()
        if projekt:
            root = self._projekt_root(projekt).resolve()
            ziel = (root / unterordner.strip().strip("/\\")).resolve() if unterordner.strip() else root
            if ziel != root and root not in ziel.parents:
                raise ValueError(self.t("Der gewählte Ordner liegt nicht im Projekt."))
            if not ziel.is_dir():
                raise ValueError(self.t("Ordner '{o}' gibt es im Projekt nicht (mehr). Bitte Seite neu laden.",
                                        o=unterordner))
        else:
            ziel = self.ordner("notiz_ordner")
            ziel.mkdir(parents=True, exist_ok=True)
        text = vorlage.read_text(encoding="utf-8")
        fm, _ = parse_frontmatter(text)
        typ = (fm.get("typ") or "").lower()
        praefix = "Task_" if typ == "task" else ""
        datei_neu = self._unique(ziel / f"{praefix}{safe_name(titel, bool(praefix))}.md")
        text = render_vorlage(text, {"title": titel, "date": heute.isoformat(), "projekt": projekt,
                                     "start": heute.isoformat(), "ende": heute.isoformat(),
                                     "datum": heute.isoformat(), "prioritaet": "mittel"})
        werte = {"titel": titel}
        if projekt:
            werte["projekt"] = projekt
        if typ == "task":
            werte.update({"status": "offen", "start": heute.isoformat(), "ende": heute.isoformat()})
        text = re.sub(r"(?m)^zielordner:.*\n", "", set_frontmatter(text, werte), count=1)
        datei_neu.write_text(text, encoding="utf-8")
        self._index_neu(datei_neu)
        return datei_neu

    def letzte_notizen(self, limit: int = 15) -> list[dict]:
        with self.db() as con:
            rows = con.execute("SELECT pfad, titel, typ, projekt, geaendert FROM notizen "
                               "WHERE typ NOT IN ('readme','index','planer','vorlage') "
                               "ORDER BY geaendert DESC LIMIT ?", (limit,)).fetchall()
        return [dict(r, link=self.obsidian_link(r["pfad"])) for r in rows]

    # --- Einträge (Frontmatter aus dem Index) -------------------------------------------------
    def eintraege(self, typ: str) -> list[dict]:
        with self.db() as con:
            rows = con.execute("SELECT pfad, titel, projekt, kategorie, geaendert, meta FROM notizen "
                               "WHERE typ=? ORDER BY titel COLLATE NOCASE", (typ,)).fetchall()
        out = []
        for r in rows:
            d = json.loads(r["meta"] or "{}")
            d.update({k: r[k] for k in ("pfad", "titel", "projekt", "geaendert")})
            d["link"] = self.obsidian_link(r["pfad"])
            out.append(d)
        return out

    FELD_ERLAUBT = {"meilenstein": {"status", "plan", "ist", "entscheid_durch"},
                    "risiko": {"roam", "wahrscheinlichkeit", "auswirkung", "verantwortlich", "faellig"},
                    "entscheid": {"status"}, "pi": {"status"},
                    "pi_objective": {"status", "bv_geplant", "bv_ist", "committed"}}
    FELD_WERTE = {"roam": pm.ROAM, "wahrscheinlichkeit": pm.STUFEN, "auswirkung": pm.STUFEN,
                  "committed": {"ja": "", "nein": ""}}
    FELD_STATUS = {"meilenstein": pm.MS_STATUS, "entscheid": pm.ENTSCHEID_STATUS, "pi": pm.PI_STATUS,
                   "pi_objective": pm.OBJ_STATUS}
    DATUM_FELDER = {"plan", "ist", "faellig"}

    def feld_setzen(self, rel: str, feld: str, wert: str) -> None:
        p = self.abs_in_vault(rel)
        fm, _ = parse_frontmatter(p.read_text(encoding="utf-8"))
        typ = (fm.get("typ") or "").lower()
        if feld not in self.FELD_ERLAUBT.get(typ, set()):
            raise ValueError(self.t("Dieses Feld kann hier nicht geändert werden."))
        wert = (wert or "").strip()
        erlaubt = self.FELD_STATUS.get(typ) if feld == "status" else self.FELD_WERTE.get(feld)
        if erlaubt and wert not in erlaubt:
            raise ValueError(self.t("Ungültiger Wert für {feld}: {wert}", feld=feld, wert=wert))
        if feld in self.DATUM_FELDER and wert:
            d = parse_date(wert)
            if not d:
                raise ValueError(self.t("Ungültiges Datum: {wert}", wert=wert))
            wert = d.isoformat()
        if feld in ("bv_geplant", "bv_ist") and wert and (not wert.isdigit() or not 0 <= int(wert) <= 10):
            raise ValueError(self.t("Business Value bitte als Zahl von 0 bis 10 eingeben."))
        p.write_text(set_frontmatter(p.read_text(encoding="utf-8"), {feld: wert}), encoding="utf-8")
        self._index_neu(p)

    # --- Team und Stakeholder -----------------------------------------------------------
    def person_anlegen(self, d: dict) -> Path:
        self.ensure_basics()
        name = (d.get("titel") or "").strip()
        if not name:
            raise ValueError(self.t("Name fehlt."))
        datei = self.ordner("team_ordner") / f"{safe_name(name)}.md"
        if datei.exists():
            raise ValueError(self.t("Person existiert bereits: {pfad}", pfad=self.rel(datei)))
        return self._schreiben("person", datei, {"title": name, **{k: (d.get(k) or "").strip() for k in (
            "kuerzel", "rolle", "team", "organisation", "email", "telefon", "einfluss", "interesse", "vertretung")}})

    def team(self) -> list[dict]:
        personen = self.eintraege("person")
        g = self.tasks()
        offen = [t for k in ("ueberfaellig", "heute", "geplant", "ohne_datum") for t in g[k]]
        for p in personen:
            schluessel = {x.lower() for x in (p["titel"], p.get("kuerzel") or "") if x}
            p["tasks"] = [t for t in offen if schluessel & {
                x.strip() for x in re.split(r"[,;/&]", (t["verantwortlich"] or "").lower())}]
            p["ueberfaellig"] = sum(t["kategorie"] == "ueberfaellig" for t in p["tasks"])
        return personen

    # --- Jour Fixe ---------------------------------------------------------------------
    @staticmethod
    def _jf_naechster(datum: dt.date, turnus: str) -> dt.date | None:
        tage = JF_TURNUS.get(turnus)
        if tage is None:
            return None
        if tage:
            return datum + dt.timedelta(days=tage)
        m, j = datum.month % 12 + 1, datum.year + (datum.month == 12)
        for tag in (datum.day, 30, 29, 28):
            try:
                return dt.date(j, m, tag)
            except ValueError:
                continue
        return None

    def jf_pendenzen(self, serie: str = "", alle: bool = False) -> list[dict]:
        g = self.tasks()
        gruppen = ("ueberfaellig", "heute", "geplant", "ohne_datum") + (("erledigt",) if alle else ())
        out = [t for k in gruppen for t in g[k] if t.get("jourfixe")]
        if serie:
            out = [t for t in out if t["jourfixe"].lower() == serie.lower()]
        out.sort(key=lambda t: (t["status"] == "erledigt", t["ende"] or "9999", t["titel"].lower()))
        return out

    def jf_sitzungen(self, serie: str = "") -> list[dict]:
        s = [e for e in self.eintraege("jourfixe") if not serie or (e.get("serie") or "").lower() == serie.lower()]
        s.sort(key=lambda e: iso(parse_date(e.get("datum"))) or "", reverse=True)
        return s

    def jf_serien(self) -> list[dict]:
        heute = dt.date.today()
        namen: dict[str, str] = {}
        jdir = self.ordner("jourfixe_ordner")
        if jdir.is_dir():
            for d in jdir.iterdir():
                if d.is_dir() and not d.name.startswith("."):
                    namen.setdefault(d.name.lower(), d.name)
        sitzungen, pendenzen = self.jf_sitzungen(), self.jf_pendenzen()
        for x in [e.get("serie") for e in sitzungen] + [t["jourfixe"] for t in pendenzen]:
            if x:
                namen.setdefault(x.lower(), x)
        out = []
        for key, name in sorted(namen.items()):
            ss = [e for e in sitzungen if (e.get("serie") or "").lower() == key]
            pp = [t for t in pendenzen if t["jourfixe"].lower() == key]
            letzte = ss[0] if ss else None
            naechster = parse_date(letzte.get("naechster_termin")) if letzte else None
            out.append({"name": name, "sitzungen": len(ss), "letzte": letzte, "naechster": iso(naechster),
                        "naechster_in": (naechster - heute).days if naechster else None, "offen": len(pp),
                        "ueberfaellig": sum(t["kategorie"] == "ueberfaellig" for t in pp),
                        "projekt": (letzte or {}).get("projekt", ""),
                        "teilnehmer": (letzte or {}).get("teilnehmer", ""),
                        "moderation": (letzte or {}).get("moderation", "")})
        return out

    def jf_sitzung_anlegen(self, d: dict) -> Path:
        self.ensure_basics()
        serie = safe_name(d.get("serie") or "")
        if not serie:
            raise ValueError(self.t("Bitte eine Serie wählen oder einen neuen Namen eingeben."))
        datum = parse_date(d.get("datum")) or dt.date.today()
        naechster = parse_date(d.get("naechster_termin")) or self._jf_naechster(datum, d.get("turnus") or "")
        offen = self.jf_pendenzen(serie)
        if offen:
            zeilen = [f"| {self.t('Pendenz')} | {self.t('Verantwortlich')} | {self.t('Fällig')} | {self.t('Status')} |",
                      "|---|---|---|---|"]
            zeilen += [f"| [[{t['pfad'][:-3]}\\|{t['titel']}]] | {t['verantwortlich'] or ''} | {self.datum(t['ende'])} | "
                       f"{self.label(pm.TASK_STATUS, t['status'])} |" for t in offen]
            pendenzen = "\n".join(zeilen)
        else:
            pendenzen = self.t("Keine offenen Pendenzen.")
        agenda = "\n".join(f"{i}. {z.strip()}" for i, z in enumerate(
            (z for z in (d.get("agenda") or "").splitlines() if z.strip()), 1)) or "1. " + self.t("Pendenzen durchgehen")
        datei = self._unique(self.ordner("jourfixe_ordner") / serie /
                             f"{self.dateiname('jourfixe', datum=datum.isoformat(), serie=safe_name(serie, True))}.md")
        return self._schreiben("jourfixe", datei, {
            "title": f"{self.t('Jour Fixe')} {serie} {self.datum(datum.isoformat())}", "serie": serie,
            "datum": datum.isoformat(), "projekt": d.get("projekt"), "moderation": d.get("moderation"),
            "teilnehmer": d.get("teilnehmer"), "naechster_termin": iso(naechster) or "", "agenda": agenda,
            "pendenzen": pendenzen})

    def jf_pendenz_anlegen(self, d: dict) -> Path:
        serie = safe_name(d.get("serie") or "")
        if not serie:
            raise ValueError(self.t("Bitte eine Jour-Fixe-Serie wählen."))
        projekt = d.get("projekt") or ""
        if projekt and not (self.ordner("projekt_ordner") / safe_name(projekt)).is_dir():
            projekt = ""
        sitzung = self.jf_sitzungen(serie)
        extra = {"jourfixe": serie}
        beschreibung = d.get("beschreibung") or ""
        if sitzung:
            extra["jf_sitzung"] = f"[[{sitzung[0]['pfad'][:-3]}]]"
            beschreibung = (beschreibung + "\n\n" if beschreibung else "") + \
                f"{self.t('Aus dem Jour Fixe')}: [[{sitzung[0]['pfad'][:-3]}|{sitzung[0]['titel']}]]"
        heute = dt.date.today()
        ende = parse_date(d.get("ende"))
        if not ende:
            info = next((s for s in self.jf_serien() if s["name"].lower() == serie.lower()), None)
            ende = parse_date(info["naechster"]) if info and info["naechster"] else heute
        start = parse_date(d.get("start")) or min(heute, ende)
        return self.task_anlegen(d.get("titel", ""), iso(start), iso(ende), projekt, d.get("prioritaet") or "mittel",
                                 d.get("verantwortlich", ""), beschreibung, d.get("checkliste", ""),
                                 ordner=self.ordner("jourfixe_ordner") / serie / self.unter("pendenzen"), extra=extra)

    # --- HERMES ------------------------------------------------------------------------
    def _ms_name(self, ms_id: str) -> str:
        return self.t(pm.MS_NAME[ms_id])

    def _hermes_meilensteine_anlegen(self, projekt: str, methode: str) -> int:
        mdir = self._projekt_ziel(projekt, "steuerung", "meilensteine")
        if any(mdir.glob("*.md")):
            return 0
        for i, (ms_id, phase, pruef) in enumerate(pm.MEILENSTEINE[methode], 1):
            titel = self._ms_name(ms_id)
            datei = mdir / f"{self.dateiname('meilenstein', nr=f'{i:02d}_', titel_=safe_name(titel, True))}.md"
            entscheid_durch = self.t(pm.MS_ENTSCHEID.get(ms_id, pm.MS_ENTSCHEID_STANDARD))
            self._schreiben("meilenstein", datei, {
                "title": titel, "ms_id": ms_id, "projekt": projekt, "methode": methode, "phase": phase,
                "phase_name": self.label(pm.PHASEN_NAME, phase), "reihenfolge": i * 10, "kern": "ja", "plan": "",
                "entscheid_durch": entscheid_durch, "pruefpunkte": "\n".join(f"- [ ] {self.t(x)}" for x in pruef)},
                {"ms_id": ms_id, "projekt": projekt, "phase": phase, "reihenfolge": i * 10, "kern": "ja"})
        return len(pm.MEILENSTEINE[methode])

    def meilenstein_anlegen(self, d: dict) -> Path:
        projekt = d.get("projekt") or ""
        titel = (d.get("titel") or "").strip()
        if not titel:
            raise ValueError(self.t("Bitte einen Namen für den Meilenstein eingeben."))
        methode = self.projekt_methode(projekt)
        if not pm.ist_hermes(methode):
            raise ValueError(self.t("Meilensteine gibt es nur in Projekten mit HERMES-Methode."))
        phase = d.get("phase") or pm.PHASEN[methode][0]
        if phase not in pm.PHASEN[methode]:
            raise ValueError(self.t("Unbekannte Phase: {p}", p=phase))
        plan = iso(parse_date(d.get("plan"))) or ""
        mdir = self._projekt_ziel(projekt, "steuerung", "meilensteine")
        datei = self._unique(mdir / f"{self.dateiname('meilenstein', nr='', titel_=safe_name(titel, True))}.md")
        return self._schreiben("meilenstein", datei, {
            "title": titel, "ms_id": "", "projekt": projekt, "methode": methode, "phase": phase,
            "phase_name": self.label(pm.PHASEN_NAME, phase), "reihenfolge": 0, "kern": "nein", "plan": plan,
            "entscheid_durch": d.get("entscheid_durch") or "", "pruefpunkte": "- [ ] "},
            {"projekt": projekt, "phase": phase, "kern": "nein", "plan": plan})

    def meilensteine(self, projekt: str = "", heute: dt.date | None = None) -> list[dict]:
        heute = heute or dt.date.today()
        out = []
        for m in self.eintraege("meilenstein"):
            if projekt and m.get("projekt") != projekt:
                continue
            m["status"] = (m.get("status") or "geplant").lower()
            m["erledigt"] = m["status"] in pm.MS_ERLEDIGT
            m["kern"] = (m.get("kern") or "").lower() in ("ja", "true", "yes")
            plan = parse_date(m.get("plan"))
            m["plan"], m["ist"] = iso(plan), iso(parse_date(m.get("ist")))
            m["rest_tage"] = (plan - heute).days if plan else None
            m["ueberfaellig"] = bool(plan and plan < heute and not m["erledigt"])
            m["phase_name"] = self.label(pm.PHASEN_NAME, m.get("phase") or "")
            try:
                m["reihenfolge"] = int(m.get("reihenfolge") or 0)
            except ValueError:
                m["reihenfolge"] = 0
            out.append(m)
        methoden: dict[str, str] = {}

        def key(m):
            p = m.get("projekt") or ""
            if p not in methoden:
                methoden[p] = self.projekt_methode(p) if p else ""
            phasen = pm.PHASEN.get(methoden[p], [])
            idx = phasen.index(m.get("phase")) if m.get("phase") in phasen else len(phasen)
            gruppe = 0 if m.get("ms_id") == "projektinitialisierung" else (2 if m["kern"] else 1)
            return (p.lower(), idx, gruppe, m["plan"] or "9999", m["reihenfolge"], m["titel"].lower())
        out.sort(key=key)
        return out

    def hermes_status(self, projekt: str, heute: dt.date | None = None) -> dict:
        methode = self.projekt_methode(projekt)
        phasen = pm.PHASEN.get(methode, [])
        ms = self.meilensteine(projekt, heute)
        kern = [m for m in ms if m["kern"]]
        offen = [m for m in kern if not m["erledigt"]]
        aktuell = (offen[0].get("phase") or "") if offen else ("abgeschlossen" if kern else "")
        idx = phasen.index(aktuell) if aktuell in phasen else (len(phasen) if aktuell == "abgeschlossen" else -1)
        return {"methode": methode, "methode_label": self.label(pm.METHODEN, methode),
                "phasen": [{"id": p, "name": self.label(pm.PHASEN_NAME, p),
                            "zustand": "erledigt" if i < idx else ("aktuell" if i == idx else "offen"),
                            "meilensteine": [m for m in ms if m.get("phase") == p]} for i, p in enumerate(phasen)],
                "aktuelle_phase": aktuell,
                "aktuelle_phase_name": self.t("abgeschlossen") if aktuell == "abgeschlossen"
                else self.label(pm.PHASEN_NAME, aktuell),
                "meilensteine": ms, "naechster": next((m for m in ms if not m["erledigt"]), None),
                "ueberfaellig": sum(m["ueberfaellig"] for m in ms),
                "fortschritt": (sum(m["erledigt"] for m in kern), len(kern))}

    def meilenstein_freigeben(self, rel: str, datum: str = "", entscheid_durch: str = "",
                              bemerkung: str = "", entscheid_notiz: bool = True) -> Path | None:
        p = self.abs_in_vault(rel)
        fm, _ = parse_frontmatter(p.read_text(encoding="utf-8"))
        if (fm.get("typ") or "").lower() != "meilenstein":
            raise ValueError(self.t("Das ist kein Meilenstein."))
        d = parse_date(datum) or dt.date.today()
        werte = {"status": "freigegeben", "ist": d.isoformat()}
        if entscheid_durch:
            werte["entscheid_durch"] = entscheid_durch
        entscheid = None
        if entscheid_notiz:
            titel = fm.get("titel") or p.stem
            entscheid = self.entscheid_anlegen({
                "titel": self.t("{titel} erteilt", titel=titel), "projekt": fm.get("projekt", ""),
                "datum": d.isoformat(), "status": "entschieden",
                "gremium": self.t("Auftraggeber/in") if fm.get("ms_id") in pm.MS_FREIGABE_AUFTRAGGEBER
                else self.t("Projektausschuss"),
                "entscheid_durch": entscheid_durch or fm.get("entscheid_durch", ""),
                "meilenstein": f"[[{rel[:-3]}|{titel}]]",
                "antrag": self.t("Freigabe des Meilensteins {link} (Phase {phase}).", link=f"[[{rel[:-3]}|{titel}]]",
                                 phase=self.label(pm.PHASEN_NAME, fm.get("phase", ""))),
                "entscheid": bemerkung or self.t("{titel} erteilt", titel=titel) + "."})
            werte["entscheid"] = f"[[{self.rel(entscheid)[:-3]}]]"
        p.write_text(set_frontmatter(p.read_text(encoding="utf-8"), werte), encoding="utf-8")
        self._index_neu(p)
        return entscheid

    # --- Risiken -------------------------------------------------------------------------
    def _pm_ziel(self, projekt: str, unter: str, pi: str = "") -> Path:
        if projekt:
            return self._projekt_ziel(projekt, "risiken", unter)
        if pi and self.pi_finden(pi):
            ziel = self.pi_ordner(pi) / self.unter(unter)
        else:
            ziel = self.ordner("notiz_ordner") / self.unter(unter)
        ziel.mkdir(parents=True, exist_ok=True)
        return ziel

    @staticmethod
    def risiko_bewertung(r: dict) -> dict:
        w = pm.STUFE_WERT.get((r.get("wahrscheinlichkeit") or "").lower(), 2)
        a = pm.STUFE_WERT.get((r.get("auswirkung") or "").lower(), 2)
        score = w * a
        return {"score": score, "farbe": "rot" if score >= 6 else "orange" if score >= 3
                else "gelb" if score == 2 else "gruen"}

    def risiko_anlegen(self, d: dict) -> Path:
        self.ensure_basics()
        titel = (d.get("titel") or "").strip()
        if not titel:
            raise ValueError(self.t("Bitte das Risiko kurz benennen."))
        projekt, pi = d.get("projekt") or "", (d.get("pi") or "").strip()
        if not projekt and pi:
            projekt = (self.pi_finden(pi) or {}).get("projekt") or ""
        roam = d.get("roam") or "offen"
        if roam not in pm.ROAM:
            raise ValueError(self.t("Ungültiger ROAM-Status: {s}", s=roam))
        w = d.get("wahrscheinlichkeit") if d.get("wahrscheinlichkeit") in pm.STUFEN else "mittel"
        a = d.get("auswirkung") if d.get("auswirkung") in pm.STUFEN else "mittel"
        faellig = iso(parse_date(d.get("faellig"))) or ""
        datei = self._unique(self._pm_ziel(projekt, "risiken", pi) /
                             f"{self.dateiname('risiko', titel_=safe_name(titel, True))}.md")
        return self._schreiben("risiko", datei, {
            "title": titel, "projekt": projekt, "pi": pi, "roam": roam, "wahrscheinlichkeit": w, "auswirkung": a,
            "verantwortlich": d.get("verantwortlich") or "", "faellig": faellig,
            "beschreibung": d.get("beschreibung") or "", "massnahme": d.get("massnahme") or ""},
            {"roam": roam, "wahrscheinlichkeit": w, "auswirkung": a})

    def risiken(self, projekt: str = "", pi: str = "", heute: dt.date | None = None) -> list[dict]:
        heute = heute or dt.date.today()
        out = []
        for r in self.eintraege("risiko"):
            if (projekt and r.get("projekt") != projekt) or (pi and (r.get("pi") or "") != pi):
                continue
            r["roam"] = (r.get("roam") or "offen").lower()
            if r["roam"] not in pm.ROAM:
                r["roam"] = "offen"
            r.update(self.risiko_bewertung(r))
            f = parse_date(r.get("faellig"))
            r["faellig"] = iso(f)
            r["ueberfaellig"] = bool(f and f < heute and r["roam"] != "resolved")
            out.append(r)
        out.sort(key=lambda r: (-r["score"], r["faellig"] or "9999", r["titel"].lower()))
        return out

    @staticmethod
    def risiko_matrix(risiken: list[dict]) -> list[list[int]]:
        m = [[0] * 3 for _ in range(3)]
        for r in risiken:
            if r["roam"] == "resolved":
                continue
            w = pm.STUFE_WERT.get((r.get("wahrscheinlichkeit") or "").lower(), 2)
            a = pm.STUFE_WERT.get((r.get("auswirkung") or "").lower(), 2)
            m[3 - a][w - 1] += 1
        return m

    def risiko_zu_task(self, rel: str, start: str = "", ende: str = "", verantwortlich: str = "") -> Path:
        p = self.abs_in_vault(rel)
        fm, _ = parse_frontmatter(p.read_text(encoding="utf-8"))
        if (fm.get("typ") or "").lower() != "risiko":
            raise ValueError(self.t("Das ist kein Risiko."))
        titel = fm.get("titel") or p.stem
        projekt = fm.get("projekt") or ""
        if projekt and not (self.ordner("projekt_ordner") / safe_name(projekt)).is_dir():
            projekt = ""
        verantwortlich = verantwortlich or fm.get("verantwortlich", "")
        start_d = parse_date(start) or dt.date.today()
        ende_d = max(parse_date(ende) or parse_date(fm.get("faellig")) or start_d, start_d)
        task = self.task_anlegen(self.t("Massnahme {titel}", titel=titel), iso(start_d), iso(ende_d), projekt,
                                 "hoch", verantwortlich, self.t("Massnahme zum Risiko {link}",
                                                                link=f"[[{rel[:-3]}|{titel}]]"))
        werte = {"task": f"[[{self.rel(task)[:-3]}]]"}
        if (fm.get("roam") or "offen").lower() == "offen":
            werte["roam"] = "owned"
        if verantwortlich and not fm.get("verantwortlich"):
            werte["verantwortlich"] = verantwortlich
        p.write_text(set_frontmatter(p.read_text(encoding="utf-8"), werte), encoding="utf-8")
        self._index_neu(p)
        return task

    # --- Markierungen ---------------------------------------------------------------------
    def marker(self, tag: str = "", projekt: str = "", limit: int = 500) -> list[dict]:
        sql, args = "SELECT * FROM marker WHERE 1=1", []
        if tag:
            sql += " AND tag=?"
            args.append(tag)
        if projekt:
            sql += " AND projekt=?"
            args.append(projekt)
        sql += " ORDER BY datum DESC, pfad, zeile LIMIT ?"
        args.append(limit)
        with self.db() as con:
            rows = [dict(r) for r in con.execute(sql, args)]
        for r in rows:
            r["anzeige"] = wikilinks_lesbar(r["text"])
            r["link"] = self.obsidian_link(r["pfad"])
        return rows

    # --- Entscheide ------------------------------------------------------------------------
    def entscheid_anlegen(self, d: dict) -> Path:
        self.ensure_basics()
        titel = (d.get("titel") or "").strip()
        if not titel:
            raise ValueError(self.t("Bitte den Entscheid kurz benennen."))
        projekt, pi = d.get("projekt") or "", (d.get("pi") or "").strip()
        if not projekt and pi:
            projekt = (self.pi_finden(pi) or {}).get("projekt") or ""
        status = d.get("status") or "entschieden"
        if status not in pm.ENTSCHEID_STATUS:
            raise ValueError(self.t("Ungültiger Status"))
        datum = parse_date(d.get("datum")) or dt.date.today()
        name = self.dateiname("entscheid", date=datum.isoformat(), titel_=safe_name(titel, True))
        datei = self._unique(self._pm_ziel(projekt, "entscheide", pi) / f"{name}.md")
        return self._schreiben("entscheid", datei, {
            "title": titel, "projekt": projekt, "pi": pi, "datum": datum.isoformat(), "status": status,
            "gremium": d.get("gremium") or "", "entscheid_durch": d.get("entscheid_durch") or "",
            "meilenstein": d.get("meilenstein") or "", "antrag": d.get("antrag") or "",
            "entscheid": d.get("entscheid") or ""},
            {"datum": datum.isoformat(), "status": status, "meilenstein": d.get("meilenstein") or ""})

    def entscheide(self, projekt: str = "", quelle: str = "") -> list[dict]:
        """Entscheid-Log: Entscheid-Notizen, technische Entscheidungen (ADR) und Zeilen mit #entscheid."""
        out = []
        if quelle in ("", "entscheid"):
            for e in self.eintraege("entscheid"):
                out.append({"quelle": "entscheid", "titel": e["titel"], "projekt": e.get("projekt") or "",
                            "datum": iso(parse_date(e.get("datum"))) or e["geaendert"][:10],
                            "gremium": e.get("gremium") or "", "wer": e.get("entscheid_durch") or "",
                            "status": e.get("status") or "", "pfad": e["pfad"], "link": e["link"],
                            "pi": e.get("pi") or ""})
        if quelle in ("", "adr"):
            for e in self.eintraege("entscheidung"):
                out.append({"quelle": "adr", "titel": e["titel"], "projekt": e.get("projekt") or "",
                            "datum": iso(parse_date(e.get("datum"))) or e["geaendert"][:10],
                            "gremium": "ADR", "wer": "", "status": e.get("status") or "",
                            "pfad": e["pfad"], "link": e["link"], "pi": ""})
        if quelle in ("", "notiz"):
            for m in self.marker("entscheid"):
                out.append({"quelle": "notiz", "titel": m["anzeige"], "projekt": m["projekt"] or "",
                            "datum": m["datum"] or "", "gremium": "", "wer": "", "status": "",
                            "pfad": m["pfad"], "link": m["link"], "notiz": m["titel"], "pi": ""})
        if projekt:
            out = [e for e in out if e["projekt"] == projekt]
        out.sort(key=lambda e: (e["datum"] or "", e["titel"].lower()), reverse=True)
        return out

    # --- SAFe ----------------------------------------------------------------------------
    @staticmethod
    def pi_iterationen(start: dt.date, anzahl: int, wochen: int) -> list[dict]:
        out = []
        for i in range(anzahl):
            s = start + dt.timedelta(weeks=wochen * i)
            out.append({"name": "IP" if i == anzahl - 1 and anzahl > 1 else f"I{i + 1}",
                        "start": s.isoformat(), "ende": (s + dt.timedelta(weeks=wochen, days=-1)).isoformat()})
        return out

    def pis(self, projekt: str = "", heute: dt.date | None = None) -> list[dict]:
        heute = heute or dt.date.today()
        out = []
        for p in self.eintraege("pi"):
            if projekt and p.get("projekt") != projekt:
                continue
            s, e = parse_date(p.get("start")), parse_date(p.get("ende"))
            p["start"], p["ende"] = iso(s), iso(e)
            p["laufend"] = bool(s and e and s <= heute <= e)
            p["status"] = (p.get("status") or "planung").lower()
            try:
                n, w = int(p.get("iterationen") or 5), int(p.get("iteration_wochen") or 2)
            except ValueError:
                n, w = 5, 2
            p["iterationen_liste"] = self.pi_iterationen(s, n, w) if s else []
            p["iteration_aktuell"] = next((i["name"] for i in p["iterationen_liste"]
                                           if i["start"] <= heute.isoformat() <= i["ende"]), "")
            out.append(p)
        out.sort(key=lambda p: p["start"] or "", reverse=True)
        return out

    def pi_finden(self, name: str) -> dict | None:
        return next((p for p in self.pis() if p["titel"].lower() == (name or "").strip().lower()), None)

    def pi_ordner(self, name: str) -> Path:
        p = self.pi_finden(name)
        if not p:
            raise ValueError(self.t("PI '{name}' nicht gefunden.", name=name))
        return self.abs_in_vault(p["pfad"]).parent

    def _board_datei(self, ordner: Path, pi: str) -> Path:
        return ordner / f"{self.dateiname('board', titel_=safe_name(pi, True))}.canvas"

    def pi_anlegen(self, d: dict) -> Path:
        self.ensure_basics()
        name = safe_name(d.get("titel") or "")
        if not name:
            raise ValueError(self.t("Bitte einen Namen für das PI eingeben, z.B. 2027-PI1."))
        if self.pi_finden(name):
            raise ValueError(self.t("PI '{name}' gibt es bereits.", name=name))
        start = parse_date(d.get("start"))
        if not start:
            raise ValueError(self.t("Bitte das Startdatum des PI angeben."))
        try:
            n, w = int(d.get("iterationen") or 5), int(d.get("iteration_wochen") or 2)
        except ValueError:
            raise ValueError(self.t("Iterationen und Wochen bitte als Zahl angeben."))
        if not (1 <= n <= 12 and 1 <= w <= 6):
            raise ValueError(self.t("Iterationen 1 bis 12, Länge 1 bis 6 Wochen."))
        ende = parse_date(d.get("ende")) or start + dt.timedelta(weeks=n * w, days=-1)
        if ende < start:
            raise ValueError(self.t("Das Ende liegt vor dem Start."))
        projekt = d.get("projekt") or ""
        ordner = (self._projekt_ziel(projekt, "steuerung", "pi") if projekt else self.ordner("safe_ordner")) / name
        ordner.mkdir(parents=True, exist_ok=True)
        art = (d.get("art") or "").strip()
        iters = self.pi_iterationen(start, n, w)
        tabelle = "\n".join([f"| {self.t('Iteration')} | {self.t('Start')} | {self.t('Ende')} |", "|---|---|---|"] +
                            [f"| {i['name']} | {self.datum(i['start'])} | {self.datum(i['ende'])} |" for i in iters])
        board = self._board_datei(ordner, name)
        status = d.get("status") if d.get("status") in pm.PI_STATUS else "planung"
        datei = self._unique(ordner / f"{self.dateiname('pi', titel_=safe_name(name, True))}.md")
        self._schreiben("pi", datei, {
            "title": name, "projekt": projekt, "art": art, "art_titel": f" · ART {art}" if art else "",
            "start": start.isoformat(), "ende": ende.isoformat(), "iterationen": n, "iteration_wochen": w,
            "status": status, "iterationen_tabelle": tabelle, "ordner": self.rel(ordner),
            "board": self.rel(board)},
            {"start": start.isoformat(), "ende": ende.isoformat(), "iterationen": n, "iteration_wochen": w,
             "status": status})
        teams = [x.strip() for x in re.split(r"[,;\n]", d.get("teams") or "") if x.strip()]
        self._pi_board_schreiben(board, name, iters, teams)
        return datei

    def _pi_board_schreiben(self, datei: Path, pi: str, iters: list[dict], teams: list[str]) -> bool:
        """ART Planning Board als Obsidian-Canvas: Spalten = Iterationen, Zeilen = Teams."""
        if datei.exists():
            return False
        teams = teams or ["Team A", "Team B", "Team C"]
        zeilen = [self.t("Meilensteine / Events")] + teams
        bw, bh, kopf, lw = 260, 170, 60, 220
        nodes = [{"id": "titel", "type": "text", "x": 0, "y": -kopf - 90, "width": lw + bw * len(iters),
                  "height": 70, "text": f"# ART Planning Board {pi}\n" + self.t(
                      "Features als Karten in die Felder ziehen, Abhängigkeiten mit Pfeilen verbinden.")}]
        for i, it in enumerate(iters):
            nodes.append({"id": f"it{i}", "type": "group", "x": lw + bw * i, "y": -kopf, "width": bw,
                          "height": kopf + bh * len(zeilen),
                          "label": f"{it['name']} ({self.datum(it['start'])} – {self.datum(it['ende'])})"})
        for j, z in enumerate(zeilen):
            nodes.append({"id": f"lane{j}", "type": "text", "x": 0, "y": bh * j + 10, "width": lw - 20,
                          "height": bh - 20, "text": f"## {z}", **({"color": "4"} if j == 0 else {})})
        nodes.append({"id": "beispiel", "type": "text", "x": lw + 20, "y": bh + 20, "width": bw - 40, "height": 110,
                      "text": f"**{self.t('Feature')}**\n" + self.t("Karte verschieben oder löschen"), "color": "5"})
        datei.write_text(json.dumps({"nodes": nodes, "edges": []}, ensure_ascii=False, indent=1), encoding="utf-8")
        return True

    def pi_board_anlegen(self, name: str) -> Path:
        pi = self.pi_finden(name)
        if not pi:
            raise ValueError(self.t("PI '{name}' nicht gefunden.", name=name))
        datei = self._board_datei(self.pi_ordner(name), pi["titel"])
        teams = sorted({o.get("team") for o in self.objectives(pi["titel"]) if o.get("team")})
        if not self._pi_board_schreiben(datei, pi["titel"], pi["iterationen_liste"], teams):
            raise ValueError(self.t("Das Board existiert bereits: {pfad}", pfad=self.rel(datei)))
        return datei

    def objective_anlegen(self, d: dict) -> Path:
        pi = self.pi_finden(d.get("pi") or "")
        if not pi:
            raise ValueError(self.t("Bitte ein bestehendes PI wählen."))
        titel, team = (d.get("titel") or "").strip(), (d.get("team") or "").strip()
        if not titel or not team:
            raise ValueError(self.t("Titel und Team sind Pflicht."))
        bv = str(d.get("bv_geplant") or "").strip()
        if bv and (not bv.isdigit() or not 1 <= int(bv) <= 10):
            raise ValueError(self.t("Business Value bitte von 1 bis 10."))
        committed = "nein" if d.get("committed") == "nein" else "ja"
        ordner = self.pi_ordner(pi["titel"]) / self.unter("objectives")
        datei = self._unique(ordner / f"{self.dateiname('pi_objective', team_=safe_name(team, True), titel_=safe_name(titel, True))}.md")
        return self._schreiben("pi_objective", datei, {
            "title": titel, "projekt": pi.get("projekt") or "", "pi": pi["titel"], "team": team,
            "committed": committed, "bv_geplant": bv, "beschreibung": d.get("beschreibung") or ""},
            {"pi": pi["titel"], "team": team, "committed": committed, "bv_geplant": bv})

    def objectives(self, pi: str) -> list[dict]:
        out = []
        for o in self.eintraege("pi_objective"):
            if (o.get("pi") or "").lower() != pi.lower():
                continue
            o["committed"] = "nein" if (o.get("committed") or "").lower() in ("nein", "no", "false") else "ja"
            for k in ("bv_geplant", "bv_ist"):
                v = str(o.get(k) or "").strip()
                o[k] = int(v) if v.isdigit() else None
            o["status"] = o.get("status") or "geplant"
            out.append(o)
        out.sort(key=lambda o: ((o.get("team") or "").lower(), o["committed"] != "ja", o["titel"].lower()))
        return out

    @staticmethod
    def predictability(objs: list[dict]) -> dict:
        """Erreichter BV aller Objectives geteilt durch geplanten BV der committed Objectives."""
        geplant = sum(o["bv_geplant"] or 0 for o in objs if o["committed"] == "ja")
        ist = sum(o["bv_ist"] or 0 for o in objs if o["bv_ist"] is not None)
        bewertet = sum(o["bv_ist"] is not None for o in objs)
        return {"geplant": geplant, "ist": ist, "bewertet": bewertet, "anzahl": len(objs),
                "prozent": round(100 * ist / geplant) if geplant and bewertet else None}

    def pi_details(self, name: str) -> dict | None:
        pi = self.pi_finden(name)
        if not pi:
            return None
        objs = self.objectives(pi["titel"])
        teams: dict[str, list] = {}
        for o in objs:
            teams.setdefault(o.get("team") or "–", []).append(o)
        board = self._board_datei(self.pi_ordner(pi["titel"]), pi["titel"])
        ia = next((e for e in self.eintraege("inspect_adapt") if (e.get("pi") or "") == pi["titel"]), None)
        return {"pi": pi, "teams": [{"name": t, "objectives": lst, "pred": self.predictability(lst)}
                                    for t, lst in teams.items()],
                "art": self.predictability(objs), "risiken": self.risiken(pi=pi["titel"]),
                "board": {"vorhanden": board.exists(), "link": self.obsidian_link(self.rel(board))},
                "ia": ia, "retros": [e for e in self.eintraege("retro") if (e.get("pi") or "") == pi["titel"]]}

    def _predictability_tabelle(self, name: str) -> str:
        det = self.pi_details(name)
        z = [f"| {self.t('Team')} | {self.t('BV geplant (committed)')} | {self.t('BV erreicht')} | Predictability |",
             "|---|---|---|---|"]

        def pr_txt(pr):
            return f"{pr['prozent']} %" if pr["prozent"] is not None else self.t("noch nicht bewertet")
        z += [f"| {t['name']} | {t['pred']['geplant']} | {t['pred']['ist']} | {pr_txt(t['pred'])} |" for t in det["teams"]]
        a = det["art"]
        z.append(f"| **{self.t('ART gesamt')}** | **{a['geplant']}** | **{a['ist']}** | **{pr_txt(a)}** |")
        return "\n".join(z)

    def ia_anlegen(self, name: str) -> Path:
        pi = self.pi_finden(name)
        if not pi:
            raise ValueError(self.t("PI '{name}' nicht gefunden.", name=name))
        datei = self.pi_ordner(pi["titel"]) / f"{self.dateiname('inspect_adapt', titel_=safe_name(pi['titel'], True))}.md"
        if datei.exists():
            raise ValueError(self.t("Inspect & Adapt gibt es schon: {pfad}", pfad=self.rel(datei)))
        return self._schreiben("inspect_adapt", datei, {
            "title": f"Inspect & Adapt {pi['titel']}", "projekt": pi.get("projekt") or "", "pi": pi["titel"],
            "predictability": self._predictability_tabelle(pi["titel"])}, {"pi": pi["titel"]})

    # --- PM-Dokumente --------------------------------------------------------------------
    def _md_meilensteine(self, projekt: str) -> str:
        ms = self.meilensteine(projekt)
        if not ms:
            return "_" + self.t("Keine Meilensteine erfasst.") + "_"
        z = [f"| {self.t('Meilenstein')} | {self.t('Phase')} | {self.t('Plan')} | {self.t('Ist')} | {self.t('Status')} |",
             "|---|---|---|---|---|"]
        z += [f"| [[{m['pfad'][:-3]}\\|{m['titel']}]] | {m['phase_name']} | {self.datum(m['plan'])} | "
              f"{self.datum(m['ist'])} | {self.label(pm.MS_STATUS, m['status'])}"
              f"{' (' + self.t('überfällig') + ')' if m['ueberfaellig'] else ''} |" for m in ms]
        return "\n".join(z)

    def _md_risiken(self, projekt: str = "", pi: str = "") -> str:
        rr = [r for r in self.risiken(projekt, pi) if r["roam"] != "resolved"]
        if not rr:
            return "_" + self.t("Keine offenen Risiken erfasst.") + "_"
        z = [f"| {self.t('Risiko')} | {self.t('Wahrscheinlichkeit')} | {self.t('Auswirkung')} | ROAM | "
             f"{self.t('Verantwortlich')} |", "|---|---|---|---|---|"]
        z += [f"| [[{r['pfad'][:-3]}\\|{r['titel']}]] | {self.label(pm.STUFEN, r.get('wahrscheinlichkeit', ''))} | "
              f"{self.label(pm.STUFEN, r.get('auswirkung', ''))} | {self.label(pm.ROAM, r['roam'])} | "
              f"{r.get('verantwortlich', '')} |" for r in rr]
        return "\n".join(z)

    def _md_entscheide(self, projekt: str, tage: int = 30) -> str:
        grenze = (dt.date.today() - dt.timedelta(days=tage)).isoformat()
        ee = [e for e in self.entscheide(projekt) if (e["datum"] or "") >= grenze]
        if not ee:
            return "_" + self.t("Keine Entscheide in den letzten {n} Tagen.", n=tage) + "_"
        return "\n".join(f"- {self.datum(e['datum'])}: [[{e['pfad'][:-3]}|{e['titel'][:120]}]]"
                         + (f" ({e['gremium']})" if e["gremium"] else "") for e in ee)

    def pm_dokument_anlegen(self, typ: str, titel: str, projekt: str = "", extra: dict | None = None) -> Path:
        self.ensure_basics()
        if typ not in pm.HERMES_DOKU and typ not in pm.SAFE_DOKU:
            raise ValueError(self.t("Unbekannter Dokumenttyp"))
        titel = (titel or "").strip()
        if not titel:
            raise ValueError(self.t("Titel fehlt."))
        extra = {k: (v or "").strip() for k, v in (extra or {}).items()}
        heute = dt.date.today()
        pi = extra.get("pi", "")
        _, rolle, _ = pm.VORLAGEN[typ]
        if typ in pm.SAFE_DOKU and pi and self.pi_finden(pi):
            ziel = self.pi_ordner(pi) / self.unter("retros" if typ == "retro" else "art_sync")
            projekt = projekt or (self.pi_finden(pi).get("projekt") or "")
        elif projekt:
            ziel = self._projekt_ziel(projekt, rolle)
        else:
            ziel = self.ordner("notiz_ordner")
        datei = self._unique(ziel / f"{self.dateiname(typ, date=heute.isoformat(), titel_=safe_name(titel, True))}.md")
        werte = {"title": titel, "projekt": projekt, **extra}
        if projekt and typ in pm.HERMES_DOKU:
            werte["auto_phase"] = self.hermes_status(projekt)["aktuelle_phase_name"] or "–"
            werte["auto_meilensteine"] = self._md_meilensteine(projekt)
            werte["auto_entscheide"] = self._md_entscheide(projekt)
        if projekt or pi:
            werte["auto_risiken"] = self._md_risiken(projekt, "" if projekt else pi)
        return self._schreiben(typ, datei, werte)

    # --- Cockpit ---------------------------------------------------------------------------
    def meilensteine_faellig(self, heute: dt.date | None = None) -> list[dict]:
        n = int(self.cfg.get("meilenstein_tage", 14))
        return [m for m in self.meilensteine(heute=heute) if not m["erledigt"] and m["plan"]
                and (m["ueberfaellig"] or m["rest_tage"] <= n)]

    def pm_cockpit(self, heute: dt.date | None = None) -> dict:
        heute = heute or dt.date.today()
        projekte = [p for p in self.projekte() if p["methode"]]
        risiken, entscheide = self.risiken(heute=heute), self.entscheide()
        blocker, pis = self.marker("blocker"), self.pis(heute=heute)
        grenze30 = (heute - dt.timedelta(days=30)).isoformat()
        for p in projekte:
            p["hermes"] = self.hermes_status(p["name"], heute) if pm.ist_hermes(p["methode"]) else None
            p["pi"] = p["pred"] = None
            if pm.ist_safe(p["methode"]):
                pp = [x for x in pis if x.get("projekt") == p["name"]]
                p["pi"] = next((x for x in pp if x["laufend"]), pp[0] if pp else None)
                p["pred"] = self.predictability(self.objectives(p["pi"]["titel"])) if p["pi"] else None
            rr = [r for r in risiken if r.get("projekt") == p["name"] and r["roam"] != "resolved"]
            p["risiken_offen"], p["risiken_rot"] = len(rr), sum(r["farbe"] == "rot" for r in rr)
            p["entscheide_30"] = sum(e["projekt"] == p["name"] and (e["datum"] or "") >= grenze30 for e in entscheide)
            p["blocker"] = sum(b["projekt"] == p["name"] for b in blocker)
            p["ampel"] = ("rot" if (p["hermes"] and p["hermes"]["ueberfaellig"]) or p["risiken_rot"]
                          else "orange" if p["risiken_offen"] or p["blocker"] else "gruen")
        return {"projekte": projekte, "meilensteine": self.meilensteine_faellig(heute),
                "risiken": [r for r in risiken if r["roam"] != "resolved"][:15], "entscheide": entscheide[:12],
                "blocker": blocker[:20], "pis": [x for x in pis if x["laufend"]]}

    # --- Planer-Notizen ------------------------------------------------------------------
    def _hinweis(self) -> str:
        return "> " + self.t("Diese Datei wird bei jedem Sync neu geschrieben. Änderungen gehen verloren.")

    def _planer_notiz(self, heute: dt.date):
        g = self.tasks(heute)
        n_tage = int(self.cfg.get("demnaechst_tage", 7))
        bald = [t for t in g["geplant"] if parse_date(t["start"]) <= heute + dt.timedelta(days=n_tage)]
        gestern = (heute - dt.timedelta(days=1)).isoformat()
        erledigt = [t for t in g["erledigt"] if (t["erledigt_am"] or "") >= gestern]

        def zeile(t):
            teile = [f"- [[{t['pfad'][:-3]}|{t['titel']}]]"]
            if t["projekt"]:
                teile.append(f"· {t['projekt']}")
            if t["ende"]:
                teile.append(f"· {self.t('bis')} {self.datum(t['ende'])}")
            if (t["prioritaet"] or "") == "hoch":
                teile.append(f"· {self.t('Priorität hoch')}")
            if t["checks_total"]:
                teile.append(f"· {t['checks_done']}/{t['checks_total']}")
            return " ".join(teile)
        z = ["---", "typ: planer", f"datum: {heute.isoformat()}",
             f"aktualisiert: {dt.datetime.now().isoformat(timespec='minutes')}", "---",
             f"# {self.t('Tagesübersicht')} {self.sp.wochentag(heute)}, {self.sp.datum(heute)}", self._hinweis(), ""]
        for titel, liste in ((self.t("Heute"), g["heute"]), (self.t("Überfällig"), g["ueberfaellig"]),
                             (self.t("Demnächst (nächste {n} Tage)", n=n_tage), bald),
                             (self.t("Seit gestern erledigt"), erledigt)):
            z += [f"## {titel} ({len(liste)})"] + ([zeile(t) for t in liste] or ["- –"]) + [""]
        ms = self.meilensteine_faellig(heute)
        if ms:
            z += [f"## {self.t('Meilensteine')} ({len(ms)})"]
            z += [f"- [[{m['pfad'][:-3]}|{m['titel']}]] · {m.get('projekt', '')} · {self.datum(m['plan'])}"
                  + (f" · {self.t('überfällig')}" if m["ueberfaellig"] else "") for m in ms] + [""]
        inhalt = "\n".join(z)
        pdir = self.ordner("planer_ordner")
        (pdir / self.unter("archiv")).mkdir(parents=True, exist_ok=True)
        (pdir / f"{self.dateiname('heute')}.md").write_text(inhalt, encoding="utf-8")
        (pdir / self.unter("archiv") / f"{self.dateiname('tagesuebersicht', datum=heute.isoformat())}.md").write_text(
            inhalt, encoding="utf-8")

    def _pm_planer_notizen(self, heute: dt.date) -> None:
        """PM-Cockpit und Entscheid-Log als Notizen, nur wenn es PM-Daten gibt."""
        with self.db() as con:
            n = con.execute("SELECT COUNT(*) FROM notizen WHERE typ IN "
                            "('meilenstein','risiko','entscheid','pi')").fetchone()[0]
            n += con.execute("SELECT COUNT(*) FROM marker").fetchone()[0]
        if not n:
            return
        pdir = self.ordner("planer_ordner")
        pdir.mkdir(parents=True, exist_ok=True)
        kopf = ["---", "typ: planer", f"aktualisiert: {dt.datetime.now().isoformat(timespec='minutes')}", "---"]

        def link(pfad, titel):
            return f"[[{pfad[:-3]}|{titel}]]"
        c = self.pm_cockpit(heute)
        z = kopf + [f"# {self.t('PM-Cockpit')} {self.sp.datum(heute)}", self._hinweis(), "", f"## {self.t('Projekte')}"]
        if c["projekte"]:
            z += [f"| {self.t('Projekt')} | {self.t('Methode')} | {self.t('Phase / PI')} | {self.t('Nächster Meilenstein')} | "
                  f"{self.t('Offene Risiken')} | {self.t('Blocker')} |", "|---|---|---|---|---|---|"]
            for p in c["projekte"]:
                h = p.get("hermes")
                phase = (h["aktuelle_phase_name"] if h else "") or ""
                if p.get("pi"):
                    phase = (phase + " · " if phase else "") + p["pi"]["titel"]
                nm = h["naechster"] if h else None
                nm_txt = f"{nm['titel']} ({self.datum(nm['plan']) or self.t('ohne Datum')})" if nm else "–"
                z.append(f"| {p['name']} | {p['methode_label']} | {phase or '–'} | {nm_txt} | "
                         f"{p['risiken_offen']} | {p['blocker']} |")
        else:
            z.append("- –")
        z += ["", f"## {self.t('Meilensteine: überfällig und nächste {n} Tage', n=self.cfg.get('meilenstein_tage', 14))}"]
        z += [f"- {link(m['pfad'], m['titel'])} · {m.get('projekt', '')} · {self.datum(m['plan'])}"
              + (f" · {self.t('überfällig')}" if m["ueberfaellig"] else "") for m in c["meilensteine"]] or ["- –"]
        z += ["", f"## {self.t('Risiken nach ROAM')}"]
        alle = self.risiken(heute=heute)
        for s in pm.ROAM:
            rr = [r for r in alle if r["roam"] == s]
            if rr:
                z += [f"### {self.label(pm.ROAM, s)} ({len(rr)})"]
                z += [f"- {link(r['pfad'], r['titel'])} · {self.t('Wahrscheinlichkeit')} "
                      f"{self.label(pm.STUFEN, r.get('wahrscheinlichkeit', ''))}, {self.t('Auswirkung')} "
                      f"{self.label(pm.STUFEN, r.get('auswirkung', ''))}"
                      + (f" · {r['projekt']}" if r.get("projekt") else "")
                      + (f" · {r['verantwortlich']}" if r.get("verantwortlich") else "") for r in rr]
        if not alle:
            z.append("- –")
        mr = self.marker("risiko")
        if mr:
            z += ["", f"### {self.t('In Notizen mit #risiko markiert')}"]
            z += [f"- {m['anzeige']} · {link(m['pfad'], m['titel'])}" for m in mr[:50]]
        z += ["", f"## {self.t('Blocker (#blocker)')}"]
        z += [f"- {m['anzeige']} · {link(m['pfad'], m['titel'])}" for m in c["blocker"]] or ["- –"]
        (pdir / f"{self.dateiname('cockpit')}.md").write_text("\n".join(z) + "\n", encoding="utf-8")

        quelle = {"entscheid": self.t("Entscheid"), "adr": "ADR", "notiz": self.t("Notiz")}
        e = kopf + [f"# {self.t('Entscheid-Log')}", self._hinweis(),
                    "> " + self.t("Quellen: Entscheid-Notizen, technische Entscheidungen (ADR) und Zeilen mit #entscheid."),
                    "", f"| {self.t('Datum')} | {self.t('Entscheid')} | {self.t('Projekt')} | {self.t('Gremium')} | "
                        f"{self.t('Status')} | {self.t('Quelle')} |", "|---|---|---|---|---|---|"]
        for x in self.entscheide():
            titel = x["titel"].replace("|", "/")[:160]
            status = self.label(pm.ENTSCHEID_STATUS, x["status"]) if x["status"] else ""
            e.append(f"| {self.datum(x['datum'])} | [[{x['pfad'][:-3]}\\|{titel}]] | {x['projekt']} | {x['gremium']} | "
                     f"{status} | {quelle[x['quelle']]} |")
        (pdir / f"{self.dateiname('entscheidlog')}.md").write_text("\n".join(e) + "\n", encoding="utf-8")

    # --- Suche ------------------------------------------------------------------------------
    def suche(self, q: str, limit: int = 100) -> list[dict]:
        woerter = [w for w in q.split() if w]
        if not woerter:
            return []
        sql, args = "SELECT pfad, titel, typ, projekt, inhalt FROM notizen WHERE 1=1", []
        for w in woerter:
            sql += " AND (titel LIKE ? OR inhalt LIKE ? OR pfad LIKE ?)"
            args += [f"%{w}%"] * 3
        sql += " ORDER BY geaendert DESC LIMIT ?"
        args.append(limit)
        out = []
        with self.db() as con:
            for r in con.execute(sql, args):
                inhalt = r["inhalt"] or ""
                pos = inhalt.lower().find(woerter[0].lower())
                snippet = inhalt[max(0, pos - 80): pos + 160] if pos >= 0 else inhalt[:200]
                out.append({"pfad": r["pfad"], "titel": r["titel"], "typ": r["typ"], "projekt": r["projekt"],
                            "snippet": snippet.replace("\n", " "), "link": self.obsidian_link(r["pfad"]),
                            "score": sum(w.lower() in (r["titel"] or "").lower() for w in woerter)})
        out.sort(key=lambda x: -x["score"])
        return out

    # --- Sync -----------------------------------------------------------------------------
    def _iter_md(self):
        for p in self.vault.rglob("*.md"):
            if not any(part in SKIP_ORDNER for part in p.relative_to(self.vault).parts):
                yield p

    def _projekt_aus_pfad(self, rel: str) -> str:
        po = self.cfg.get("projekt_ordner") or ""
        parts = rel.split("/")
        if po:
            return parts[1] if len(parts) > 2 and parts[0] == po else ""
        if len(parts) > 1 and self._projekt_uebersicht(parts[0]):
            return parts[0]
        return ""

    def _index_file(self, con: sqlite3.Connection, p: Path, heute: dt.date):
        rel = self.rel(p)
        text = p.read_text(encoding="utf-8", errors="replace")
        fm, body = parse_frontmatter(text)
        typ = (fm.get("typ") or fm.get("type") or "").lower()
        name_l = p.name.lower()
        vorlagen = self.cfg.get("vorlagen_ordner") or "_Vorlagen"
        ist_vorlage = rel.startswith(vorlagen + "/")
        projekt = fm.get("projekt") or self._projekt_aus_pfad(rel)
        titel = fm.get("titel") or fm.get("title") or p.stem
        geaendert = dt.datetime.fromtimestamp(p.stat().st_mtime).isoformat(timespec="seconds")
        if ist_vorlage:
            typ = "vorlage"
        if not ist_vorlage and (name_l.startswith("task_") or typ == "task"):
            typ = "task"
            if not fm.get("titel") and name_l.startswith("task_"):
                titel = p.stem[5:].replace("_", " ")
            checks = CHECK_RE.findall(body)
            total, done = len(checks), sum(c.lower() == "x" for c in checks)
            raw = (fm.get("status") or "").lower().strip()
            if raw in ERLEDIGT_WERTE or (fm.get("erledigt") or "").lower() in ERLEDIGT_WERTE:
                status = "erledigt"
            elif not raw and total and total == done:
                status = "erledigt"
            else:
                status = raw if raw in pm.TASK_STATUS else "offen"
            erledigt_am = iso(parse_date(fm.get("erledigt_am"))) or (heute.isoformat() if status == "erledigt" else None)
            con.execute("""
                INSERT INTO tasks (pfad, titel, projekt, start, ende, status, prioritaet, verantwortlich,
                                   checks_total, checks_done, erledigt_am, geaendert, aktiv, jourfixe)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,1,?)
                ON CONFLICT(pfad) DO UPDATE SET
                    titel=excluded.titel, projekt=excluded.projekt, start=excluded.start, ende=excluded.ende,
                    status=excluded.status, prioritaet=excluded.prioritaet, verantwortlich=excluded.verantwortlich,
                    checks_total=excluded.checks_total, checks_done=excluded.checks_done,
                    erledigt_am=CASE WHEN excluded.status='erledigt'
                                     THEN COALESCE(tasks.erledigt_am, excluded.erledigt_am) ELSE NULL END,
                    geaendert=excluded.geaendert, aktiv=1, jourfixe=excluded.jourfixe
            """, (rel, titel, projekt, iso(parse_date(fm.get("start"))), iso(parse_date(fm.get("ende") or fm.get("end"))),
                  status, (fm.get("prioritaet") or "mittel").lower(), fm.get("verantwortlich", ""),
                  total, done, erledigt_am, geaendert, (fm.get("jourfixe") or "").strip()))
        if not typ and not name_l.startswith(("readme_", "_")):
            for key, t in (("team_ordner", "person"), ("jourfixe_ordner", "jourfixe")):
                o = self.cfg.get(key) or ""
                if o and rel.startswith(o + "/"):
                    typ = t
                    break
        con.execute("INSERT OR REPLACE INTO notizen (pfad, titel, typ, projekt, tags, kategorie, geaendert, inhalt, meta) "
                    "VALUES (?,?,?,?,?,?,?,?,?)",
                    (rel, titel, typ or "notiz", projekt, fm.get("tags", ""), fm.get("kategorie", ""), geaendert, body,
                     json.dumps(fm, ensure_ascii=False)))
        con.execute("DELETE FROM marker WHERE pfad=?", (rel,))
        if not ist_vorlage and typ not in ("planer", "index", "readme"):
            datum = iso(parse_date(fm.get("datum") or fm.get("erstellt"))) or geaendert[:10]
            for nr, tag, txt in marker_finden(body):
                con.execute("INSERT OR REPLACE INTO marker (pfad, zeile, tag, text, projekt, datum, titel) "
                            "VALUES (?,?,?,?,?,?,?)", (rel, nr, tag, txt, projekt, datum, titel))

    def _tagesuebersicht(self, con: sqlite3.Connection, heute: dt.date):
        d = heute.isoformat()
        con.execute("DELETE FROM tagesuebersicht WHERE datum=?", (d,))
        for r in con.execute("SELECT * FROM tasks WHERE aktiv=1").fetchall():
            t = dict(r)
            kat = task_kategorie(t, heute)
            if kat == "erledigt" and t["erledigt_am"] != d:
                continue
            con.execute("INSERT INTO tagesuebersicht VALUES (?,?,?,?,?,?,?,?)",
                        (d, t["pfad"], t["titel"], t["projekt"], kat, t["status"], t["ende"], t["prioritaet"]))

    def sync(self, art: str = "manuell") -> dict:
        with self._lock:
            t0 = time.time()
            heute = dt.date.today()
            self.ensure_basics()
            dateien = 0
            with self.db() as con:
                con.execute("UPDATE tasks SET aktiv=0")
                con.execute("DELETE FROM notizen")
                con.execute("DELETE FROM marker")
                for p in self._iter_md():
                    try:
                        self._index_file(con, p, heute)
                        dateien += 1
                    except Exception as exc:
                        print(f"[WARN] {p}: {exc}", file=sys.stderr)
                con.execute("DELETE FROM tasks WHERE aktiv=0")
                self._tagesuebersicht(con, heute)
            self._planer_notiz(heute)
            self._pm_planer_notizen(heute)
            g = self.tasks(heute)
            stats = {"zeitpunkt": dt.datetime.now().isoformat(timespec="seconds"), "art": art, "dateien": dateien,
                     "tasks_offen": sum(len(g[k]) for k in ("heute", "ueberfaellig", "geplant", "ohne_datum")),
                     "tasks_heute": len(g["heute"]), "tasks_erledigt": len(g["erledigt"]),
                     "dauer_ms": int((time.time() - t0) * 1000)}
            with self.db() as con:
                con.execute("INSERT INTO sync_log (zeitpunkt, art, dateien, tasks_offen, tasks_heute, tasks_erledigt, "
                            "lcm, dauer_ms) VALUES (:zeitpunkt,:art,:dateien,:tasks_offen,:tasks_heute,"
                            ":tasks_erledigt,0,:dauer_ms)", stats)
            return stats

    def sync_log(self, limit: int = 20) -> list[dict]:
        with self.db() as con:
            return [dict(r) for r in con.execute("SELECT * FROM sync_log ORDER BY id DESC LIMIT ?", (limit,))]

    def letzter_sync(self) -> dict | None:
        log = self.sync_log(1)
        return log[0] if log else None

    def geplanter_sync_faellig(self, jetzt: dt.datetime | None = None) -> bool:
        jetzt = jetzt or dt.datetime.now()
        h, m = (int(x) for x in str(self.cfg.get("sync_zeit", "04:00")).split(":"))
        slot = jetzt.replace(hour=h, minute=m, second=0, microsecond=0)
        if jetzt < slot:
            slot -= dt.timedelta(days=1)
        with self.db() as con:
            last = con.execute("SELECT MAX(zeitpunkt) FROM sync_log WHERE art='geplant'").fetchone()[0]
        return last is None or dt.datetime.fromisoformat(last) < slot

    def starte_scheduler(self):
        def loop():
            while True:
                try:
                    if self.vault_ok() and self.geplanter_sync_faellig():
                        s = self.sync("geplant")
                        print(f"[Agent] Sync: {s['tasks_heute']} / {s['tasks_offen']}")
                except Exception as exc:
                    print(f"[Agent] Sync: {exc}", file=sys.stderr)
                time.sleep(60)
        threading.Thread(target=loop, daemon=True, name="agent-scheduler").start()


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def main(argv=None):
    ap = argparse.ArgumentParser(description="Obsidian-Agent")
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("sync")
    s.add_argument("--geplant", action="store_true")
    sub.add_parser("heute")
    p = sub.add_parser("projekt")
    p.add_argument("name")
    p.add_argument("--methode", choices=[k for k in pm.METHODEN if k], default=None)
    sp = sub.add_parser("sprache")
    sp.add_argument("code", choices=list(SPRACHEN))
    a = ap.parse_args(argv)
    if a.cmd == "sprache":
        sprache_setzen(a.code)
        print(a.code)
        return
    agent = Agent()
    t = agent.t
    if a.cmd == "sync":
        st = agent.sync("geplant" if a.geplant else "manuell")
        print(t("Sync OK: {d} Dateien, {h} Tasks heute, {o} offen, {ms} ms", d=st["dateien"], h=st["tasks_heute"],
                o=st["tasks_offen"], ms=st["dauer_ms"]))
    elif a.cmd == "heute":
        g = agent.tasks()
        for titel, k in ((t("Heute"), "heute"), (t("Überfällig"), "ueberfaellig")):
            print(f"\n== {titel} ({len(g[k])}) ==")
            for x in g[k]:
                print(f"  [{x['prioritaet'][:1].upper()}] {x['titel']}  ({x['projekt'] or '-'}, {agent.datum(x['ende'])})")
    elif a.cmd == "projekt":
        print(t("Projekt angelegt: {pfad}", pfad=agent.projekt_anlegen(a.name, methode=a.methode)))


if __name__ == "__main__":
    main()
